// Claude Field - PS Vita homebrew (a nod to King's Field)
// First-person camera, PS1-style low-poly world, held-weapon view model,
// three weapon slots, enemies, rooms, beacons, XP and save files.
//
// Controls
//   Left stick   walk            Right stick  look
//   O            dodge: side-step toward the stick (back-step if neutral)
//   R            attack with the weapon in hand (slash / blunt / thrust)
//   D-pad L/R    swap between your three equipped weapons
//   X            interact (pick up / open door / talk / use beacon)
//   TRIANGLE     equipment      START        pause menu (equipment, bestiary, quit)
//   (menus)      D-pad up/down select, X confirm, O back
//   SELECT       debug: take damage (to test the health bar)
//
// Rendering: vitaGL (fixed-function), flat-shaded, vertex-colored, linear fog.

#include <vitasdk.h>
#include <vitaGL.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>

#define WORLD_HALF  30.0f      // plane spans -30..+30 on X and Z
#define EYE_HEIGHT  1.6f
#define MOVE_SPEED  4.5f       // units / second
#define LOOK_SPEED  2.4f       // radians / second at full stick
#define DEADZONE    0.15f
#define PLAYER_R    0.4f
#define PI_F        3.14159265f

// ---- Held-weapon placement in camera space (tweak these to taste) ----
// The weapon is modelled with its grip at the origin and the blade along +Y.
#define VM_X        0.62f      // + = right
#define VM_Y       -0.25f      // + = up
#define VM_Z       -0.74f      // - = away from camera
#define VM_ROT_Z    2.0f       // lean blade toward the left (degrees); 0 = straight up
#define VM_ROT_X   -8.0f       // tilt blade away from the camera (degrees)
// The arm is anchored off-screen at the shoulder (camera space) and stretches
// to the hand during swings.
#define ARM_ANCHOR_X        1.47f
#define ARM_ANCHOR_Y       -0.80f
#define ARM_ANCHOR_Z       -0.59f

// ---- Player stats / mechanics (tweak these) ----
#define MAX_HEALTH            100.0f
#define MAX_STAMINA           100.0f
#define STAMINA_REGEN          35.0f   // per second
#define STAMINA_REGEN_DELAY     0.8f   // seconds before regen after using stamina
#define STAMINA_EXHAUST_DELAY   1.4f   // longer delay if stamina hits zero
#define DODGE_COST             20.0f
#define DODGE_DISTANCE          3.2f   // world units
#define DODGE_TIME              0.28f  // seconds
#define DODGE_ROLL_DEG          4.0f   // camera tilt during a dodge

// ---- Weapon stats (hit_start / hit_end are fractions of the swing) ----
#define SWORD_DAMAGE         20.0f     // slashing
#define SWORD_SWING_TIME      0.60f
#define SWORD_STAMINA_COST   18.0f
#define SWORD_RANGE           2.6f
#define SWORD_ARC_DEG        80.0f     // half-angle in front of the player
#define SWORD_HIT_START       0.36f
#define SWORD_HIT_END         0.60f

#define MACE_DAMAGE          35.0f     // blunt
#define MACE_SWING_TIME       0.80f
#define MACE_STAMINA_COST    30.0f
#define MACE_RANGE            2.3f
#define MACE_ARC_DEG         50.0f
#define MACE_HIT_START        0.50f
#define MACE_HIT_END          0.72f

#define SPEAR_DAMAGE         24.0f     // piercing
#define SPEAR_SWING_TIME      0.62f
#define SPEAR_STAMINA_COST   16.0f
#define SPEAR_RANGE           3.5f
#define SPEAR_ARC_DEG        24.0f     // narrow: a thrust only hits what you point at
#define SPEAR_HIT_START       0.40f
#define SPEAR_HIT_END         0.56f

#define SWAP_TIME             0.34f    // weapon swap animation (the weapon changes at the halfway point)

#define DEBUG_DAMAGE           10.0f   // SELECT button

// ---- HUD bars (pixels; colors are r, g, b) ----
#define BAR_X               24.0f
#define BAR_Y               22.0f
#define BAR_GAP              8.0f
#define HEALTH_BAR_W       320.0f      // width at 100 max health (scales with max)
#define HEALTH_BAR_H        18.0f
#define STAMINA_BAR_W      250.0f      // width at 100 max stamina (scales with max)
#define STAMINA_BAR_H       12.0f
#define HEALTH_COLOR        0.78f, 0.12f, 0.12f
#define STAMINA_COLOR       0.85f, 0.75f, 0.15f

// Training dummy position
#define DUMMY_X             2.5f
#define DUMMY_Z             0.0f

// ---- Beacon (the crystal): save / rest / teleport ----
#define BEACON_X             0.0f
#define BEACON_Z            -5.0f
#define BEACON_RANGE         2.8f

// ---- Stone room + door (east of the start area) ----
#define ROOM_X0             16.0f      // west wall (the door is in this wall)
#define ROOM_X1             26.0f
#define ROOM_Z0             -5.0f
#define ROOM_Z1              5.0f
#define ROOM_WALL_H          3.6f
#define DOOR_HALF            1.1f      // half the doorway width
#define DOOR_OPEN_SPEED      1.1f      // 1 / seconds to swing open or shut
#define DOOR_RANGE           2.6f
#define ROOM2_X1            36.0f      // the second room shares the first room's east wall (x = ROOM_X1)

// ---- Giant rat (tweak these) ----
#define RAT_HEALTH          30.0f      // sword (20 dmg) = 2 hits, mace (35 dmg) = 1 hit
#define RAT_RESIST_SLASH     1.0f      // damage multipliers: 1 = neutral, >1 weak, <1 resistant
#define RAT_RESIST_BLUNT     1.0f
#define RAT_RESIST_PIERCE    1.0f
#define RAT_SCALE            1.8f
#define RAT_RADIUS           0.45f
#define RAT_AGGRO_RANGE      8.0f
#define RAT_HOP_SPEED        3.4f      // units / second while hopping
#define RAT_HOP_TIME         0.42f     // seconds per hop
#define RAT_ATTACK_RANGE     2.7f      // starts its wind-up this close
#define RAT_WINDUP_TIME      0.60f     // readable crouch before the lunge
#define RAT_LUNGE_TIME       0.22f
#define RAT_LUNGE_SPEED     12.0f
#define RAT_RECOVER_TIME     0.90f     // helpless after a lunge
#define RAT_STAGGER_TIME     0.35f
#define RAT_DAMAGE          12.0f
#define RAT_HIT_RADIUS       0.95f

// ---- Rock crab (tweak these) ----
#define CRAB_HEALTH         60.0f      // mace (35 x 1.5) = 2 hits; sword and spear take many more
#define CRAB_RESIST_SLASH    0.4f      // strong against slashing
#define CRAB_RESIST_BLUNT    1.5f      // weak to blunt
#define CRAB_RESIST_PIERCE   0.5f      // strong against piercing
#define CRAB_SCALE           1.4f
#define CRAB_RADIUS          0.8f
#define CRAB_AGGRO_RANGE     7.0f
#define CRAB_SPEED           1.9f      // chasing
#define CRAB_WANDER_SPEED    0.9f      // strolling around its room
#define CRAB_ATTACK_RANGE    2.3f
#define CRAB_WINDUP_TIME     0.85f     // rears up, claws raised
#define CRAB_LUNGE_TIME      0.16f
#define CRAB_LUNGE_SPEED    10.0f
#define CRAB_RECOVER_TIME    1.2f
#define CRAB_STAGGER_TIME    0.2f
#define CRAB_DAMAGE         20.0f
#define CRAB_HIT_RADIUS      1.5f
#define CRAB_XP             15

#define DODGE_IFRAME_FRAC    0.7f      // portion of a dodge where you can't be hurt

// ---- XP / attributes (tweak these) ----
// XP is a currency you carry. At a beacon you spend it to raise your level: going from level L to
// L+1 costs XP_BASE + XP_STEP * (L - 1), so each level costs a little more than the last.
#define XP_BASE             10
#define XP_STEP              5
#define XP_POP_DELAY         1.1f      // seconds a "+N" waits before it merges into the counter
#define RAT_XP               5
#define HP_PER_LEVEL        10.0f      // max health per Health point
#define STAM_PER_LEVEL       8.0f      // max stamina per Stamina point
#define STR_BONUS            0.10f     // extra weapon damage per Strength point (0.10 = +10%)

// ---- Save files ----
#ifndef SAVE_DIR
#define SAVE_DIR "ux0:data/PlainWalk"  // saves: save1.dat, save2.dat, save3.dat
#endif
#define NUM_SLOTS 3

// ---- NPC next to the door ----
#define NPC_X               14.6f
#define NPC_Z                3.0f
#define NPC_REST_YAW        -1.9f      // which way he faces when you're not near
#define NPC_RANGE            2.6f
#define DIALOGUE_CPS        38.0f      // typewriter speed (characters / second)
#define RESPAWN_DELAY        2.5f      // seconds on the death screen

#define V(x, y, z)  ((vec3){(x), (y), (z)})
#define C(r, g, b)  ((rgb){(r), (g), (b)})

typedef struct { float x, y, z; } vec3;
typedef struct { float r, g, b; } rgb;
typedef struct { float x, z, r; } collider;

// ---------------------------------------------------------------- mesh ----

typedef struct { float *v; float *c; int n; int max; } Mesh;

#define DECLARE_MESH(name, maxv)                 \
    static float name##_v[(maxv) * 3];           \
    static float name##_c[(maxv) * 4];           \
    static Mesh name = { name##_v, name##_c, 0, (maxv) }

DECLARE_MESH(world_mesh, 30000);
DECLARE_MESH(hand_mesh, 1500);
DECLARE_MESH(sword_mesh, 1000);
DECLARE_MESH(mace_mesh, 1500);
DECLARE_MESH(dummy_mesh, 1500);
DECLARE_MESH(arm_mesh, 400);
DECLARE_MESH(rat_mesh, 600);
DECLARE_MESH(door_mesh, 200);
DECLARE_MESH(gem_mesh, 200);
DECLARE_MESH(npc_mesh, 500);
DECLARE_MESH(spear_mesh, 600);
DECLARE_MESH(crab_mesh, 1800);

static Mesh *cur;   // mesh the add_* helpers currently write into

static collider colliders[64];
static int      ncolliders = 0;

static void add_collider(float x, float z, float r) {
    if (ncolliders < 64) colliders[ncolliders++] = (collider){x, z, r};
}

// Axis-aligned wall boxes (the stone room). Can be switched off (the door).
typedef struct { float x0, z0, x1, z1; int on; } wall_t;
static wall_t walls[16];
static int    nwalls = 0;

// Doors: 0 = outside -> first room (west wall), 1 = first room -> second room (east wall).
typedef struct { float x; float open_t; int target; int wall; } Door;   // open_t 0 shut .. 1 open
#define NUM_DOORS 2
static Door doors[NUM_DOORS] = { { ROOM_X0, 0.0f, 0, -1 }, { ROOM_X1, 0.0f, 0, -1 } };

static int add_wall_collider(float x0, float z0, float x1, float z1) {
    if (nwalls >= 16) return -1;
    walls[nwalls] = (wall_t){x0, z0, x1, z1, 1};
    return nwalls++;
}

// Push a circle (x, z, radius r) out of every circle collider and active wall.
static void resolve_collisions(float *x, float *z, float r) {
    for (int i = 0; i < ncolliders; i++) {
        float dx = *x - colliders[i].x, dz = *z - colliders[i].z;
        float d = sqrtf(dx * dx + dz * dz);
        float minD = colliders[i].r + r;
        if (d < minD && d > 1e-4f) {
            *x = colliders[i].x + dx / d * minD;
            *z = colliders[i].z + dz / d * minD;
        }
    }
    for (int i = 0; i < nwalls; i++) {
        const wall_t *w = &walls[i];
        if (!w->on) continue;
        float cx = fminf(fmaxf(*x, w->x0), w->x1);
        float cz = fminf(fmaxf(*z, w->z0), w->z1);
        float dx = *x - cx, dz = *z - cz;
        float d2 = dx * dx + dz * dz;
        if (d2 >= r * r) continue;
        if (d2 > 1e-8f) {
            float d = sqrtf(d2);
            *x = cx + dx / d * r;
            *z = cz + dz / d * r;
        } else {   // centre is inside the box: leave by the nearest side
            float l = *x - w->x0, rt = w->x1 - *x, tp = *z - w->z0, bt = w->z1 - *z;
            float m = fminf(fminf(l, rt), fminf(tp, bt));
            if (m == l) *x = w->x0 - r;
            else if (m == rt) *x = w->x1 + r;
            else if (m == tp) *z = w->z0 - r;
            else *z = w->z1 + r;
        }
    }
}

static vec3 v_sub(vec3 a, vec3 b) { return V(a.x - b.x, a.y - b.y, a.z - b.z); }
static vec3 v_cross(vec3 a, vec3 b) {
    return V(a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x);
}
static vec3 v_norm(vec3 a) {
    float l = sqrtf(a.x * a.x + a.y * a.y + a.z * a.z);
    return l > 1e-6f ? V(a.x / l, a.y / l, a.z / l) : V(0, 1, 0);
}

// Flat-shaded triangle. Shading is baked from a fixed light direction and is
// two-sided, so winding order doesn't matter.
static void add_tri(vec3 a, vec3 b, vec3 c, rgb col) {
    if (cur->n + 3 > cur->max) return;

    vec3 n = v_cross(v_sub(b, a), v_sub(c, a));
    float len = sqrtf(n.x * n.x + n.y * n.y + n.z * n.z);

    float shade = 0.7f;
    if (len > 1e-6f) {
        float d = fabsf((n.x * 0.45f + n.y * 0.80f + n.z * 0.40f) / len);
        shade = 0.45f + 0.55f * d;
    }

    vec3 p[3] = {a, b, c};
    for (int i = 0; i < 3; i++) {
        int k = cur->n++;
        cur->v[k * 3 + 0] = p[i].x;
        cur->v[k * 3 + 1] = p[i].y;
        cur->v[k * 3 + 2] = p[i].z;
        cur->c[k * 4 + 0] = col.r * shade;
        cur->c[k * 4 + 1] = col.g * shade;
        cur->c[k * 4 + 2] = col.b * shade;
        cur->c[k * 4 + 3] = 1.0f;
    }
}

static void add_quad(vec3 a, vec3 b, vec3 c, vec3 d, rgb col) {
    add_tri(a, b, c, col);
    add_tri(a, c, d, col);
}

static void add_box(float cx, float y0, float cz, float sx, float sy, float sz, rgb col) {
    float x0 = cx - sx / 2, x1 = cx + sx / 2;
    float z0 = cz - sz / 2, z1 = cz + sz / 2;
    float y1 = y0 + sy;
    add_quad(V(x0, y1, z0), V(x1, y1, z0), V(x1, y1, z1), V(x0, y1, z1), col); // top
    add_quad(V(x0, y0, z1), V(x1, y0, z1), V(x1, y1, z1), V(x0, y1, z1), col); // +z
    add_quad(V(x1, y0, z0), V(x0, y0, z0), V(x0, y1, z0), V(x1, y1, z0), col); // -z
    add_quad(V(x1, y0, z1), V(x1, y0, z0), V(x1, y1, z0), V(x1, y1, z1), col); // +x
    add_quad(V(x0, y0, z0), V(x0, y0, z1), V(x0, y1, z1), V(x0, y1, z0), col); // -x
}

static void add_pyramid(float cx, float y0, float cz, float base, float height, rgb col) {
    float h = base / 2;
    vec3 p0 = V(cx - h, y0, cz - h), p1 = V(cx + h, y0, cz - h);
    vec3 p2 = V(cx + h, y0, cz + h), p3 = V(cx - h, y0, cz + h);
    vec3 apex = V(cx, y0 + height, cz);
    add_tri(p0, p1, apex, col);
    add_tri(p1, p2, apex, col);
    add_tri(p2, p3, apex, col);
    add_tri(p3, p0, apex, col);
    add_quad(p0, p1, p2, p3, col);
}

static void add_cylinder(float cx, float y0, float cz, float r, float height, int sides, rgb col) {
    float y1 = y0 + height;
    for (int i = 0; i < sides; i++) {
        float a0 = 2 * PI_F * i / sides, a1 = 2 * PI_F * (i + 1) / sides;
        vec3 b0 = V(cx + cosf(a0) * r, y0, cz + sinf(a0) * r);
        vec3 b1 = V(cx + cosf(a1) * r, y0, cz + sinf(a1) * r);
        vec3 t0 = V(b0.x, y1, b0.z), t1 = V(b1.x, y1, b1.z);
        add_quad(b0, b1, t1, t0, col);
        add_tri(V(cx, y1, cz), t0, t1, col);
    }
}

static void add_cone(float cx, float y0, float cz, float r, float height, int sides, rgb col) {
    vec3 apex = V(cx, y0 + height, cz);
    for (int i = 0; i < sides; i++) {
        float a0 = 2 * PI_F * i / sides, a1 = 2 * PI_F * (i + 1) / sides;
        vec3 b0 = V(cx + cosf(a0) * r, y0, cz + sinf(a0) * r);
        vec3 b1 = V(cx + cosf(a1) * r, y0, cz + sinf(a1) * r);
        add_tri(b0, b1, apex, col);
        add_tri(V(cx, y0, cz), b0, b1, col);
    }
}

// Tube between two arbitrary points (arms, handles, shafts).
static void add_prism(vec3 a, vec3 b, float r, int sides, rgb col) {
    vec3 d = v_norm(v_sub(b, a));
    vec3 ref = fabsf(d.y) < 0.9f ? V(0, 1, 0) : V(1, 0, 0);
    vec3 u = v_norm(v_cross(d, ref));
    vec3 w = v_cross(d, u);
    for (int i = 0; i < sides; i++) {
        float a0 = 2 * PI_F * i / sides, a1 = 2 * PI_F * (i + 1) / sides;
        float c0 = cosf(a0) * r, s0 = sinf(a0) * r, c1 = cosf(a1) * r, s1 = sinf(a1) * r;
        vec3 o0 = V(u.x * c0 + w.x * s0, u.y * c0 + w.y * s0, u.z * c0 + w.z * s0);
        vec3 o1 = V(u.x * c1 + w.x * s1, u.y * c1 + w.y * s1, u.z * c1 + w.z * s1);
        vec3 a0p = V(a.x + o0.x, a.y + o0.y, a.z + o0.z), a1p = V(a.x + o1.x, a.y + o1.y, a.z + o1.z);
        vec3 b0p = V(b.x + o0.x, b.y + o0.y, b.z + o0.z), b1p = V(b.x + o1.x, b.y + o1.y, b.z + o1.z);
        add_quad(a0p, a1p, b1p, b0p, col);
        add_tri(b, b0p, b1p, col);
    }
}

static void add_octahedron(float cx, float cy, float cz, float r, rgb c1, rgb c2) {
    vec3 top = V(cx, cy + r * 1.4f, cz), bot = V(cx, cy - r * 1.4f, cz);
    vec3 e[4] = {V(cx + r, cy, cz), V(cx, cy, cz + r), V(cx - r, cy, cz), V(cx, cy, cz - r)};
    for (int i = 0; i < 4; i++) {
        vec3 a = e[i], b = e[(i + 1) % 4];
        add_tri(a, b, top, (i & 1) ? c1 : c2);
        add_tri(b, a, bot, (i & 1) ? c2 : c1);
    }
}

// --------------------------------------------------------------- scene ----

static void build_ground(void) {
    const int n = 30;
    const float t = 2.0f;
    for (int j = 0; j < n; j++) {
        for (int i = 0; i < n; i++) {
            float x0 = -WORLD_HALF + i * t, z0 = -WORLD_HALF + j * t;
            float var = ((i * 7 + j * 13) % 3) * 0.025f;
            rgb c = ((i + j) & 1) ? C(0.26f + var, 0.50f + var, 0.22f)
                                  : C(0.22f + var, 0.44f + var, 0.19f);
            add_quad(V(x0, 0, z0), V(x0, 0, z0 + t), V(x0 + t, 0, z0 + t), V(x0 + t, 0, z0), c);
        }
    }
}

static void add_tree(float x, float z) {
    add_cylinder(x, 0.0f, z, 0.25f, 1.6f, 6, C(0.40f, 0.26f, 0.14f));
    add_cone(x, 1.4f, z, 1.4f, 3.2f, 7, C(0.10f, 0.35f, 0.14f));
    add_cone(x, 3.0f, z, 1.0f, 2.4f, 7, C(0.13f, 0.42f, 0.17f));
    add_collider(x, z, 0.5f);
}

static void add_wall_block(float x0, float z0, float x1, float z1, float h, rgb col) {
    add_box((x0 + x1) / 2, 0.0f, (z0 + z1) / 2, x1 - x0, h, z1 - z0, col);
    add_wall_collider(x0, z0, x1, z1);
}

// A small enclosed stone room with a door in its west wall.
static void build_room(void) {
    rgb stone = C(0.46f, 0.46f, 0.52f), stone2 = C(0.40f, 0.40f, 0.46f), roof = C(0.26f, 0.26f, 0.31f);
    const float T = 0.25f;   // half wall thickness

    // Floor: dark checkered flagstones just above the grass.
    for (int j = 0; j < 5; j++) {
        for (int i = 0; i < 5; i++) {
            float x0 = ROOM_X0 + i * 2.0f, z0 = ROOM_Z0 + j * 2.0f;
            rgb c = ((i + j) & 1) ? C(0.32f, 0.32f, 0.36f) : C(0.27f, 0.27f, 0.31f);
            add_quad(V(x0, 0.03f, z0), V(x0, 0.03f, z0 + 2), V(x0 + 2, 0.03f, z0 + 2), V(x0 + 2, 0.03f, z0), c);
        }
    }

    add_wall_block(ROOM_X0 - T, ROOM_Z0 - T, ROOM_X1 + T, ROOM_Z0 + T, ROOM_WALL_H, stone);    // north
    add_wall_block(ROOM_X0 - T, ROOM_Z1 - T, ROOM_X1 + T, ROOM_Z1 + T, ROOM_WALL_H, stone);    // south
    add_wall_block(ROOM_X1 - T, ROOM_Z0 + T, ROOM_X1 + T, -DOOR_HALF, ROOM_WALL_H, stone2);    // east, left of door
    add_wall_block(ROOM_X1 - T, DOOR_HALF, ROOM_X1 + T, ROOM_Z1 - T, ROOM_WALL_H, stone2);     // east, right of door
    add_box(ROOM_X1, 2.8f, 0.0f, 2 * T, ROOM_WALL_H - 2.8f, 2 * DOOR_HALF, stone);            // lintel over the back door
    add_wall_block(ROOM_X0 - T, ROOM_Z0 + T, ROOM_X0 + T, -DOOR_HALF, ROOM_WALL_H, stone2);    // west, left of door
    add_wall_block(ROOM_X0 - T, DOOR_HALF, ROOM_X0 + T, ROOM_Z1 - T, ROOM_WALL_H, stone2);     // west, right of door
    add_box(ROOM_X0, 2.8f, 0.0f, 2 * T, ROOM_WALL_H - 2.8f, 2 * DOOR_HALF, stone);            // lintel over the door
    add_box((ROOM_X0 + ROOM_X1) / 2, ROOM_WALL_H, (ROOM_Z0 + ROOM_Z1) / 2,
            (ROOM_X1 - ROOM_X0) + 2 * T + 0.2f, 0.3f, (ROOM_Z1 - ROOM_Z0) + 2 * T + 0.2f, roof);   // roof

    // Invisible-when-open collider that fills the doorway while the door is shut.
    doors[0].wall = add_wall_collider(ROOM_X0 - 0.2f, -DOOR_HALF, ROOM_X0 + 0.2f, DOOR_HALF);
    doors[1].wall = add_wall_collider(ROOM_X1 - 0.2f, -DOOR_HALF, ROOM_X1 + 0.2f, DOOR_HALF);

    // A couple of crates for atmosphere.
    add_box(24.6f, 0.0f, -3.6f, 1.4f, 1.4f, 1.4f, C(0.55f, 0.38f, 0.18f));
    add_collider(24.6f, -3.6f, 1.0f);
    add_box(24.8f, 0.0f, 3.7f, 1.2f, 1.2f, 1.2f, C(0.50f, 0.34f, 0.16f));
    add_collider(24.8f, 3.7f, 0.9f);

    // ---- Second room, behind the first (its door is in the shared east wall) ----
    for (int j = 0; j < 5; j++) {
        for (int i = 0; i < 5; i++) {
            float x0 = ROOM_X1 + i * 2.0f, z0 = ROOM_Z0 + j * 2.0f;
            rgb c = ((i + j) & 1) ? C(0.21f, 0.25f, 0.23f) : C(0.17f, 0.21f, 0.19f);
            add_quad(V(x0, 0.03f, z0), V(x0, 0.03f, z0 + 2), V(x0 + 2, 0.03f, z0 + 2), V(x0 + 2, 0.03f, z0), c);
        }
    }
    add_wall_block(ROOM_X1 + T, ROOM_Z0 - T, ROOM2_X1 + T, ROOM_Z0 + T, ROOM_WALL_H, stone2);   // north
    add_wall_block(ROOM_X1 + T, ROOM_Z1 - T, ROOM2_X1 + T, ROOM_Z1 + T, ROOM_WALL_H, stone2);   // south
    add_wall_block(ROOM2_X1 - T, ROOM_Z0 + T, ROOM2_X1 + T, ROOM_Z1 - T, ROOM_WALL_H, stone);   // east
    add_box((ROOM_X1 + ROOM2_X1) / 2, ROOM_WALL_H + 0.01f, (ROOM_Z0 + ROOM_Z1) / 2,
            (ROOM2_X1 - ROOM_X1) + 2 * T + 0.2f, 0.3f, (ROOM_Z1 - ROOM_Z0) + 2 * T + 0.2f, roof);   // roof

    // Boulders and stalagmites: a rocky den.
    rgb rk = C(0.40f, 0.39f, 0.38f), rk2 = C(0.28f, 0.28f, 0.29f);
    add_octahedron(34.8f, 0.8f, -3.5f, 1.0f, rk, rk2);   add_collider(34.8f, -3.5f, 0.9f);
    add_octahedron(34.6f, 0.6f,  3.6f, 0.8f, rk, rk2);   add_collider(34.6f,  3.6f, 0.7f);
    add_octahedron(28.0f, 0.5f, -4.0f, 0.6f, rk, rk2);   add_collider(28.0f, -4.0f, 0.55f);
    add_cone(30.5f, 0.0f, -4.2f, 0.4f, 1.6f, 6, rk2);
    add_cone(32.6f, 0.0f,  4.3f, 0.5f, 2.0f, 6, rk);
    add_cone(28.6f, 0.0f,  4.3f, 0.3f, 1.2f, 6, rk2);
}

static void build_scene(void) {
    cur = &world_mesh;
    build_ground();

    // Crate stack
    add_box(6.0f, 0.0f, -6.0f, 2.0f, 2.0f, 2.0f, C(0.62f, 0.42f, 0.20f));
    add_box(6.3f, 2.0f, -6.0f, 1.2f, 1.2f, 1.2f, C(0.70f, 0.48f, 0.24f));
    add_collider(6.0f, -6.0f, 1.45f);

    // Sand pyramid
    add_pyramid(-9.0f, 0.0f, -11.0f, 6.0f, 5.0f, C(0.80f, 0.70f, 0.42f));
    add_collider(-9.0f, -11.0f, 3.0f);

    // Trees
    add_tree(-5.0f, 4.0f);
    add_tree(4.0f, 9.0f);
    add_tree(-13.0f, 6.0f);
    add_tree(11.0f, 3.0f);
    add_tree(15.0f, -13.0f);

    // Ring of stone pillars around the start point
    for (int i = 0; i < 8; i++) {
        float a = 2 * PI_F * i / 8;
        float x = cosf(a) * 11.0f, z = sinf(a) * 11.0f;
        add_cylinder(x, 0.0f, z, 0.5f, 3.5f, 8, C(0.58f, 0.58f, 0.62f));
        add_box(x, 3.5f, z, 1.3f, 0.35f, 1.3f, C(0.48f, 0.48f, 0.52f));
        add_collider(x, z, 0.75f);
    }

    // Pedestal (the beacon crystal floats above it and is drawn separately)
    add_box(0.0f, 0.0f, -5.0f, 1.4f, 0.8f, 1.4f, C(0.50f, 0.50f, 0.54f));
    add_collider(0.0f, -5.0f, 1.1f);

    build_room();
}

// ------------------------------------------------- weapons & right hand ----
// Weapon meshes: grip at the origin, blade/shaft along +Y, flat faces toward +Z.

static void build_sword(void) {
    cur = &sword_mesh;
    rgb leather = C(0.35f, 0.22f, 0.12f);
    rgb steel = C(0.70f, 0.76f, 0.80f), steel2 = C(0.52f, 0.60f, 0.66f);
    rgb guard = C(0.42f, 0.50f, 0.58f);

    add_prism(V(0, -0.20f, 0), V(0, 0.0f, 0), 0.022f, 6, leather);   // grip
    add_box(0, -0.25f, 0, 0.07f, 0.05f, 0.07f, guard);               // pommel
    add_box(0, 0.0f, 0, 0.20f, 0.035f, 0.05f, guard);                // cross-guard
    add_box(-0.14f, 0.0f, 0, 0.07f, 0.09f, 0.04f, guard);            // guard wings
    add_box( 0.14f, 0.0f, 0, 0.07f, 0.09f, 0.04f, guard);

    // Diamond cross-section blade with a pointed tip.
    float y0 = 0.035f, ysh = 0.72f, y1 = 0.88f, hw = 0.06f, ht = 0.016f;
    vec3 bl = V(-hw, y0, 0), br = V(hw, y0, 0), bf = V(0, y0, ht), bb = V(0, y0, -ht);
    vec3 sl = V(-hw, ysh, 0), sr = V(hw, ysh, 0), sf = V(0, ysh, ht), sb = V(0, ysh, -ht);
    vec3 tip = V(0, y1, 0);
    add_quad(bl, bf, sf, sl, steel);
    add_quad(bf, br, sr, sf, steel2);
    add_quad(bb, bl, sl, sb, steel2);
    add_quad(br, bb, sb, sr, steel);
    add_tri(sl, sf, tip, steel);
    add_tri(sf, sr, tip, steel2);
    add_tri(sb, sl, tip, steel2);
    add_tri(sr, sb, tip, steel);
}

static void build_mace(void) {
    cur = &mace_mesh;
    rgb wood = C(0.42f, 0.28f, 0.15f), iron = C(0.45f, 0.47f, 0.52f), iron2 = C(0.58f, 0.60f, 0.66f);

    add_prism(V(0, -0.22f, 0), V(0, 0.55f, 0), 0.025f, 6, wood);     // shaft
    add_box(0, -0.27f, 0, 0.07f, 0.05f, 0.07f, iron);                // pommel
    add_cylinder(0, 0.48f, 0, 0.085f, 0.20f, 8, iron);               // head
    add_cone(0, 0.68f, 0, 0.085f, 0.12f, 8, iron2);                  // top spike
    add_box(-0.115f, 0.54f, 0, 0.06f, 0.07f, 0.06f, iron2);          // studs
    add_box( 0.115f, 0.54f, 0, 0.06f, 0.07f, 0.06f, iron2);
    add_box(0, 0.54f, -0.115f, 0.06f, 0.07f, 0.06f, iron2);
    add_box(0, 0.54f,  0.115f, 0.06f, 0.07f, 0.06f, iron2);
}

// Spear: long shaft with a leaf-shaped head (grip at the origin, tip along +Y).
static void build_spear(void) {
    cur = &spear_mesh;
    rgb wood = C(0.45f, 0.30f, 0.16f), iron = C(0.50f, 0.52f, 0.58f);
    rgb steel = C(0.86f, 0.89f, 0.93f), steel2 = C(0.66f, 0.72f, 0.78f), red = C(0.65f, 0.15f, 0.12f);

    add_prism(V(0, -0.35f, 0), V(0, 1.30f, 0), 0.022f, 6, wood);     // shaft
    add_box(0, -0.40f, 0, 0.055f, 0.06f, 0.055f, iron);              // butt cap
    add_prism(V(0, 1.08f, 0), V(0, 1.18f, 0), 0.034f, 6, red);       // cloth band
    add_prism(V(0, 1.26f, 0), V(0, 1.38f, 0), 0.034f, 6, iron);      // socket
    vec3 pb = V(0, 1.38f, 0), tip = V(0, 2.00f, 0);
    vec3 L = V(-0.11f, 1.58f, 0), R = V(0.11f, 1.58f, 0), F = V(0, 1.58f, 0.03f), B = V(0, 1.58f, -0.03f);
    add_tri(pb, F, L, steel);  add_tri(pb, R, F, steel2);
    add_tri(pb, B, R, steel);  add_tri(pb, L, B, steel2);
    add_tri(L, F, tip, steel); add_tri(F, R, tip, steel2);
    add_tri(R, B, tip, steel); add_tri(B, L, tip, steel2);
}

// Right hand + forearm, fingers wrapped around the grip, arm leaving the
// bottom-right corner of the screen.
static void build_hand(void) {
    cur = &hand_mesh;
    rgb skin = C(0.80f, 0.58f, 0.44f), skin2 = C(0.70f, 0.50f, 0.38f);

    add_box(0.035f, -0.155f, -0.005f, 0.11f, 0.14f, 0.05f, skin2);   // back of hand
    for (int k = 0; k < 4; k++)                                      // fingers
        add_box(0.01f, -0.15f + 0.034f * k, 0.035f, 0.095f, 0.03f, 0.045f, skin);
    add_box(-0.03f, -0.03f, 0.035f, 0.035f, 0.035f, 0.045f, skin);   // thumb
}

// Straw training dummy (origin at its base). Swing at it to test attacks.
static void build_dummy(void) {
    cur = &dummy_mesh;
    rgb wood = C(0.40f, 0.28f, 0.16f), straw = C(0.78f, 0.68f, 0.42f), straw2 = C(0.66f, 0.56f, 0.34f);
    add_cylinder(0, 0.0f, 0, 0.5f, 0.08f, 8, C(0.36f, 0.26f, 0.15f));   // base
    add_cylinder(0, 0.0f, 0, 0.12f, 1.2f, 6, wood);                      // post
    add_box(0, 0.88f, 0, 0.95f, 0.12f, 0.12f, wood);                     // arms
    add_box(0, 0.55f, 0, 0.55f, 0.75f, 0.30f, straw);                    // torso
    add_octahedron(0, 1.55f, 0, 0.22f, straw, straw2);                   // head
    add_collider(DUMMY_X, DUMMY_Z, 0.55f);
}

// Blocky PS1-style rat (origin at its feet, snout toward +Z).
static void build_rat(void) {
    cur = &rat_mesh;
    rgb fur = C(0.46f, 0.38f, 0.32f), fur2 = C(0.38f, 0.31f, 0.26f);
    rgb pink = C(0.80f, 0.55f, 0.55f), eye = C(0.95f, 0.15f, 0.12f), tooth = C(0.92f, 0.90f, 0.80f);

    add_box(0.0f, 0.08f, -0.05f, 0.30f, 0.24f, 0.50f, fur);        // body
    add_box(0.0f, 0.10f, -0.24f, 0.34f, 0.28f, 0.24f, fur2);       // haunches
    add_box(0.0f, 0.12f, 0.28f, 0.20f, 0.18f, 0.22f, fur);         // head
    add_box(0.0f, 0.14f, 0.44f, 0.11f, 0.11f, 0.14f, fur2);        // snout
    add_box(0.0f, 0.17f, 0.52f, 0.05f, 0.05f, 0.04f, pink);        // nose
    add_box(0.0f, 0.08f, 0.46f, 0.05f, 0.05f, 0.03f, tooth);       // buck teeth
    add_box(-0.10f, 0.28f, 0.20f, 0.07f, 0.10f, 0.03f, pink);      // ears
    add_box( 0.10f, 0.28f, 0.20f, 0.07f, 0.10f, 0.03f, pink);
    add_box(-0.075f, 0.22f, 0.385f, 0.035f, 0.035f, 0.03f, eye);   // eyes
    add_box( 0.075f, 0.22f, 0.385f, 0.035f, 0.035f, 0.03f, eye);
    add_box(-0.11f, 0.0f, 0.14f, 0.07f, 0.10f, 0.09f, fur2);       // legs
    add_box( 0.11f, 0.0f, 0.14f, 0.07f, 0.10f, 0.09f, fur2);
    add_box(-0.13f, 0.0f, -0.26f, 0.08f, 0.12f, 0.12f, fur2);
    add_box( 0.13f, 0.0f, -0.26f, 0.08f, 0.12f, 0.12f, fur2);
    add_prism(V(0.0f, 0.16f, -0.36f), V(0.0f, 0.10f, -0.62f), 0.022f, 4, pink);   // tail
    add_prism(V(0.0f, 0.10f, -0.62f), V(0.0f, 0.20f, -0.88f), 0.018f, 4, pink);
}

// Rock crab: a chunky crab made of boulders (origin at its feet, claws toward +Z).
static void build_crab(void) {
    cur = &crab_mesh;
    rgb rock = C(0.46f, 0.44f, 0.41f), rock2 = C(0.34f, 0.33f, 0.33f), rock3 = C(0.56f, 0.53f, 0.48f);
    rgb dark = C(0.22f, 0.21f, 0.22f), moss = C(0.28f, 0.40f, 0.22f), glow = C(1.0f, 0.55f, 0.15f);

    add_box(0.0f, 0.12f, 0.0f, 0.95f, 0.30f, 0.76f, rock2);          // lower body
    add_box(0.0f, 0.40f, -0.02f, 0.78f, 0.22f, 0.62f, rock);         // upper shell
    add_box(0.0f, 0.18f, -0.44f, 0.55f, 0.22f, 0.14f, rock2);        // rear plate
    add_octahedron(0.0f, 0.66f, -0.05f, 0.27f, rock3, rock);         // rocks on its back
    add_octahedron(-0.28f, 0.58f, 0.12f, 0.17f, rock, rock2);
    add_octahedron(0.30f, 0.57f, -0.16f, 0.19f, rock3, rock2);
    add_box(0.04f, 0.60f, 0.22f, 0.24f, 0.04f, 0.16f, moss);         // moss patch

    add_box(-0.14f, 0.50f, 0.32f, 0.06f, 0.16f, 0.06f, rock2);       // eye stalks
    add_box( 0.14f, 0.50f, 0.32f, 0.06f, 0.16f, 0.06f, rock2);
    add_box(-0.14f, 0.64f, 0.34f, 0.09f, 0.09f, 0.09f, glow);        // glowing eyes
    add_box( 0.14f, 0.64f, 0.34f, 0.09f, 0.09f, 0.09f, glow);

    for (int k = 0; k < 2; k++) {
        float sgn = k ? 1.0f : -1.0f;
        add_box(sgn * 0.46f, 0.18f, 0.30f, 0.20f, 0.18f, 0.34f, rock2);   // upper arm
        add_box(sgn * 0.58f, 0.14f, 0.58f, 0.34f, 0.28f, 0.34f, rock);    // claw
        add_box(sgn * 0.49f, 0.14f, 0.84f, 0.13f, 0.20f, 0.30f, rock3);   // pincers
        add_box(sgn * 0.67f, 0.14f, 0.84f, 0.13f, 0.20f, 0.30f, rock3);
        for (int i = 0; i < 3; i++) {                                     // legs
            float z = -0.24f + 0.22f * i;
            add_prism(V(sgn * 0.42f, 0.24f, z), V(sgn * 0.82f, 0.02f, z + 0.05f), 0.045f, 4, dark);
        }
    }
}

// Door slab with its hinge at the origin, extending along -Z.
static void build_door(void) {
    cur = &door_mesh;
    rgb wood = C(0.40f, 0.26f, 0.14f), iron = C(0.30f, 0.30f, 0.34f);
    const float w = 2.0f * DOOR_HALF + 0.05f;
    add_box(0.0f, 0.0f, -w / 2, 0.14f, 2.7f, w, wood);
    add_box(0.0f, 0.5f, -w / 2, 0.18f, 0.12f, w, iron);
    add_box(0.0f, 1.9f, -w / 2, 0.18f, 0.12f, w, iron);
    add_box(0.12f, 1.2f, -w + 0.25f, 0.08f, 0.10f, 0.10f, iron);   // handle
}

// Hooded wanderer (origin at his feet, facing +Z).
static void build_npc(void) {
    cur = &npc_mesh;
    rgb cloth = C(0.30f, 0.27f, 0.24f), cloth2 = C(0.24f, 0.21f, 0.19f), hood = C(0.36f, 0.30f, 0.22f);
    rgb skin = C(0.78f, 0.62f, 0.50f), dark = C(0.10f, 0.08f, 0.08f), belt = C(0.45f, 0.30f, 0.14f);

    add_box(-0.12f, 0.0f, 0.0f, 0.16f, 0.7f, 0.20f, dark);            // legs
    add_box( 0.12f, 0.0f, 0.0f, 0.16f, 0.7f, 0.20f, dark);
    add_box(0.0f, 0.12f, 0.0f, 0.72f, 0.55f, 0.46f, cloth2);          // cloak skirt
    add_box(0.0f, 0.60f, 0.0f, 0.60f, 0.80f, 0.38f, cloth);           // torso
    add_box(0.0f, 0.62f, 0.0f, 0.64f, 0.08f, 0.42f, belt);            // belt
    add_box(-0.38f, 0.72f, 0.04f, 0.14f, 0.60f, 0.18f, cloth);        // arms
    add_box( 0.38f, 0.72f, 0.04f, 0.14f, 0.60f, 0.18f, cloth);
    add_box(-0.38f, 0.64f, 0.06f, 0.11f, 0.11f, 0.11f, skin);         // hands
    add_box( 0.38f, 0.64f, 0.06f, 0.11f, 0.11f, 0.11f, skin);
    add_box(0.0f, 1.20f, 0.0f, 0.30f, 0.30f, 0.30f, skin);            // head
    add_box(-0.07f, 1.32f, 0.152f, 0.05f, 0.05f, 0.02f, dark);        // eyes
    add_box( 0.07f, 1.32f, 0.152f, 0.05f, 0.05f, 0.02f, dark);
    add_box(0.0f, 1.48f, -0.02f, 0.42f, 0.12f, 0.40f, hood);          // hood top
    add_box(0.0f, 1.18f, -0.12f, 0.42f, 0.34f, 0.18f, hood);          // hood back
    add_box(-0.21f, 1.18f, 0.03f, 0.06f, 0.34f, 0.32f, hood);         // hood sides
    add_box( 0.21f, 1.18f, 0.03f, 0.06f, 0.34f, 0.32f, hood);
    add_collider(NPC_X, NPC_Z, 0.5f);
}

// The beacon crystal (spins and bobs above the pedestal).
static void build_gem(void) {
    cur = &gem_mesh;
    add_octahedron(0.0f, 0.0f, 0.0f, 0.6f, C(0.25f, 0.85f, 0.95f), C(0.85f, 0.30f, 0.90f));
}

// ----------------------------------------------------------- inventory ----

typedef enum { ITEM_SWORD = 0, ITEM_MACE = 1, ITEM_SPEAR = 2, ITEM_COUNT } ItemId;

// Damage tags. Enemies can be weak to or resist each of these.
typedef enum { DMG_SLASH = 0, DMG_BLUNT = 1, DMG_PIERCE = 2, DMG_TYPE_COUNT } DamageType;
static const char *const dmg_type_names[DMG_TYPE_COUNT] = { "SLASHING", "BLUNT", "PIERCING" };
static const char *const dmg_type_short[DMG_TYPE_COUNT] = { "SLASH", "BLUNT", "PIERCE" };

// Weapon pose offsets (added to the resting view model) used by swing animations.
//   dx/dy/dz: hand movement (camera space)   ry: yaw about the vertical axis (+ = toward the left)
//   rz: roll/lean on screen                  rx: pitch (- = tip tilts away from you)
typedef struct { float dx, dy, dz, rz, rx, ry; } Pose;
enum { EASE_SMOOTH = 0, EASE_IN, EASE_OUT, EASE_LINEAR };
#define SWING_MAX_KEYS 8
// Keyframes: t runs 0..1 over the swing; ease[i] shapes the segment from key i to key i+1.
typedef struct { int n; float t[SWING_MAX_KEYS]; unsigned char ease[SWING_MAX_KEYS]; Pose p[SWING_MAX_KEYS]; } Swing;

// Sword: a flat horizontal slice. The blade is held pointing forward-left with the flat of the
// blade parallel to the ground, then whipped across the screen to the right, edge leading.
static const Swing sword_swing = {
    6,
    {0.00f, 0.32f, 0.46f, 0.60f, 0.74f, 1.00f},
    {EASE_SMOOTH, EASE_IN, EASE_OUT, EASE_SMOOTH, EASE_SMOOTH, EASE_SMOOTH},
    {
        { 0.00f,  0.00f,  0.00f,   0.0f,   0.0f,   0.0f},   // rest
        {-0.55f,  0.04f,  0.00f,  40.0f, -60.0f,  74.0f},   // wind-up: blade out flat across the screen to the left, wrist cocked
        {-0.30f,  0.00f, -0.22f,   0.0f, -62.0f,  10.0f},   // mid slice: wrist rolls through as it sweeps the centre
        {-0.05f, -0.04f, -0.10f, -40.0f, -60.0f, -56.0f},   // end of the slice: blade across the screen to the right
        { 0.02f, -0.06f, -0.08f, -44.0f, -56.0f, -62.0f},   // follow-through
        { 0.00f,  0.00f,  0.00f,   0.0f,   0.0f,   0.0f},   // back to rest
    }
};

// Mace: overhead hammer blow, top to bottom.
static const Swing mace_swing = {
    5,
    {0.00f, 0.34f, 0.56f, 0.68f, 1.00f},
    {EASE_SMOOTH, EASE_SMOOTH, EASE_SMOOTH, EASE_SMOOTH, EASE_SMOOTH},
    {
        { 0.00f,  0.00f,  0.00f,   0.0f,   0.0f,  0.0f},   // rest
        {-0.05f,  0.48f,  0.06f,  -2.0f,  24.0f,  0.0f},   // wind-up: hoisted high
        {-0.05f, -0.22f, -0.24f,   0.0f, -92.0f,  0.0f},   // slam: down and forward
        {-0.05f, -0.26f, -0.26f,   0.0f, -100.0f, 0.0f},   // impact
        { 0.00f,  0.00f,  0.00f,   0.0f,   0.0f,  0.0f},   // back to rest
    }
};

// Spear: drawn back, then thrust straight ahead.
static const Swing spear_swing = {
    5,
    {0.00f, 0.32f, 0.46f, 0.60f, 1.00f},
    {EASE_SMOOTH, EASE_OUT, EASE_SMOOTH, EASE_SMOOTH, EASE_SMOOTH},
    {
        { 0.00f,  0.00f,  0.00f,   0.0f,   0.0f,  0.0f},   // rest
        { 0.12f, -0.10f,  0.16f,   0.0f,   8.0f, -4.0f},   // wind-up: pulled back
        {-0.26f,  0.04f, -0.72f,   0.0f, -20.0f, 10.0f},   // thrust: stabbed forward at the centre
        {-0.24f,  0.04f, -0.66f,   0.0f, -18.0f,  9.0f},   // hold
        { 0.00f,  0.00f,  0.00f,   0.0f,   0.0f,  0.0f},   // back to rest
    }
};

typedef struct {
    const char *name;
    const char *desc;
    Mesh *mesh;
    DamageType dmg_type;
    float damage;
    float swing_time, stamina_cost, range, arc_deg, hit_start, hit_end;
    const Swing *swing;
    Pose hold;                      // how it is held at rest (added to the default view model)
    float preview_scale, preview_cy;   // size and centre (along the shaft) for the equipment screen
} ItemDef;

static const ItemDef item_defs[ITEM_COUNT] = {
    [ITEM_SWORD] = { "IRON SWORD", "A PLAIN BLADE. STILL SHARP.", &sword_mesh,
      DMG_SLASH, SWORD_DAMAGE, SWORD_SWING_TIME, SWORD_STAMINA_COST, SWORD_RANGE, SWORD_ARC_DEG,
      SWORD_HIT_START, SWORD_HIT_END, &sword_swing, {0}, 1.15f, 0.31f },
    [ITEM_MACE] = { "STONE MACE", "HEAVY AND BLUNT. SHATTERS WHAT SWORDS CANNOT.", &mace_mesh,
      DMG_BLUNT, MACE_DAMAGE, MACE_SWING_TIME, MACE_STAMINA_COST, MACE_RANGE, MACE_ARC_DEG,
      MACE_HIT_START, MACE_HIT_END, &mace_swing, {0}, 1.5f, 0.22f },
    [ITEM_SPEAR] = { "IRON SPEAR", "A LONG REACH. THRUSTS FORWARD.", &spear_mesh,
      DMG_PIERCE, SPEAR_DAMAGE, SPEAR_SWING_TIME, SPEAR_STAMINA_COST, SPEAR_RANGE, SPEAR_ARC_DEG,
      SPEAR_HIT_START, SPEAR_HIT_END, &spear_swing, { -0.06f, -0.02f, 0.0f, 0.0f, -48.0f, 10.0f }, 0.58f, 0.80f },
};

#define INV_MAX 8
static int inv[INV_MAX];          // item ids
static int inv_n = 0;
#define QUICK_SLOTS 3
static int quick[QUICK_SLOTS] = { -1, -1, -1 };   // the three equipped weapons (item ids, -1 = empty)
static int active_quick = 0;                       // which of them is in hand
static float swap_t = -1.0f;                       // weapon-swap animation timer, -1 = idle
static int   swap_to = 0, swap_done = 0;
static int equipped_id(void) { return quick[active_quick]; }
typedef enum { MENU_NONE = 0, MENU_INVENTORY, MENU_PAUSE, MENU_BESTIARY, MENU_BEACON, MENU_DIALOGUE, MENU_STATS } MenuId;
static int menu = MENU_NONE;
static int pause_sel = 0, bestiary_sel = 0, beacon_sel = 0, stats_sel = 0, menu_return = MENU_BEACON;
static int pend[3];   // attribute points chosen in the level-up screen but not yet confirmed
static int inv_sel = 0;           // equipment screen: cursor in the item list (0 = EMPTY)
static int eq_focus = 0, eq_slot = 0;   // equipment screen: 0 = choosing a slot, 1 = choosing an item

// ---- player state ----
static float player_max_hp = MAX_HEALTH,  player_hp = MAX_HEALTH;
static float player_max_stam = MAX_STAMINA, player_stam = MAX_STAMINA;
static float stam_delay = 0.0f;                       // time until stamina regen resumes
static float dodge_t = -1.0f;                         // seconds into a dodge, -1 = idle
static float dodge_vx = 0.0f, dodge_vz = 0.0f, dodge_side = 0.0f;
static float attack_t = -1.0f;                        // seconds into a swing, -1 = idle
static unsigned attack_hit_mask = 0;                  // which targets this swing already hit
static float dummy_wobble = -1.0f;                    // seconds since dummy was hit, -1 = still
static float dummy_hit_amp = 0.0f;
static DamageType dummy_hit_type = DMG_SLASH;
static int   dummy_hits = 0;

static void use_stamina(float cost) {
    player_stam -= cost;
    if (player_stam <= 0.0f) { player_stam = 0.0f; stam_delay = STAMINA_EXHAUST_DELAY; }
    else                     { stam_delay = STAMINA_REGEN_DELAY; }
}

// Put item `id` (or -1 for nothing) into weapon slot `slot`. A weapon can only sit in one slot,
// so equipping one that is already elsewhere swaps the two.
static void equip_item(int slot, int id) {
    if (id >= 0) {
        for (int j = 0; j < QUICK_SLOTS; j++)
            if (j != slot && quick[j] == id) quick[j] = quick[slot];
    }
    quick[slot] = id;
    attack_t = -1.0f;
}

// Equipment screen: which item is being looked at (-1 = none). While choosing from the list it is
// the highlighted entry, otherwise whatever sits in the selected weapon slot.
#define EQ_PREVIEW_X  652.0f
#define EQ_PREVIEW_Y   80.0f
#define EQ_PREVIEW_W  280.0f
#define EQ_PREVIEW_H  130.0f
static int eq_shown_item(void) {
    if (eq_focus) return inv_sel > 0 && inv_sel <= inv_n ? inv[inv_sel - 1] : -1;
    return quick[eq_slot];
}

static float smooth01(float u) {
    if (u < 0.0f) u = 0.0f;
    if (u > 1.0f) u = 1.0f;
    return u * u * (3.0f - 2.0f * u);
}

static Pose swing_pose(const Swing *sw, float u) {
    if (u <= 0.0f) return sw->p[0];
    if (u >= 1.0f) return sw->p[sw->n - 1];
    int i = 0;
    while (i < sw->n - 2 && u > sw->t[i + 1]) i++;
    float f = (u - sw->t[i]) / (sw->t[i + 1] - sw->t[i]);
    switch (sw->ease[i]) {
    case EASE_IN:     f = f * f; break;
    case EASE_OUT:    f = 1.0f - (1.0f - f) * (1.0f - f); break;
    case EASE_LINEAR: break;
    default:          f = smooth01(f); break;
    }
    Pose a = sw->p[i], b = sw->p[i + 1], r;
    r.dx = a.dx + (b.dx - a.dx) * f;
    r.dy = a.dy + (b.dy - a.dy) * f;
    r.dz = a.dz + (b.dz - a.dz) * f;
    r.rz = a.rz + (b.rz - a.rz) * f;
    r.rx = a.rx + (b.rx - a.rx) * f;
    r.ry = a.ry + (b.ry - a.ry) * f;
    return r;
}

typedef struct { float x, z; int item; int taken; } Pickup;
static Pickup pickups[] = {
    { -2.5f, 2.5f, ITEM_SWORD, 0 },
    {  7.0f, -1.5f, ITEM_MACE, 0 },
    { -5.5f, -2.5f, ITEM_SPEAR, 0 },
};
#define NUM_PICKUPS ((int)(sizeof(pickups) / sizeof(pickups[0])))
#define PICKUP_RANGE 2.2f

// ------------------------------------------------------------ enemies ----

typedef enum { ENEMY_RAT = 0, ENEMY_CRAB, ENEMY_TYPE_COUNT } EnemyType;

typedef struct {
    const char *name;
    const char *desc[2];            // two short lines for the bestiary
    Mesh *mesh;
    float max_hp;
    float resist[DMG_TYPE_COUNT];   // damage multiplier per damage tag: 1 neutral, >1 weak, <1 resistant
    float bar_height;               // world height of the health bar above the ground
    float radius;
    float scale;
    int xp;                         // xp granted when killed
    // behaviour
    int   hops;                     // 1 = moves in hops (rat), 0 = walks
    int   wanders;                  // 1 = strolls around its spawn point while idle
    float aggro_range, move_speed, wander_speed, hop_time;
    float attack_range, windup, lunge_time, lunge_speed, recover, stagger, damage, hit_radius;
    // bestiary preview
    float preview_scale, preview_cy, preview_cz;
} EnemyDef;

static const EnemyDef enemy_defs[ENEMY_TYPE_COUNT] = {
    [ENEMY_RAT] = {
        .name = "GIANT RAT",
        .desc = { "A BLOCKY SEWER PEST THAT HOPS CLOSER.", "WATCH FOR THE CROUCH - THEN THE LUNGE." },
        .mesh = &rat_mesh, .max_hp = RAT_HEALTH,
        .resist = { RAT_RESIST_SLASH, RAT_RESIST_BLUNT, RAT_RESIST_PIERCE },
        .bar_height = 0.95f, .radius = RAT_RADIUS, .scale = RAT_SCALE, .xp = RAT_XP,
        .hops = 1, .wanders = 0,
        .aggro_range = RAT_AGGRO_RANGE, .move_speed = RAT_HOP_SPEED, .wander_speed = 0.0f, .hop_time = RAT_HOP_TIME,
        .attack_range = RAT_ATTACK_RANGE, .windup = RAT_WINDUP_TIME, .lunge_time = RAT_LUNGE_TIME,
        .lunge_speed = RAT_LUNGE_SPEED, .recover = RAT_RECOVER_TIME, .stagger = RAT_STAGGER_TIME,
        .damage = RAT_DAMAGE, .hit_radius = RAT_HIT_RADIUS,
        .preview_scale = 0.85f, .preview_cy = 0.15f, .preview_cz = -0.12f,
    },
    [ENEMY_CRAB] = {
        .name = "ROCK CRAB",
        .desc = { "A CRAB CARVED FROM LIVING STONE.", "BLADES GLANCE OFF. USE BLUNT FORCE." },
        .mesh = &crab_mesh, .max_hp = CRAB_HEALTH,
        .resist = { CRAB_RESIST_SLASH, CRAB_RESIST_BLUNT, CRAB_RESIST_PIERCE },
        .bar_height = 1.45f, .radius = CRAB_RADIUS, .scale = CRAB_SCALE, .xp = CRAB_XP,
        .hops = 0, .wanders = 1,
        .aggro_range = CRAB_AGGRO_RANGE, .move_speed = CRAB_SPEED, .wander_speed = CRAB_WANDER_SPEED, .hop_time = 0.55f,
        .attack_range = CRAB_ATTACK_RANGE, .windup = CRAB_WINDUP_TIME, .lunge_time = CRAB_LUNGE_TIME,
        .lunge_speed = CRAB_LUNGE_SPEED, .recover = CRAB_RECOVER_TIME, .stagger = CRAB_STAGGER_TIME,
        .damage = CRAB_DAMAGE, .hit_radius = CRAB_HIT_RADIUS,
        .preview_scale = 0.78f, .preview_cy = 0.30f, .preview_cz = 0.15f,
    },
};

typedef enum { E_IDLE = 0, E_CHASE, E_WINDUP, E_LUNGE, E_RECOVER, E_STAGGER, E_DEAD } EnemyState;

typedef struct {
    int type;
    float spawn_x, spawn_z, spawn_yaw;
    float x, z, yaw, hp;
    int state;
    float state_t, hop;
    float lunge_x, lunge_z;
    int lunge_hit;
    float kb_x, kb_z;
    float wx, wz, wait;     // wandering: current target and pause timer
    int walking;            // moved this frame (drives the walk animation)
} Enemy;

static Enemy enemies[] = {
    { .type = ENEMY_RAT,  .spawn_x = 22.5f, .spawn_z = 0.0f, .spawn_yaw = -PI_F / 2.0f },
    { .type = ENEMY_CRAB, .spawn_x = 31.5f, .spawn_z = 1.0f, .spawn_yaw = PI_F },
};
#define NUM_ENEMIES ((int)(sizeof(enemies) / sizeof(enemies[0])))

static int bestiary_seen[ENEMY_TYPE_COUNT];

// ---- NPC dialogue (Dark Souls style: a box at the bottom, text typed out in chunks) ----
// The progress lives in these globals only: resting, dying (and, later, loading a save)
// never touch them, so once he's said his piece he only ever repeats the short line.
static const char *const npc_lines[] = {
    "Who me? I don't know what I'm doing here.",
    "What are you doing here? You don't know either?",
    "Well, this is a test room buddy.",
    "There's a rat behind the door.",
    "Go on, kill it.",
};
#define NPC_LINES ((int)(sizeof(npc_lines) / sizeof(npc_lines[0])))
static const char *const npc_repeat = "Go on buddy, get in there.";
static int   npc_line = 0;        // which chunk he's on
static int   npc_done = 0;        // 1 once the whole speech has been heard
static float dlg_chars = 0.0f;    // characters of the current chunk shown so far
static float npc_yaw = NPC_REST_YAW;
static float g_time = 0.0f;       // seconds since start (for blinking HUD bits)

static const char *npc_text(void) { return npc_done ? npc_repeat : npc_lines[npc_line]; }

// X pressed during dialogue: finish typing, else go to the next chunk. Returns 1 to close the box.
static int npc_advance(void) {
    int len = (int)strlen(npc_text());
    if (dlg_chars < (float)len) { dlg_chars = (float)len; return 0; }
    if (npc_done) return 1;
    if (npc_line + 1 < NPC_LINES) { npc_line++; dlg_chars = 0.0f; return 0; }
    npc_done = 1;
    return 1;
}

// ---- player survival state ----
static int   player_dead = 0;
static float death_t = 0.0f;
static float hurt_flash = 0.0f;

// ---- camera (set each frame; used to project things onto the HUD) ----
static float g_cam_x = 0, g_cam_z = 0, g_cam_eye = 0, g_cam_yaw = 0, g_cam_pitch = 0, g_cam_roll = 0;

// 0 = outside, 1 = the rat room, 2 = the crab room (thresholds sit on the wall centres so that
// standing in a doorway is never "outside").
static int room_of(float x, float z) {
    if (z > ROOM_Z0 && z < ROOM_Z1) {
        if (x > ROOM2_X1) return 0;
        if (x > ROOM_X1) return 2;
        if (x > ROOM_X0) return 1;
    }
    return 0;
}

// Can something in room a see into room b? Same room, or neighbours with the door between open.
static int can_see(int a, int b) {
    if (a == b) return 1;
    if (a - b == 1 || b - a == 1) return doors[a < b ? a : b].open_t > 0.5f;
    return 0;
}

static void damage_player(float amount) {
    if (player_dead) return;
    if (dodge_t >= 0.0f && dodge_t < DODGE_TIME * DODGE_IFRAME_FRAC) return;   // dodge i-frames
    player_hp -= amount;
    hurt_flash = 0.4f;
    if (player_hp <= 0.0f) { player_hp = 0.0f; player_dead = 1; death_t = 0.0f; }
}

// World point -> screen pixels (same maths as the GL view + projection). 0 if behind the camera.
static int project_point(float wx, float wy, float wz, float *sx, float *sy) {
    float x = wx - g_cam_x, y = wy - g_cam_eye, z = wz - g_cam_z;
    float x1 = x * cosf(g_cam_yaw) - z * sinf(g_cam_yaw);
    float z1 = x * sinf(g_cam_yaw) + z * cosf(g_cam_yaw);
    float y2 = y * cosf(g_cam_pitch) + z1 * sinf(g_cam_pitch);
    float z2 = -y * sinf(g_cam_pitch) + z1 * cosf(g_cam_pitch);
    float x3 = x1 * cosf(g_cam_roll) - y2 * sinf(g_cam_roll);
    float y3 = x1 * sinf(g_cam_roll) + y2 * cosf(g_cam_roll);
    if (z2 > -0.2f) return 0;
    const float tv = 0.70020753f;   // tan(35 degrees)
    *sx = (x3 / (-z2 * tv * (960.0f / 544.0f)) + 1.0f) * 0.5f * 960.0f;
    *sy = (1.0f - y3 / (-z2 * tv)) * 0.5f * 544.0f;
    return 1;
}

static void reset_enemies(void) {
    for (int i = 0; i < NUM_ENEMIES; i++) {
        Enemy *e = &enemies[i];
        e->x = e->spawn_x;
        e->z = e->spawn_z;
        e->yaw = e->spawn_yaw;
        e->hp = enemy_defs[e->type].max_hp;
        e->state = E_IDLE;
        e->state_t = 0.0f;
        e->hop = 0.0f;
        e->lunge_hit = 0;
        e->kb_x = e->kb_z = 0.0f;
        e->wx = e->spawn_x; e->wz = e->spawn_z; e->wait = 0.5f + 0.7f * (float)i;
        e->walking = 0;
    }
}

// ---------------------------------------------------- xp / attributes ----
// Killing things gives XP. XP stays in your pocket until you spend it on a level at a beacon
// (and dying doesn't take it away). Each level you buy raises Health, Stamina or Strength.

static int xp = 0;               // XP you are carrying
static int lv_hp = 0, lv_stam = 0, lv_str = 0;
static float play_time = 0.0f;   // seconds, shown on the save slots
static float xp_shown = 0.0f;    // the number on the HUD counter (counts up/down smoothly)
static float xp_pop = 0.0f;      // XP just gained, shown as "+N" until it merges into the counter
static float xp_pop_t = 0.0f;    // seconds until the "+N" starts merging

static int player_level(void) { return 1 + lv_hp + lv_stam + lv_str; }
static int level_cost(int level) { return XP_BASE + XP_STEP * (level - 1); }   // XP to go from `level` to level + 1
static int levels_cost(int from_level, int n) {
    int c = 0;
    for (int k = 0; k < n; k++) c += level_cost(from_level + k);
    return c;
}
static float str_mult(void) { return 1.0f + STR_BONUS * (float)lv_str; }
static float weapon_damage(const ItemDef *d) { return d->damage * str_mult(); }

static void recompute_stats(void) {
    player_max_hp   = MAX_HEALTH  + HP_PER_LEVEL   * (float)lv_hp;
    player_max_stam = MAX_STAMINA + STAM_PER_LEVEL * (float)lv_stam;
}

static void give_xp(int amount) {
    xp += amount;
    xp_pop += (float)amount;
    xp_pop_t = XP_POP_DELAY;
}

// Dark Souls style counter: "+N" sits beside the total, then pours into it.
static void update_xp_display(float dt) {
    if (xp_pop > 0.01f) {
        if (xp_pop_t > 0.0f) {
            xp_pop_t -= dt;
        } else {
            float rate = fmaxf(12.0f, xp_pop * 3.0f);
            float step = fminf(xp_pop, rate * dt);
            xp_pop -= step;
            xp_shown += step;
            if (xp_pop <= 0.01f) { xp_pop = 0.0f; xp_shown = (float)xp; }
        }
    } else {
        xp_pop = 0.0f;
        float diff = (float)xp - xp_shown;
        if (fabsf(diff) < 0.5f) xp_shown = (float)xp;
        else xp_shown += diff * fminf(1.0f, 10.0f * dt);
    }
}

// Buys h + s + st levels (Health / Stamina / Strength) if you can afford them. Returns 1 on success.
static int commit_levels(int h, int s, int st) {
    int n = h + s + st;
    if (n <= 0) return 0;
    int cost = levels_cost(player_level(), n);
    if (cost > xp) return 0;
    float oh = player_max_hp, os = player_max_stam;
    xp -= cost;
    lv_hp += h; lv_stam += s; lv_str += st;
    recompute_stats();
    player_hp   += player_max_hp   - oh;   // the new capacity arrives full
    player_stam += player_max_stam - os;
    return 1;
}

// Resting at the beacon: heals you, respawns enemies, shuts the door. Items are kept.
static void do_rest(void) {
    player_hp = player_max_hp;
    player_stam = player_max_stam;
    stam_delay = 0.0f;
    dodge_t = -1.0f;
    attack_t = -1.0f;
    dummy_wobble = -1.0f;
    reset_enemies();
    for (int i = 0; i < NUM_DOORS; i++) doors[i].target = 0;   // the doors swing shut again
}

// ------------------------------------------------------------ saving ----
typedef enum { SCREEN_TITLE = 0, SCREEN_GAME } ScreenId;
static int screen = SCREEN_TITLE;
static int title_sel = 0, title_confirm = 0, cur_slot = 0;

#define SAVE_MAGIC 0x33574C50u   // "PLW3"
typedef struct {
    unsigned magic;
    int xp, lv_hp, lv_stam, lv_str;
    int inv_n, inv[INV_MAX], quick[QUICK_SLOTS], active_quick;
    int pickup_taken[16];
    int npc_done, npc_line;      // the wanderer's dialogue is part of the save
    int bestiary_seen[8];
    float play_time;
} SaveData;
_Static_assert(sizeof(pickups) / sizeof(pickups[0]) <= 16, "save: too many pickups");
_Static_assert(ENEMY_TYPE_COUNT <= 8, "save: too many enemy types");

static SaveData slot_info[NUM_SLOTS];
static int      slot_ok[NUM_SLOTS];

static void save_path(int slot, char *buf, size_t n) { snprintf(buf, n, SAVE_DIR "/save%d.dat", slot + 1); }

static int read_save(int slot, SaveData *out) {
    char path[128];
    save_path(slot, path, sizeof(path));
    FILE *f = fopen(path, "rb");
    if (!f) return 0;
    int ok = fread(out, sizeof(*out), 1, f) == 1 && out->magic == SAVE_MAGIC;
    fclose(f);
    return ok;
}

static int write_save(int slot) {
    SaveData d;
    memset(&d, 0, sizeof(d));
    d.magic = SAVE_MAGIC;
    d.xp = xp;
    d.lv_hp = lv_hp; d.lv_stam = lv_stam; d.lv_str = lv_str;
    d.inv_n = inv_n;
    for (int i = 0; i < INV_MAX; i++) d.inv[i] = inv[i];
    for (int i = 0; i < QUICK_SLOTS; i++) d.quick[i] = quick[i];
    d.active_quick = active_quick;
    for (int i = 0; i < NUM_PICKUPS; i++) d.pickup_taken[i] = pickups[i].taken;
    d.npc_done = npc_done; d.npc_line = npc_line;
    for (int i = 0; i < ENEMY_TYPE_COUNT; i++) d.bestiary_seen[i] = bestiary_seen[i];
    d.play_time = play_time;

    mkdir(SAVE_DIR, 0777);
    char path[128];
    save_path(slot, path, sizeof(path));
    FILE *f = fopen(path, "wb");
    if (!f) return 0;
    int ok = fwrite(&d, sizeof(d), 1, f) == 1;
    if (fflush(f) != 0) ok = 0;
    if (fclose(f) != 0) ok = 0;   // make sure it is really on the memory card
    if (ok) { slot_info[slot] = d; slot_ok[slot] = 1; }
    return ok;
}

static void delete_save(int slot) {
    char path[128];
    save_path(slot, path, sizeof(path));
    remove(path);
    slot_ok[slot] = 0;
}

static void refresh_slots(void) {
    for (int i = 0; i < NUM_SLOTS; i++) slot_ok[i] = read_save(i, &slot_info[i]);
}

static void new_game_state(void) {
    xp = 0; xp_shown = 0.0f; xp_pop = 0.0f; xp_pop_t = 0.0f;
    lv_hp = lv_stam = lv_str = 0;
    play_time = 0.0f;
    inv_n = 0; inv_sel = 0;
    for (int i = 0; i < QUICK_SLOTS; i++) quick[i] = -1;
    active_quick = 0; swap_t = -1.0f;
    for (int i = 0; i < NUM_PICKUPS; i++) pickups[i].taken = 0;
    npc_done = 0; npc_line = 0; dlg_chars = 0.0f;
    for (int i = 0; i < ENEMY_TYPE_COUNT; i++) bestiary_seen[i] = 0;
    dummy_hits = 0;
    player_dead = 0; hurt_flash = 0.0f;
    recompute_stats();
    do_rest();
    for (int i = 0; i < NUM_DOORS; i++) doors[i].open_t = 0.0f;
    menu = MENU_NONE;
}

static void apply_save(const SaveData *d) {
    new_game_state();
    xp = d->xp; xp_shown = (float)xp;
    lv_hp = d->lv_hp; lv_stam = d->lv_stam; lv_str = d->lv_str;
    inv_n = d->inv_n < 0 ? 0 : (d->inv_n > INV_MAX ? INV_MAX : d->inv_n);
    for (int i = 0; i < inv_n; i++) inv[i] = (d->inv[i] >= 0 && d->inv[i] < ITEM_COUNT) ? d->inv[i] : 0;
    for (int i = 0; i < QUICK_SLOTS; i++) {   // only keep weapons you actually own
        int id = d->quick[i], owned = 0;
        for (int k = 0; k < inv_n; k++) if (inv[k] == id) owned = 1;
        quick[i] = (id >= 0 && id < ITEM_COUNT && owned) ? id : -1;
    }
    active_quick = (d->active_quick >= 0 && d->active_quick < QUICK_SLOTS) ? d->active_quick : 0;
    for (int i = 0; i < NUM_PICKUPS; i++) pickups[i].taken = d->pickup_taken[i];
    npc_done = d->npc_done ? 1 : 0;
    npc_line = (d->npc_line >= 0 && d->npc_line < NPC_LINES) ? d->npc_line : 0;
    for (int i = 0; i < ENEMY_TYPE_COUNT; i++) bestiary_seen[i] = d->bestiary_seen[i];
    play_time = d->play_time;
    recompute_stats();
    do_rest();   // full health, enemies back, doors shut
    for (int i = 0; i < NUM_DOORS; i++) doors[i].open_t = 0.0f;
}

// Apply a weapon hit to an enemy. Returns the damage dealt.
static float hit_enemy(Enemy *e, const ItemDef *wd, float px, float pz) {
    const EnemyDef *d = &enemy_defs[e->type];
    float dmg = weapon_damage(wd) * d->resist[wd->dmg_type];
    e->hp -= dmg;
    bestiary_seen[e->type] = 1;
    float dx = e->x - px, dz = e->z - pz, l = sqrtf(dx * dx + dz * dz);
    if (l > 1e-4f) { e->kb_x = dx / l; e->kb_z = dz / l; }
    e->state_t = 0.0f;
    if (e->hp <= 0.0f) { e->hp = 0.0f; e->state = E_DEAD; }
    else               { e->state = E_STAGGER; }   // a hit interrupts whatever it was doing
    return dmg;
}

static unsigned rng_state = 2463534242u;
static float rnd01(void) {   // tiny xorshift, 0..1
    rng_state ^= rng_state << 13; rng_state ^= rng_state >> 17; rng_state ^= rng_state << 5;
    return (float)(rng_state & 0xFFFFFF) / 16777216.0f;
}

// Turn `yaw` toward `target` by at most `rate * dt` radians.
static void turn_toward(float *yaw, float target, float maxstep) {
    float diff = target - *yaw;
    while (diff >  PI_F) diff -= 2.0f * PI_F;
    while (diff < -PI_F) diff += 2.0f * PI_F;
    if (diff >  maxstep) diff =  maxstep;
    if (diff < -maxstep) diff = -maxstep;
    *yaw += diff;
}

static void update_enemy(Enemy *e, float dt, float px, float pz) {
    const EnemyDef *d = &enemy_defs[e->type];
    float dx = px - e->x, dz = pz - e->z;
    float dist = sqrtf(dx * dx + dz * dz);
    int er = room_of(e->x, e->z), pr = room_of(px, pz);
    int same = (er == pr);
    e->state_t += dt;
    e->walking = 0;

    switch (e->state) {
    case E_IDLE:
        // Wakes up when you're close and it can see you (same room, or the door between is open).
        if (!player_dead && dist < d->aggro_range && can_see(er, pr)) {
            e->state = E_CHASE;
            e->state_t = 0.0f;
            e->hop = 0.0f;
            bestiary_seen[e->type] = 1;
        } else if (d->wanders) {
            // Stroll to a random spot near home, pause, repeat.
            if (e->wait > 0.0f) {
                e->wait -= dt;
            } else {
                float wx = e->wx - e->x, wz = e->wz - e->z, wd = sqrtf(wx * wx + wz * wz);
                if (wd < 0.35f) {
                    e->wait = 1.0f + rnd01() * 2.0f;
                    e->wx = e->spawn_x + (rnd01() * 2.0f - 1.0f) * 3.2f;
                    e->wz = e->spawn_z + (rnd01() * 2.0f - 1.0f) * 2.8f;
                } else {
                    turn_toward(&e->yaw, atan2f(wx, wz), 3.0f * dt);
                    e->x += wx / wd * d->wander_speed * dt;
                    e->z += wz / wd * d->wander_speed * dt;
                    e->walking = 1;
                    e->hop += dt / d->hop_time;
                    if (e->state_t > 12.0f) { e->wx = e->x; e->wz = e->z; }   // stuck on something: give up this target
                }
            }
        }
        break;

    case E_CHASE: {
        // If you're in another room it heads for the doorway between you first.
        float tx = px, tz = pz;
        if (!same) {
            if (er < pr) { tx = doors[er].x + 0.6f;     tz = 0.0f; }
            else         { tx = doors[er - 1].x - 0.6f; tz = 0.0f; }
        }
        float wx = tx - e->x, wz = tz - e->z, wd = sqrtf(wx * wx + wz * wz);
        if (wd > 1e-4f) {
            if (d->hops) e->yaw = atan2f(wx, wz);
            else         turn_toward(&e->yaw, atan2f(wx, wz), 5.0f * dt);
        }
        if (d->hops) {
            e->hop += dt / d->hop_time;
            float f = e->hop - floorf(e->hop);
            if (f < 0.65f && wd > 0.6f) {   // moves only while airborne: hop, hop, hop
                e->x += wx / wd * d->move_speed * dt;
                e->z += wz / wd * d->move_speed * dt;
                e->walking = 1;
            }
        } else if (wd > 0.6f) {
            e->x += wx / wd * d->move_speed * dt;
            e->z += wz / wd * d->move_speed * dt;
            e->walking = 1;
            e->hop += dt / d->hop_time;
        }
        if (same && dist < d->attack_range) {
            e->state = E_WINDUP;
            e->state_t = 0.0f;
        } else if (dist > 16.0f || player_dead) {
            e->state = E_IDLE;
            e->state_t = 0.0f;
        }
        break;
    }

    case E_WINDUP:   // telegraphs, tracks you, then commits to a direction
        if (e->state_t < d->windup * 0.6f && dist > 1e-4f) e->yaw = atan2f(dx, dz);
        if (e->state_t >= d->windup) {
            e->lunge_x = sinf(e->yaw);
            e->lunge_z = cosf(e->yaw);
            e->lunge_hit = 0;
            e->state = E_LUNGE;
            e->state_t = 0.0f;
        }
        break;

    case E_LUNGE:    // straight-line dash: side-step it with a dodge
        e->x += e->lunge_x * d->lunge_speed * dt;
        e->z += e->lunge_z * d->lunge_speed * dt;
        if (!e->lunge_hit && dist < d->hit_radius) {
            e->lunge_hit = 1;
            damage_player(d->damage);
        }
        if (e->state_t >= d->lunge_time) { e->state = E_RECOVER; e->state_t = 0.0f; }
        break;

    case E_RECOVER:  // open for a counter-attack
        if (e->state_t >= d->recover) { e->state = E_CHASE; e->state_t = 0.0f; e->hop = 0.0f; }
        break;

    case E_STAGGER: {
        float k = 3.5f * (1.0f - e->state_t / d->stagger);
        if (k < 0.0f) k = 0.0f;
        e->x += e->kb_x * k * dt;
        e->z += e->kb_z * k * dt;
        if (e->state_t >= d->stagger) { e->state = E_CHASE; e->state_t = 0.0f; e->hop = 0.0f; }
        break;
    }

    case E_DEAD:
        break;
    }

    if (e->state != E_DEAD) {
        float lim = WORLD_HALF - 0.5f;
        if (e->x >  lim) e->x =  lim;
        if (e->x < -lim) e->x = -lim;
        if (e->z >  lim) e->z =  lim;
        if (e->z < -lim) e->z = -lim;
        resolve_collisions(&e->x, &e->z, d->radius);
    }
}

// ----------------------------------------------------------- HUD / font ----
// Tiny built-in 5x7 bitmap font (uppercase, digits, a few symbols).

#define FONT_CHARS " ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-.:>[]/!?,'+%"

static const unsigned char font[][7] = {
    {0, 0, 0, 0, 0, 0, 0},                                                           // space
    {0b01110, 0b10001, 0b10001, 0b11111, 0b10001, 0b10001, 0b10001},                 // A
    {0b11110, 0b10001, 0b10001, 0b11110, 0b10001, 0b10001, 0b11110},                 // B
    {0b01110, 0b10001, 0b10000, 0b10000, 0b10000, 0b10001, 0b01110},                 // C
    {0b11110, 0b10001, 0b10001, 0b10001, 0b10001, 0b10001, 0b11110},                 // D
    {0b11111, 0b10000, 0b10000, 0b11110, 0b10000, 0b10000, 0b11111},                 // E
    {0b11111, 0b10000, 0b10000, 0b11110, 0b10000, 0b10000, 0b10000},                 // F
    {0b01110, 0b10001, 0b10000, 0b10111, 0b10001, 0b10001, 0b01111},                 // G
    {0b10001, 0b10001, 0b10001, 0b11111, 0b10001, 0b10001, 0b10001},                 // H
    {0b01110, 0b00100, 0b00100, 0b00100, 0b00100, 0b00100, 0b01110},                 // I
    {0b00111, 0b00010, 0b00010, 0b00010, 0b00010, 0b10010, 0b01100},                 // J
    {0b10001, 0b10010, 0b10100, 0b11000, 0b10100, 0b10010, 0b10001},                 // K
    {0b10000, 0b10000, 0b10000, 0b10000, 0b10000, 0b10000, 0b11111},                 // L
    {0b10001, 0b11011, 0b10101, 0b10101, 0b10001, 0b10001, 0b10001},                 // M
    {0b10001, 0b11001, 0b10101, 0b10011, 0b10001, 0b10001, 0b10001},                 // N
    {0b01110, 0b10001, 0b10001, 0b10001, 0b10001, 0b10001, 0b01110},                 // O
    {0b11110, 0b10001, 0b10001, 0b11110, 0b10000, 0b10000, 0b10000},                 // P
    {0b01110, 0b10001, 0b10001, 0b10001, 0b10101, 0b10010, 0b01101},                 // Q
    {0b11110, 0b10001, 0b10001, 0b11110, 0b10100, 0b10010, 0b10001},                 // R
    {0b01111, 0b10000, 0b10000, 0b01110, 0b00001, 0b00001, 0b11110},                 // S
    {0b11111, 0b00100, 0b00100, 0b00100, 0b00100, 0b00100, 0b00100},                 // T
    {0b10001, 0b10001, 0b10001, 0b10001, 0b10001, 0b10001, 0b01110},                 // U
    {0b10001, 0b10001, 0b10001, 0b10001, 0b10001, 0b01010, 0b00100},                 // V
    {0b10001, 0b10001, 0b10001, 0b10101, 0b10101, 0b11011, 0b10001},                 // W
    {0b10001, 0b10001, 0b01010, 0b00100, 0b01010, 0b10001, 0b10001},                 // X
    {0b10001, 0b10001, 0b01010, 0b00100, 0b00100, 0b00100, 0b00100},                 // Y
    {0b11111, 0b00001, 0b00010, 0b00100, 0b01000, 0b10000, 0b11111},                 // Z
    {0b01110, 0b10001, 0b10011, 0b10101, 0b11001, 0b10001, 0b01110},                 // 0
    {0b00100, 0b01100, 0b00100, 0b00100, 0b00100, 0b00100, 0b01110},                 // 1
    {0b01110, 0b10001, 0b00001, 0b00010, 0b00100, 0b01000, 0b11111},                 // 2
    {0b11110, 0b00001, 0b00001, 0b01110, 0b00001, 0b00001, 0b11110},                 // 3
    {0b00010, 0b00110, 0b01010, 0b10010, 0b11111, 0b00010, 0b00010},                 // 4
    {0b11111, 0b10000, 0b11110, 0b00001, 0b00001, 0b10001, 0b01110},                 // 5
    {0b00110, 0b01000, 0b10000, 0b11110, 0b10001, 0b10001, 0b01110},                 // 6
    {0b11111, 0b00001, 0b00010, 0b00100, 0b01000, 0b01000, 0b01000},                 // 7
    {0b01110, 0b10001, 0b10001, 0b01110, 0b10001, 0b10001, 0b01110},                 // 8
    {0b01110, 0b10001, 0b10001, 0b01111, 0b00001, 0b00010, 0b01100},                 // 9
    {0, 0, 0, 0b11111, 0, 0, 0},                                                     // -
    {0, 0, 0, 0, 0, 0b01100, 0b01100},                                               // .
    {0, 0b01100, 0b01100, 0, 0b01100, 0b01100, 0},                                   // :
    {0b01000, 0b00100, 0b00010, 0b00001, 0b00010, 0b00100, 0b01000},                 // >
    {0b01110, 0b01000, 0b01000, 0b01000, 0b01000, 0b01000, 0b01110},                 // [
    {0b01110, 0b00010, 0b00010, 0b00010, 0b00010, 0b00010, 0b01110},                 // ]
    {0b00001, 0b00010, 0b00010, 0b00100, 0b01000, 0b01000, 0b10000},                 // /
    {0b00100, 0b00100, 0b00100, 0b00100, 0b00100, 0, 0b00100},                       // !
    {0b01110, 0b10001, 0b00001, 0b00010, 0b00100, 0, 0b00100},                       // ?
    {0, 0, 0, 0, 0b01100, 0b00100, 0b01000},                                         // ,
    {0b00100, 0b00100, 0b01000, 0, 0, 0, 0},                                         // '
    {0, 0b00100, 0b00100, 0b11111, 0b00100, 0b00100, 0},                             // +
    {0b11001, 0b11010, 0b00010, 0b00100, 0b01000, 0b01011, 0b10011},                 // %
};

_Static_assert(sizeof(font) / sizeof(font[0]) == sizeof(FONT_CHARS) - 1, "font table size");

#define HUD_MAX 100000
static float hud_v[HUD_MAX * 2];
static float hud_c[HUD_MAX * 4];
static int   hud_n = 0;

static void hud_rect(float x, float y, float w, float h, float r, float g, float b, float a) {
    if (hud_n + 6 > HUD_MAX) return;
    float xs[6] = {x, x + w, x + w, x, x + w, x};
    float ys[6] = {y, y, y + h, y, y + h, y + h};
    for (int i = 0; i < 6; i++) {
        hud_v[hud_n * 2 + 0] = xs[i];
        hud_v[hud_n * 2 + 1] = ys[i];
        hud_c[hud_n * 4 + 0] = r;
        hud_c[hud_n * 4 + 1] = g;
        hud_c[hud_n * 4 + 2] = b;
        hud_c[hud_n * 4 + 3] = a;
        hud_n++;
    }
}

static float hud_text_width(const char *s, float scale) { return (float)strlen(s) * 6.0f * scale; }

static void hud_text_raw(float x, float y, float scale, const char *s,
                         float r, float g, float b, float a) {
    for (; *s; s++, x += 6.0f * scale) {
        const char *p = strchr(FONT_CHARS, toupper((unsigned char)*s));
        if (!p || !*p) continue;
        const unsigned char *rows = font[p - FONT_CHARS];
        for (int row = 0; row < 7; row++) {
            int col = 0;
            while (col < 5) {
                if (rows[row] & (1 << (4 - col))) {
                    int start = col;
                    while (col < 5 && (rows[row] & (1 << (4 - col)))) col++;
                    hud_rect(x + start * scale, y + row * scale, (col - start) * scale, scale, r, g, b, a);
                } else {
                    col++;
                }
            }
        }
    }
}

static void hud_text(float x, float y, float scale, const char *s, float r, float g, float b) {
    hud_text_raw(x + scale, y + scale, scale, s, 0, 0, 0, 0.8f);   // drop shadow
    hud_text_raw(x, y, scale, s, r, g, b, 1.0f);
}

static void hud_text_centered(float y, float scale, const char *s, float r, float g, float b) {
    hud_text((960.0f - hud_text_width(s, scale)) / 2.0f, y, scale, s, r, g, b);
}

static void hud_bar(float x, float y, float w, float h, float frac,
                    float r, float g, float b) {
    if (frac < 0.0f) frac = 0.0f;
    if (frac > 1.0f) frac = 1.0f;
    hud_rect(x - 3, y - 3, w + 6, h + 6, 0.02f, 0.02f, 0.03f, 0.85f);   // frame
    hud_rect(x, y, w, h, 0.14f, 0.12f, 0.12f, 0.9f);                    // empty part
    hud_rect(x, y, w * frac, h, r, g, b, 1.0f);                         // fill
    hud_rect(x, y, w * frac, h * 0.35f, fminf(r + 0.2f, 1.0f), fminf(g + 0.2f, 1.0f),
             fminf(b + 0.2f, 1.0f), 0.55f);                              // highlight
}

static void hud_bars(void) {
    float hw = HEALTH_BAR_W * (player_max_hp / 100.0f);
    float sw = STAMINA_BAR_W * (player_max_stam / 100.0f);
    hud_bar(BAR_X, BAR_Y, hw, HEALTH_BAR_H, player_hp / player_max_hp, HEALTH_COLOR);
    hud_bar(BAR_X, BAR_Y + HEALTH_BAR_H + BAR_GAP, sw, STAMINA_BAR_H,
            player_stam / player_max_stam, STAMINA_COLOR);
}

#define PREVIEW_X  370.0f
#define PREVIEW_Y  110.0f
#define PREVIEW_W  250.0f
#define PREVIEW_H  230.0f

// Health bar + name floating above each living enemy's head.
static void hud_enemy_bars(void) {
    for (int i = 0; i < NUM_ENEMIES; i++) {
        const Enemy *e = &enemies[i];
        const EnemyDef *d = &enemy_defs[e->type];
        if (e->state == E_DEAD) continue;
        // Hidden while it is behind a closed door.
        if (!can_see(room_of(e->x, e->z), room_of(g_cam_x, g_cam_z))) continue;
        float dx = e->x - g_cam_x, dz = e->z - g_cam_z;
        float dist = sqrtf(dx * dx + dz * dz);
        if (dist > 18.0f) continue;
        float sx, sy;
        float head = d->bar_height + (e->state == E_LUNGE ? 0.2f : 0.0f);
        if (!project_point(e->x, head, e->z, &sx, &sy)) continue;
        float w = fminf(96.0f, fmaxf(44.0f, 230.0f / (dist + 0.5f)));
        hud_bar(sx - w / 2, sy, w, 7.0f, e->hp / d->max_hp, 0.85f, 0.18f, 0.14f);
        if (dist < 10.0f)
            hud_text(sx - hud_text_width(d->name, 2) / 2, sy - 20.0f, 2, d->name, 0.95f, 0.9f, 0.8f);
        if (e->state == E_WINDUP)   // attack warning
            hud_text(sx - 12.0f, sy - 62.0f, 4, "!", 1.0f, 0.25f, 0.15f);
    }
}

static void hud_panel(float x, float y, float w, float h) {
    hud_rect(0, 0, 960, 544, 0, 0, 0, 0.45f);
    hud_rect(x, y, w, h, 0.05f, 0.05f, 0.08f, 0.88f);
    hud_rect(x, y, w, 4, 0.7f, 0.6f, 0.3f, 1.0f);
    hud_rect(x, y + h - 4, w, 4, 0.7f, 0.6f, 0.3f, 1.0f);
}

static void hud_menu_list(float x, float y, float row, float w, const char *const *labels, int n, int sel) {
    for (int i = 0; i < n; i++) {
        float yy = y + i * row;
        if (i == sel) hud_rect(x - 18, yy - 6, w, 32, 0.25f, 0.22f, 0.12f, 0.9f);
        hud_text(x - 6, yy, 3, i == sel ? ">" : " ", 1.0f, 0.9f, 0.4f);
        hud_text(x + 28, yy, 3, labels[i], 0.9f, 0.9f, 0.9f);
    }
}

static void hud_pause(void) {
    static const char *const labels[5] = { "RESUME", "EQUIPMENT", "BESTIARY", "MAIN MENU", "QUIT GAME" };
    hud_panel(330, 90, 300, 360);
    hud_text(360, 112, 4, "PAUSED", 0.95f, 0.85f, 0.5f);
    hud_menu_list(372, 180, 44, 250, labels, 5, pause_sel);
    hud_text(360, 410, 2, "START: RESUME", 0.8f, 0.8f, 0.8f);
}

static void hud_beacon(void) {
    static const char *const labels[4] = { "SAVE", "REST", "LEVEL UP", "TELEPORT" };
    hud_panel(330, 100, 300, 320);
    hud_text(360, 122, 4, "BEACON", 0.6f, 0.9f, 1.0f);
    hud_menu_list(372, 195, 44, 250, labels, 4, beacon_sel);
    hud_text(360, 384, 2, "O: CLOSE", 0.8f, 0.8f, 0.8f);
}

static void hud_bestiary(void) {
    hud_panel(60, 40, 840, 464);
    hud_text(90, 62, 4, "BESTIARY", 0.95f, 0.85f, 0.5f);
    for (int i = 0; i < ENEMY_TYPE_COUNT; i++) {
        float y = 130 + i * 34;
        if (i == bestiary_sel) hud_rect(78, y - 6, 270, 32, 0.25f, 0.22f, 0.12f, 0.9f);
        hud_text(90, y, 3, i == bestiary_sel ? ">" : " ", 1.0f, 0.9f, 0.4f);
        hud_text(126, y, 3, bestiary_seen[i] ? enemy_defs[i].name : "UNKNOWN", 0.9f, 0.9f, 0.9f);
    }

    // Frame for the spinning 3D model (the model itself is drawn after the HUD).
    hud_rect(PREVIEW_X - 3, PREVIEW_Y - 3, PREVIEW_W + 6, PREVIEW_H + 6, 0.7f, 0.6f, 0.3f, 1.0f);
    hud_rect(PREVIEW_X, PREVIEW_Y, PREVIEW_W, PREVIEW_H, 0.10f, 0.10f, 0.14f, 1.0f);

    if (!bestiary_seen[bestiary_sel]) {
        hud_text(PREVIEW_X + 62, PREVIEW_Y + 100, 3, "UNKNOWN", 0.6f, 0.6f, 0.65f);
        hud_text(PREVIEW_X, PREVIEW_Y + PREVIEW_H + 20, 2, "ENCOUNTER IT TO RECORD IT.", 0.7f, 0.7f, 0.75f);
    } else {
        const EnemyDef *d = &enemy_defs[bestiary_sel];
        char b[64];
        hud_text(PREVIEW_X, PREVIEW_Y + PREVIEW_H + 20, 2, d->desc[0], 0.75f, 0.75f, 0.8f);
        hud_text(PREVIEW_X, PREVIEW_Y + PREVIEW_H + 44, 2, d->desc[1], 0.75f, 0.75f, 0.8f);

        snprintf(b, sizeof(b), "HEALTH: %d", (int)d->max_hp);
        hud_text(640, 120, 3, b, 0.9f, 0.85f, 0.55f);

        char wk[64];
        int any = 0;
        snprintf(wk, sizeof(wk), "WEAK TO:");
        for (int k = 0; k < DMG_TYPE_COUNT; k++) {
            if (d->resist[k] > 1.05f) {
                size_t l = strlen(wk);
                snprintf(wk + l, sizeof(wk) - l, " %s", dmg_type_short[k]);
                any = 1;
            }
        }
        if (!any) {
            size_t l = strlen(wk);
            snprintf(wk + l, sizeof(wk) - l, " NONE");
        }
        snprintf(b, sizeof(b), "XP REWARD: %d", d->xp);
        hud_text(640, 144, 2, b, 0.7f, 0.9f, 0.7f);
        hud_text(640, 168, 2, wk, 0.9f, 0.9f, 0.9f);

        hud_text(640, 204, 2, "DAMAGE TAKEN:", 0.7f, 0.7f, 0.75f);
        for (int k = 0; k < DMG_TYPE_COUNT; k++) {
            float m = d->resist[k];
            snprintf(b, sizeof(b), "%s: %s X%.1f", dmg_type_short[k],
                     m > 1.05f ? "WEAK" : (m < 0.95f ? "RESISTANT" : "NEUTRAL"), m);
            hud_text(640, 232 + k * 28, 2, b, 0.85f, 0.85f, 0.85f);
        }
    }
    hud_text(90, 470, 2, "O: BACK", 0.8f, 0.8f, 0.8f);
}

// Draws s word-wrapped at maxc characters per line, revealing only the first `shown` characters.
static void hud_text_wrapped(float x, float y, float scale, const char *s, int maxc, int shown,
                             float r, float g, float b) {
    int len = (int)strlen(s), pos = 0, line = 0;
    while (pos < len) {
        int end = pos + maxc;
        if (end >= len) end = len;
        else { int k = end; while (k > pos && s[k] != ' ') k--; if (k > pos) end = k; }
        int n = end - pos, vis = shown - pos;
        if (vis <= 0) break;
        if (vis < n) n = vis;
        char buf[96];
        if (n > 95) n = 95;
        memcpy(buf, s + pos, n);
        buf[n] = 0;
        hud_text(x, y + line * scale * 10.0f, scale, buf, r, g, b);
        pos = end;
        while (pos < len && s[pos] == ' ') pos++;
        line++;
    }
}

static void hud_dialogue(void) {
    const float x = 60, y = 366, w = 840, h = 136;
    hud_rect(x, y, w, h, 0.03f, 0.03f, 0.05f, 0.88f);
    hud_rect(x, y, w, 3, 0.7f, 0.6f, 0.3f, 1.0f);
    hud_rect(x, y + h - 3, w, 3, 0.7f, 0.6f, 0.3f, 1.0f);
    hud_text(x + 30, y + 16, 2, "WANDERER", 0.85f, 0.75f, 0.45f);
    const char *txt = npc_text();
    int shown = (int)dlg_chars;
    hud_text_wrapped(x + 30, y + 48, 3, txt, 42, shown, 0.92f, 0.9f, 0.85f);
    if (shown >= (int)strlen(txt) && ((int)(g_time * 2.0f) & 1))
        hud_text(x + w - 50, y + h - 34, 2, npc_done || npc_line + 1 >= NPC_LINES ? "X" : ">", 0.9f, 0.8f, 0.4f);
}

static int pend_total(void) { return pend[0] + pend[1] + pend[2]; }

static void hud_box(float x, float y, float w, float h) {
    hud_rect(x, y, w, h, 0.06f, 0.055f, 0.05f, 0.94f);
    hud_rect(x, y, w, 2, 0.40f, 0.33f, 0.20f, 1.0f);
    hud_rect(x, y + h - 2, w, 2, 0.40f, 0.33f, 0.20f, 1.0f);
    hud_rect(x, y, 2, h, 0.40f, 0.33f, 0.20f, 1.0f);
    hud_rect(x + w - 2, y, 2, h, 0.40f, 0.33f, 0.20f, 1.0f);
    hud_rect(x + 4, y + 4, w - 8, 1, 0.20f, 0.17f, 0.12f, 1.0f);
}

static void hud_section(float x, float y, float w, const char *title) {
    hud_text(x, y, 2, title, 0.88f, 0.80f, 0.55f);
    hud_rect(x, y + 19, w, 1, 0.45f, 0.38f, 0.25f, 1.0f);
}

// Full-screen menu backdrop + title band shared by the level-up and equipment screens.
static void hud_header(const char *title) {
    hud_rect(0, 0, 960, 544, 0, 0, 0, 0.80f);
    hud_rect(0, 0, 960, 52, 0.03f, 0.03f, 0.04f, 0.97f);
    hud_rect(0, 52, 960, 2, 0.45f, 0.38f, 0.25f, 1.0f);
    hud_rect(16, 10, 32, 32, 0.70f, 0.60f, 0.30f, 1.0f);
    hud_rect(20, 14, 24, 24, 0.10f, 0.10f, 0.12f, 1.0f);
    hud_rect(27, 21, 10, 10, 0.92f, 0.80f, 0.40f, 1.0f);
    hud_text(64, 14, 3, title, 0.92f, 0.88f, 0.78f);
}

static void hud_footer(const char *l1, const char *l2) {
    hud_rect(0, 478, 960, 66, 0.03f, 0.03f, 0.04f, 0.97f);
    hud_rect(0, 478, 960, 2, 0.45f, 0.38f, 0.25f, 1.0f);
    hud_text(16, 490, 2, l1, 0.85f, 0.85f, 0.85f);
    hud_text(16, 514, 2, l2, 0.85f, 0.85f, 0.85f);
}

// "LABEL      cur > next" with the new value coloured when it changes.
static void hud_val_row(float x, float y, float w, const char *label, const char *cur, const char *next,
                        int changed, float nr, float ng, float nb) {
    hud_text(x, y, 2, label, 0.88f, 0.88f, 0.86f);
    hud_text(x + w - 80 - hud_text_width(cur, 2), y, 2, cur, 0.85f, 0.85f, 0.85f);
    hud_text(x + w - 70, y, 2, ">", 0.6f, 0.55f, 0.4f);
    if (changed) hud_text(x + w - hud_text_width(next, 2), y, 2, next, nr, ng, nb);
    else         hud_text(x + w - hud_text_width(next, 2), y, 2, next, 0.85f, 0.85f, 0.85f);
}

static void hud_val_int(float x, float y, float w, const char *label, int cur, int next, int up) {
    char a[24], b[24];
    snprintf(a, sizeof(a), "%d", cur);
    snprintf(b, sizeof(b), "%d", next);
    if (up) hud_val_row(x, y, w, label, a, b, cur != next, 0.45f, 0.65f, 1.0f);
    else    hud_val_row(x, y, w, label, a, b, cur != next, 1.0f, 0.55f, 0.35f);
}

// "LABEL   value" (right aligned).
static void hud_stat_row(float x, float y, float w, const char *label, const char *val) {
    hud_text(x, y, 2, label, 0.88f, 0.88f, 0.86f);
    hud_text(x + w - hud_text_width(val, 2), y, 2, val, 0.85f, 0.85f, 0.85f);
}

// Level-up screen (opened from the beacon). Loosely modelled on the Dark Souls one:
// you carry XP, pick attribute levels to buy, and see what they change before confirming.
static void hud_stats(void) {
    static const char *const names[3] = { "HEALTH", "STAMINA", "STRENGTH" };
    const int pt = pend_total();
    const int lvl = player_level();
    const int cost = levels_cost(lvl, pt);
    const int lv[3] = { lv_hp, lv_stam, lv_str };
    const float hp_new   = MAX_HEALTH  + HP_PER_LEVEL   * (float)(lv_hp + pend[0]);
    const float st_new   = MAX_STAMINA + STAM_PER_LEVEL * (float)(lv_stam + pend[1]);
    const float mult_new = 1.0f + STR_BONUS * (float)(lv_str + pend[2]);
    char a[48], b[48];

    hud_header("LEVEL UP");

    // ---------------- left: level, xp, attributes ----------------
    const float lx = 14, ly = 66, lw = 330, lh = 400, ix = lx + 14, iw = lw - 28;
    hud_box(lx, ly, lw, lh);
    hud_val_int(ix, ly + 18, iw, "LEVEL", lvl, lvl + pt, 1);
    hud_val_int(ix, ly + 46, iw, "XP", xp, xp - cost, 0);
    {
        int req = pt > 0 ? cost : level_cost(lvl);
        snprintf(a, sizeof(a), "%d", req);
        hud_text(ix, ly + 74, 2, "REQUIRED XP", 0.88f, 0.88f, 0.86f);
        if (xp >= req || pt > 0) hud_text(ix + iw - hud_text_width(a, 2), ly + 74, 2, a, 0.9f, 0.9f, 0.9f);
        else                     hud_text(ix + iw - hud_text_width(a, 2), ly + 74, 2, a, 1.0f, 0.35f, 0.3f);
    }

    hud_section(ix, ly + 118, iw, "ATTRIBUTES");
    for (int i = 0; i < 3; i++) {
        float y = ly + 150 + i * 38;
        if (i == stats_sel) {
            hud_rect(ix - 6, y - 9, iw + 12, 32, 0.50f, 0.30f, 0.10f, 0.50f);
            hud_rect(ix - 6, y - 9, iw + 12, 2, 0.85f, 0.65f, 0.30f, 0.9f);
            hud_rect(ix - 6, y + 21, iw + 12, 2, 0.85f, 0.65f, 0.30f, 0.9f);
        }
        hud_text(ix, y, 2, names[i], i == stats_sel ? 1.0f : 0.88f, i == stats_sel ? 0.92f : 0.88f, i == stats_sel ? 0.75f : 0.86f);
        snprintf(a, sizeof(a), "%d", lv[i] + 1);
        snprintf(b, sizeof(b), "%d", lv[i] + 1 + pend[i]);
        hud_text(ix + iw - 80 - hud_text_width(a, 2), y, 2, a, 0.85f, 0.85f, 0.85f);
        hud_text(ix + iw - 70, y, 2, ">", 0.6f, 0.55f, 0.4f);
        if (pend[i] > 0) hud_text(ix + iw - hud_text_width(b, 2), y, 2, b, 0.45f, 0.65f, 1.0f);
        else             hud_text(ix + iw - hud_text_width(b, 2), y, 2, b, 0.85f, 0.85f, 0.85f);
        if (i == stats_sel) hud_text(ix + iw - hud_text_width(b, 2) - 18, y, 2, "<", 0.95f, 0.8f, 0.4f);
    }

    // Confirm button
    {
        float bx = ix + 40, by = ly + lh - 62, bw = iw - 80, bh = 36;
        int sel = (stats_sel == 3);
        hud_rect(bx, by, bw, bh, sel ? 0.30f : 0.10f, sel ? 0.20f : 0.09f, sel ? 0.08f : 0.08f, 0.95f);
        hud_rect(bx, by, bw, 2, 0.75f, 0.62f, 0.32f, 1.0f);
        hud_rect(bx, by + bh - 2, bw, 2, 0.75f, 0.62f, 0.32f, 1.0f);
        hud_rect(bx, by, 2, bh, 0.75f, 0.62f, 0.32f, 1.0f);
        hud_rect(bx + bw - 2, by, 2, bh, 0.75f, 0.62f, 0.32f, 1.0f);
        float c = (pt > 0 || sel) ? 1.0f : 0.6f;
        hud_text(bx + (bw - hud_text_width("CONFIRM", 2)) / 2, by + 11, 2, "CONFIRM", c, c * 0.92f, c * 0.75f);
    }

    // ---------------- middle: base power + attack power ----------------
    const float mx = 356, mw = 290, mix = mx + 14, miw = mw - 28;
    hud_box(mx, ly, mw, lh);
    hud_section(mix, ly + 16, miw, "BASE POWER");
    hud_val_int(mix, ly + 46, miw, "HEALTH", (int)player_max_hp, (int)hp_new, 1);
    hud_val_int(mix, ly + 72, miw, "STAMINA", (int)player_max_stam, (int)st_new, 1);
    snprintf(a, sizeof(a), "X%.1f", str_mult());
    snprintf(b, sizeof(b), "X%.1f", mult_new);
    hud_val_row(mix, ly + 98, miw, "DAMAGE", a, b, lv_str + pend[2] != lv_str, 0.45f, 0.65f, 1.0f);

    hud_section(mix, ly + 146, miw, "ATTACK POWER");
    if (inv_n == 0) hud_text(mix, ly + 176, 2, "NO WEAPONS", 0.55f, 0.55f, 0.55f);
    for (int i = 0; i < inv_n && i < 6; i++) {
        const ItemDef *d = &item_defs[inv[i]];
        float wy = ly + 176 + i * 26;
        int slot = -1;
        for (int k = 0; k < QUICK_SLOTS; k++) if (quick[k] == inv[i]) slot = k;
        if (slot >= 0) hud_rect(mix, wy + 4, 6, 6, slot == active_quick ? 0.92f : 0.55f, slot == active_quick ? 0.80f : 0.48f, 0.40f, 1.0f);
        hud_val_int(mix + 14, wy, miw - 14, d->name, (int)(d->damage * str_mult() + 0.001f),
                    (int)(d->damage * mult_new + 0.001f), 1);
    }

    // ---------------- right: description + cost of upcoming levels ----------------
    const float rx = 658, rw = 288, rix = rx + 14, riw = rw - 28;
    hud_box(rx, ly, rw, lh);
    hud_section(rix, ly + 16, riw, "ABOUT");
    {
        char desc[112];
        if (stats_sel == 0)      snprintf(desc, sizeof(desc), "RAISES MAX HEALTH BY %d PER LEVEL. SURVIVE MORE HITS.", (int)HP_PER_LEVEL);
        else if (stats_sel == 1) snprintf(desc, sizeof(desc), "RAISES MAX STAMINA BY %d PER LEVEL FOR MORE SWINGS AND DODGES.", (int)STAM_PER_LEVEL);
        else if (stats_sel == 2) snprintf(desc, sizeof(desc), "RAISES ALL WEAPON DAMAGE BY %d%% PER LEVEL.", (int)(STR_BONUS * 100.0f + 0.5f));
        else                     snprintf(desc, sizeof(desc), "SPEND XP ON THE CHOSEN ATTRIBUTES AND LEVEL UP.");
        hud_text_wrapped(rix, ly + 46, 2, desc, 22, 999, 0.82f, 0.82f, 0.8f);
    }
    hud_section(rix, ly + 170, riw, "XP COST");
    for (int k = 0; k < 6; k++) {
        float y = ly + 200 + k * 26;
        snprintf(a, sizeof(a), "TO LEVEL %d", lvl + pt + k + 1);
        snprintf(b, sizeof(b), "%d", level_cost(lvl + pt + k));
        hud_text(rix, y, 2, a, k == 0 ? 0.95f : 0.65f, k == 0 ? 0.9f : 0.65f, k == 0 ? 0.75f : 0.65f);
        hud_text(rix + riw - hud_text_width(b, 2), y, 2, b, k == 0 ? 0.95f : 0.65f, k == 0 ? 0.9f : 0.65f, k == 0 ? 0.75f : 0.65f);
    }

    hud_footer("UP/DOWN: SELECT    LEFT/RIGHT: ADJUST    X: ADD / CONFIRM", "O: BACK");
}

// "LABEL  cur > next" for comparing the highlighted weapon with the one in the slot.
static void hud_cmp_val(float x, float y, float w, const char *label, float cur, float next,
                        int cmp, int higher_better, const char *fmt) {
    char a[24], b[24];
    snprintf(a, sizeof(a), fmt, cur);
    snprintf(b, sizeof(b), fmt, next);
    if (!cmp) { hud_stat_row(x, y, w, label, b); return; }
    int up = next > cur + 1e-4f, down = next < cur - 1e-4f;
    int good = higher_better ? up : down, bad = higher_better ? down : up;
    if (good)      hud_val_row(x, y, w, label, a, b, 1, 0.45f, 0.65f, 1.0f);
    else if (bad)  hud_val_row(x, y, w, label, a, b, 1, 1.0f, 0.55f, 0.35f);
    else           hud_val_row(x, y, w, label, a, b, 0, 0, 0, 0);
}

// Equipment screen: three weapon slots on the left, your items in the middle, details on the right.
static void hud_equipment(void) {
    const int shown = eq_shown_item();
    const int cur_id = quick[eq_slot];
    char a[48];

    hud_header("EQUIPMENT");

    // ---------------- left: the three weapon slots + status ----------------
    const float lx = 14, ly = 66, lw = 300, lh = 400, ix = lx + 14, iw = lw - 28;
    hud_box(lx, ly, lw, lh);
    hud_section(ix, ly + 16, iw, "WEAPONS");
    for (int i = 0; i < QUICK_SLOTS; i++) {
        float y = ly + 46 + i * 62;
        int sel = (!eq_focus && i == eq_slot), tgt = (eq_focus && i == eq_slot);
        hud_rect(ix - 6, y - 4, iw + 12, 54, sel ? 0.50f : 0.12f, sel ? 0.30f : 0.10f, sel ? 0.10f : 0.08f, sel ? 0.5f : 0.6f);
        if (sel || tgt) {
            hud_rect(ix - 6, y - 4, iw + 12, 2, 0.85f, 0.65f, 0.30f, sel ? 0.9f : 0.5f);
            hud_rect(ix - 6, y + 48, iw + 12, 2, 0.85f, 0.65f, 0.30f, sel ? 0.9f : 0.5f);
        }
        hud_rect(ix, y + 2, 40, 40, 0.40f, 0.33f, 0.20f, 1.0f);
        hud_rect(ix + 2, y + 4, 36, 36, 0.10f, 0.09f, 0.08f, 1.0f);
        char dn[2] = { (char)('1' + i), 0 };
        hud_text(ix + 11, y + 11, 3, dn, 0.9f, 0.8f, 0.5f);
        int id = quick[i];
        if (id >= 0) {
            hud_text(ix + 52, y + 4, 2, item_defs[id].name, 0.95f, 0.95f, 0.92f);
            if (i == active_quick) hud_text(ix + 52, y + 26, 2, "IN HAND", 0.92f, 0.80f, 0.40f);
            else                   hud_text(ix + 52, y + 26, 2, dmg_type_names[item_defs[id].dmg_type], 0.6f, 0.6f, 0.62f);
        } else {
            hud_text(ix + 52, y + 15, 2, "EMPTY", 0.5f, 0.5f, 0.52f);
        }
    }

    hud_section(ix, ly + 250, iw, "STATUS");
    snprintf(a, sizeof(a), "%d", player_level());           hud_stat_row(ix, ly + 280, iw, "LEVEL", a);
    snprintf(a, sizeof(a), "%d", (int)player_max_hp);        hud_stat_row(ix, ly + 304, iw, "HEALTH", a);
    snprintf(a, sizeof(a), "%d", (int)player_max_stam);      hud_stat_row(ix, ly + 328, iw, "STAMINA", a);
    snprintf(a, sizeof(a), "X%.1f", str_mult());             hud_stat_row(ix, ly + 352, iw, "DAMAGE", a);

    // ---------------- middle: inventory list ----------------
    const float mx = 326, mw = 300, mix = mx + 14, miw = mw - 28;
    hud_box(mx, ly, mw, lh);
    hud_section(mix, ly + 16, miw, "INVENTORY");
    for (int i = 0; i <= inv_n; i++) {
        float y = ly + 46 + i * 30;
        int hl = (eq_focus && i == inv_sel);
        if (hl) {
            hud_rect(mix - 6, y - 6, miw + 12, 28, 0.50f, 0.30f, 0.10f, 0.50f);
            hud_rect(mix - 6, y - 6, miw + 12, 2, 0.85f, 0.65f, 0.30f, 0.9f);
            hud_rect(mix - 6, y + 20, miw + 12, 2, 0.85f, 0.65f, 0.30f, 0.9f);
        }
        float c = (eq_focus || i > 0) ? 0.92f : 0.6f;
        if (!eq_focus) c = 0.62f;
        hud_text(mix, y, 2, i == 0 ? "- EMPTY -" : item_defs[inv[i - 1]].name, c, c, c * 0.95f);
        if (i > 0) {   // which slots hold it
            float tx = mix + miw - 20;
            for (int k = QUICK_SLOTS - 1; k >= 0; k--) {
                if (quick[k] != inv[i - 1]) continue;
                char dn[2] = { (char)('1' + k), 0 };
                hud_rect(tx, y - 3, 20, 20, 0.40f, 0.33f, 0.20f, 1.0f);
                hud_rect(tx + 2, y - 1, 16, 16, 0.10f, 0.09f, 0.08f, 1.0f);
                hud_text(tx + 4, y - 1, 2, dn, 0.92f, 0.8f, 0.45f);
                tx -= 24;
            }
        }
    }
    if (inv_n == 0) hud_text_wrapped(mix, ly + 84, 2, "NOTHING YET. EXPLORE AND PICK THINGS UP.", 22, 99, 0.55f, 0.55f, 0.55f);

    // ---------------- right: item details ----------------
    const float rx = 638, rw = 308, rix = rx + 14, riw = rw - 28;
    hud_box(rx, ly, rw, lh);
    hud_rect(EQ_PREVIEW_X - 2, EQ_PREVIEW_Y - 2, EQ_PREVIEW_W + 4, EQ_PREVIEW_H + 4, 0.45f, 0.38f, 0.25f, 1.0f);
    hud_rect(EQ_PREVIEW_X, EQ_PREVIEW_Y, EQ_PREVIEW_W, EQ_PREVIEW_H, 0.08f, 0.08f, 0.11f, 1.0f);
    if (shown < 0) {
        hud_text(rix, ly + 160, 3, "UNARMED", 0.7f, 0.7f, 0.72f);
        hud_text_wrapped(rix, ly + 196, 2, "BARE HANDS DEAL NO DAMAGE.", 23, 99, 0.6f, 0.6f, 0.62f);
    } else {
        const ItemDef *it = &item_defs[shown];
        const int cmp = eq_focus && cur_id >= 0 && cur_id != shown;
        const ItemDef *cu = cmp ? &item_defs[cur_id] : it;
        hud_text(rix, ly + 160, 3, it->name, 0.95f, 0.95f, 0.9f);
        hud_text(rix, ly + 190, 2, dmg_type_names[it->dmg_type], 0.92f, 0.80f, 0.40f);
        hud_cmp_val(rix, ly + 218, riw, "ATTACK",  weapon_damage(cu) + 0.001f, weapon_damage(it) + 0.001f, cmp, 1, "%.0f");
        hud_cmp_val(rix, ly + 242, riw, "STAMINA", cu->stamina_cost, it->stamina_cost, cmp, 0, "%.0f");
        hud_cmp_val(rix, ly + 266, riw, "RANGE",   cu->range, it->range, cmp, 1, "%.1f");
        hud_cmp_val(rix, ly + 290, riw, "SPEED",   cu->swing_time, it->swing_time, cmp, 0, "%.2f");
        hud_text_wrapped(rix, ly + 326, 2, it->desc, 23, 999, 0.72f, 0.72f, 0.76f);
    }

    if (!eq_focus) hud_footer("UP/DOWN: SELECT SLOT    X: CHOOSE A WEAPON    O: BACK", "IN GAME: D-PAD LEFT/RIGHT SWAPS BETWEEN YOUR WEAPONS");
    else           hud_footer("UP/DOWN: SELECT    X: EQUIP IN SLOT    O: BACK", "EQUIPPING A WEAPON THAT IS IN ANOTHER SLOT SWAPS THEM");
}

// Bottom-right XP counter with the Dark Souls style "+N" that pours into the total.
static void hud_xp_counter(void) {
    const float w = 210, h = 40, x = 960 - w - 20, y = 464;
    hud_rect(x, y, w, h, 0.03f, 0.03f, 0.05f, 0.80f);
    hud_rect(x, y, w, 2, 0.55f, 0.47f, 0.28f, 1.0f);
    hud_rect(x, y + h - 2, w, 2, 0.55f, 0.47f, 0.28f, 1.0f);
    hud_rect(x, y, 2, h, 0.55f, 0.47f, 0.28f, 1.0f);
    hud_rect(x + w - 2, y, 2, h, 0.55f, 0.47f, 0.28f, 1.0f);
    hud_text(x + 12, y + 13, 2, "XP", 0.80f, 0.75f, 0.50f);
    char b[24];
    snprintf(b, sizeof(b), "%d", (int)(xp_shown + 0.5f));
    hud_text(x + w - 12 - hud_text_width(b, 3), y + 8, 3, b, 0.95f, 0.92f, 0.85f);
    if (xp_pop >= 0.5f) {
        snprintf(b, sizeof(b), "+%d", (int)(xp_pop + 0.5f));
        hud_text(x + w - 12 - hud_text_width(b, 3), y - 30, 3, b, 1.0f, 0.85f, 0.35f);
    }
}

// Bottom-left: the three weapon slots, with the one in hand highlighted.
static void hud_quick_slots(void) {
    for (int i = 0; i < QUICK_SLOTS; i++) {
        float y = 446 + i * 22;
        int act = (i == active_quick), id = quick[i];
        hud_rect(12, y - 3, 196, 20, 0, 0, 0, act ? 0.55f : 0.28f);
        if (act) hud_rect(12, y - 3, 3, 20, 0.92f, 0.80f, 0.40f, 1.0f);
        char dn[2] = { (char)('1' + i), 0 };
        hud_text(22, y, 2, dn, act ? 0.92f : 0.55f, act ? 0.80f : 0.5f, act ? 0.40f : 0.35f);
        hud_text(40, y, 2, id >= 0 ? item_defs[id].name : "-", act ? 0.95f : 0.6f, act ? 0.95f : 0.6f, act ? 0.92f : 0.6f);
    }
}

static void hud_title(const char *toast) {
    hud_rect(0, 0, 960, 544, 0.04f, 0.04f, 0.07f, 1.0f);
    hud_text_centered(50, 9, "CLAUDE FIELD", 0.9f, 0.8f, 0.5f);
    hud_text_centered(150, 2, "SELECT A SAVE FILE", 0.7f, 0.7f, 0.75f);
    for (int i = 0; i < NUM_SLOTS + 1; i++) {
        float y = 200 + i * 60;
        if (i == title_sel) hud_rect(130, y - 8, 700, 48, 0.25f, 0.22f, 0.12f, 0.9f);
        hud_text(150, y, 3, i == title_sel ? ">" : " ", 1.0f, 0.9f, 0.4f);
        char b[96];
        if (i == NUM_SLOTS) {
            snprintf(b, sizeof(b), "QUIT GAME");
        } else if (slot_ok[i]) {
            const SaveData *d = &slot_info[i];
            int mins = (int)(d->play_time / 60.0f);
            snprintf(b, sizeof(b), "SLOT %d  LEVEL %d  PLAYED %d:%02d", i + 1,
                     1 + d->lv_hp + d->lv_stam + d->lv_str, mins / 60, mins % 60);
        } else {
            snprintf(b, sizeof(b), "SLOT %d  EMPTY - NEW GAME", i + 1);
        }
        float c = (i < NUM_SLOTS && !slot_ok[i]) ? 0.6f : 0.92f;
        hud_text(190, y, 3, b, c, c, c);
    }
    hud_text(130, 500, 2, "X: SELECT    SQUARE: DELETE SLOT", 0.7f, 0.7f, 0.75f);
    if (toast) hud_text_centered(455, 3, toast, 0.7f, 1.0f, 0.7f);
    if (title_confirm) {
        hud_rect(0, 0, 960, 544, 0, 0, 0, 0.6f);
        hud_rect(210, 190, 540, 150, 0.05f, 0.05f, 0.08f, 1.0f);
        hud_rect(210, 190, 540, 4, 0.7f, 0.6f, 0.3f, 1.0f);
        hud_rect(210, 336, 540, 4, 0.7f, 0.6f, 0.3f, 1.0f);
        char b[48];
        snprintf(b, sizeof(b), "DELETE SLOT %d?", title_sel + 1);
        hud_text_centered(225, 4, b, 0.95f, 0.85f, 0.5f);
        hud_text_centered(290, 3, "X: YES    O: NO", 0.9f, 0.9f, 0.9f);
    }
}

static void build_hud(const char *prompt, const char *toast) {
    hud_n = 0;
    if (screen == SCREEN_TITLE) { hud_title(toast); return; }
    if (menu != MENU_STATS && menu != MENU_INVENTORY) hud_bars();

    if (menu == MENU_NONE && !player_dead) {
        hud_enemy_bars();
        hud_xp_counter();
        hud_quick_slots();
        hud_text(12, 518, 2, "TRIANGLE: EQUIP   START: MENU   O: DODGE   R: ATTACK   D-PAD: SWAP", 0.9f, 0.9f, 0.9f);
        if (prompt) hud_text_centered(470, 3, prompt, 1.0f, 0.95f, 0.6f);
    }

    if (hurt_flash > 0.0f) hud_rect(0, 0, 960, 544, 0.7f, 0.0f, 0.0f, fminf(hurt_flash * 0.9f, 0.35f));

    if (menu == MENU_INVENTORY) hud_equipment();
    else if (menu == MENU_PAUSE) hud_pause();
    else if (menu == MENU_BESTIARY) hud_bestiary();
    else if (menu == MENU_BEACON) hud_beacon();
    else if (menu == MENU_DIALOGUE) hud_dialogue();
    else if (menu == MENU_STATS) hud_stats();

    if (toast && menu != MENU_DIALOGUE) hud_text_centered(menu == MENU_BEACON ? 450 : (menu == MENU_STATS ? 440 : 425), 3, toast, 0.7f, 1.0f, 0.7f);

    if (player_dead) {
        float a = fminf(death_t * 0.8f, 0.8f);
        hud_rect(0, 0, 960, 544, 0, 0, 0, a);
        hud_text_centered(230, 8, "YOU DIED", 0.8f, 0.1f, 0.1f);
    }
}

// --------------------------------------------------------------- input ----

// Transform a point from weapon-local space to camera space, exactly like the GL calls
// glTranslatef(tx,ty,tz); glRotatef(ry,0,1,0); glRotatef(rz,0,0,1); glRotatef(rx,1,0,0).
static vec3 vm_point(vec3 p, float tx, float ty, float tz, float rz_deg, float rx_deg, float ry_deg) {
    float rz = rz_deg * PI_F / 180.0f, rx = rx_deg * PI_F / 180.0f, ry = ry_deg * PI_F / 180.0f;
    float y1 = p.y * cosf(rx) - p.z * sinf(rx);
    float z1 = p.y * sinf(rx) + p.z * cosf(rx);
    float x2 = p.x * cosf(rz) - y1 * sinf(rz);
    float y2 = p.x * sinf(rz) + y1 * cosf(rz);
    float x3 = x2 * cosf(ry) + z1 * sinf(ry);
    float z3 = -x2 * sinf(ry) + z1 * cosf(ry);
    return V(x3 + tx, y2 + ty, z3 + tz);
}

// Rebuild the forearm each frame in camera space: anchored at the shoulder
// (off-screen, bottom right) and stretching out to the wrist.
static void build_arm(vec3 shoulder, vec3 wrist) {
    rgb skin = C(0.80f, 0.58f, 0.44f), brace = C(0.38f, 0.30f, 0.24f);
    cur = &arm_mesh;
    arm_mesh.n = 0;
    add_prism(shoulder, wrist, 0.065f, 6, skin);
    vec3 b0 = V(wrist.x + (shoulder.x - wrist.x) * 0.25f, wrist.y + (shoulder.y - wrist.y) * 0.25f,
                wrist.z + (shoulder.z - wrist.z) * 0.25f);
    vec3 b1 = V(wrist.x + (shoulder.x - wrist.x) * 0.55f, wrist.y + (shoulder.y - wrist.y) * 0.55f,
                wrist.z + (shoulder.z - wrist.z) * 0.55f);
    add_prism(b0, b1, 0.085f, 6, brace);
}

static float axis(unsigned char raw) {
    float f = ((int)raw - 128) / 128.0f;
    float a = fabsf(f);
    if (a < DEADZONE) return 0.0f;
    a = (a - DEADZONE) / (1.0f - DEADZONE);
    return f < 0 ? -a : a;
}

static void draw_mesh(const Mesh *m) {
    if (m->n == 0) return;
    glVertexPointer(3, GL_FLOAT, 0, m->v);
    glColorPointer(4, GL_FLOAT, 0, m->c);
    glDrawArrays(GL_TRIANGLES, 0, m->n);
}

// ---------------------------------------------------------------- main ----

static void set_perspective(void) {
    const float near_ = 0.1f, far_ = 100.0f;
    float top = near_ * tanf(35.0f * PI_F / 180.0f);   // 70 degree vertical FOV
    float right = top * (960.0f / 544.0f);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glFrustum(-right, right, -top, top, near_, far_);
    glMatrixMode(GL_MODELVIEW);
}

// Spinning 3D model inside a rectangle of the HUD (bestiary + equipment screens). Drawn after the
// HUD batch, using the normal projection with the model shifted to the rectangle's centre.
static void draw_preview(const Mesh *m, float rx, float ry, float rw, float rh,
                         float scale, float cy, float cz, float tilt, float spin, int flat) {
    const float dist = 2.2f;
    float ndc_x = (rx + rw / 2.0f) / 480.0f - 1.0f;
    float ndc_y = 1.0f - (ry + rh / 2.0f) / 272.0f;
    glClear(GL_DEPTH_BUFFER_BIT);
    glEnable(GL_DEPTH_TEST);
    set_perspective();
    glLoadIdentity();
    glTranslatef(ndc_x * dist * 0.70020753f * (960.0f / 544.0f), ndc_y * dist * 0.70020753f, -dist);
    glRotatef(tilt, 1, 0, 0);
    glRotatef(spin, 0, 1, 0);
    glScalef(scale, scale, scale);
    if (flat) {   // weapons lie on their side so the long axis fits the frame
        glRotatef(-90.0f, 0, 0, 1);
        glTranslatef(0.0f, -cy, 0.0f);
    } else {
        glTranslatef(0.0f, -cy, -cz);
    }
    glEnableClientState(GL_VERTEX_ARRAY);
    glEnableClientState(GL_COLOR_ARRAY);
    draw_mesh(m);
    glDisableClientState(GL_COLOR_ARRAY);
    glDisableClientState(GL_VERTEX_ARRAY);
    glDisable(GL_DEPTH_TEST);
}

// Enemy animation per state. Rat: hop, crouch + shake, stretched lunge. Crab: scuttle, rear up, slam.
static void draw_enemy(const Enemy *e, float t) {
    const EnemyDef *d = &enemy_defs[e->type];
    float hop_y = 0.0f, pitch = 0.0f, roll = 0.0f, shake = 0.0f, back = 0.0f, lift = 0.0f;
    float sx = 1.0f, sy = 1.0f, sz = 1.0f, u;

    if (e->type == ENEMY_CRAB) {
        float cyc = sinf(e->hop * 2.0f * PI_F);
        switch (e->state) {
        case E_IDLE:
        case E_CHASE:
            if (e->walking) {
                roll = cyc * (e->state == E_CHASE ? 4.5f : 3.0f);
                hop_y = fabsf(cyc) * 0.05f;
                shake = sinf(e->hop * 4.0f * PI_F) * 0.02f;
            } else {
                sy = 1.0f + sinf(t * 1.5f) * 0.015f;
            }
            break;
        case E_WINDUP:   // rears up with claws raised, trembling
            u = fminf(e->state_t / d->windup, 1.0f);
            pitch = -30.0f * u;
            hop_y = 0.20f * u;
            shake = sinf(t * 60.0f) * 0.03f * u;
            sz = 1.0f - 0.06f * u;
            break;
        case E_LUNGE:    // slams forward
            sz = 1.15f; sy = 0.9f; pitch = 22.0f;
            break;
        case E_RECOVER:
            sy = 0.93f; pitch = 10.0f;
            break;
        case E_STAGGER:
            roll = sinf(e->state_t * 40.0f) * 8.0f;
            back = -0.08f;
            break;
        case E_DEAD:     // flips onto its back
            u = smooth01(e->state_t / 0.4f);
            roll = u * 180.0f;
            lift = 0.62f * d->scale * u;
            break;
        }
    } else {
        switch (e->state) {
        case E_IDLE:
            sy = 1.0f + sinf(t * 2.5f) * 0.03f;
            break;
        case E_CHASE: {
            float f = e->hop - floorf(e->hop);
            if (f < 0.65f) {
                float a = sinf(PI_F * f / 0.65f);
                hop_y = a * 0.30f;
                pitch = -a * 22.0f;
            } else {
                sy = 0.85f; sz = 1.08f; pitch = 6.0f;   // landing squash
            }
            break;
        }
        case E_WINDUP:
            u = fminf(e->state_t / d->windup, 1.0f);
            sy = 1.0f - 0.30f * u;
            sz = 1.0f - 0.10f * u;
            back = -0.20f * u;
            pitch = 10.0f * u;
            shake = sinf(t * 70.0f) * 0.035f * u;
            break;
        case E_LUNGE:
            u = fminf(e->state_t / d->lunge_time, 1.0f);
            sz = 1.40f; sy = 0.85f; pitch = -12.0f;
            hop_y = sinf(PI_F * u) * 0.22f;
            break;
        case E_RECOVER:
            sy = 0.88f; pitch = 14.0f;
            break;
        case E_STAGGER:
            roll = sinf(e->state_t * 45.0f) * 12.0f;
            back = -0.1f; pitch = -10.0f;
            break;
        case E_DEAD:
            u = smooth01(e->state_t / 0.25f);
            roll = u * 90.0f;
            lift = 0.17f * d->scale * u;   // lies on its side
            break;
        }
    }

    glPushMatrix();
    glTranslatef(e->x, hop_y + lift, e->z);
    glRotatef(e->yaw * 180.0f / PI_F, 0, 1, 0);
    glTranslatef(shake, 0.0f, back);
    glRotatef(pitch, 1, 0, 0);
    glRotatef(roll, 0, 0, 1);
    glScalef(d->scale * sx, d->scale * sy, d->scale * sz);
    draw_mesh(d->mesh);
    glPopMatrix();
}

int main(void) {
    sceCtrlSetSamplingMode(SCE_CTRL_MODE_ANALOG);

    vglInit(0x800000);
    glViewport(0, 0, 960, 544);

    build_scene();
    build_hand();
    build_sword();
    build_mace();
    build_spear();
    build_dummy();
    build_rat();
    build_crab();
    build_door();
    build_gem();
    build_npc();
    reset_enemies();
    refresh_slots();   // read any existing save files so the main menu shows them

    const float sky[4] = {0.45f, 0.55f, 0.75f, 1.0f};
    glClearColor(sky[0], sky[1], sky[2], sky[3]);
    glFogi(GL_FOG_MODE, GL_LINEAR);
    glFogf(GL_FOG_START, 14.0f);
    glFogf(GL_FOG_END, 52.0f);
    glFogfv(GL_FOG_COLOR, sky);

    float px = 0.0f, pz = 6.0f;   // player position
    float yaw = 0.0f, pitch = 0.0f;
    float t = 0.0f, bob = 0.0f;
    float cam_roll = 0.0f, cam_drop = 0.0f;
    char toast_buf[64];
    float toast_t = 0.0f;
    unsigned int prev_buttons = 0;
    int quit = 0, menu_from_pause = 0;
    uint64_t last = sceKernelGetProcessTimeWide();

    while (!quit) {
        uint64_t now = sceKernelGetProcessTimeWide();
        float dt = (now - last) / 1000000.0f;
        last = now;
        if (dt > 0.1f) dt = 0.1f;
        t += dt;
        g_time = t;
        if (screen == SCREEN_GAME) play_time += dt;
        update_xp_display(dt);
        if (toast_t > 0.0f) toast_t -= dt;
        if (hurt_flash > 0.0f) hurt_flash -= dt;

        SceCtrlData pad;
        memset(&pad, 0, sizeof(pad));
        sceCtrlPeekBufferPositive(0, &pad, 1);
        unsigned int pressed = pad.buttons & ~prev_buttons;
        prev_buttons = pad.buttons;

        float moving = 0.0f;
        char prompt_buf[64];
        const char *prompt = NULL;

        if (screen == SCREEN_TITLE) {
            // ---- main menu: three save slots ----
            if (title_confirm) {
                if (pressed & SCE_CTRL_CROSS) {
                    delete_save(title_sel);
                    title_confirm = 0;
                    snprintf(toast_buf, sizeof(toast_buf), "SLOT %d DELETED", title_sel + 1);
                    toast_t = 2.0f;
                }
                if (pressed & SCE_CTRL_CIRCLE) title_confirm = 0;
            } else {
                if ((pressed & SCE_CTRL_UP) && title_sel > 0) title_sel--;
                if ((pressed & SCE_CTRL_DOWN) && title_sel < NUM_SLOTS) title_sel++;
                if ((pressed & SCE_CTRL_SQUARE) && title_sel < NUM_SLOTS && slot_ok[title_sel]) title_confirm = 1;
                if (pressed & SCE_CTRL_CROSS) {
                    if (title_sel == NUM_SLOTS) {
                        quit = 1;
                    } else {
                        cur_slot = title_sel;
                        yaw = 0.0f; pitch = 0.0f;
                        if (slot_ok[cur_slot]) {          // continue: wake up at the beacon
                            apply_save(&slot_info[cur_slot]);
                            px = BEACON_X; pz = BEACON_Z + 3.0f;
                            snprintf(toast_buf, sizeof(toast_buf), "GAME LOADED");
                        } else {                          // new game
                            new_game_state();
                            px = 0.0f; pz = 6.0f;
                            snprintf(toast_buf, sizeof(toast_buf), "NEW GAME - SLOT %d", cur_slot + 1);
                        }
                        toast_t = 2.5f;
                        screen = SCREEN_GAME;
                    }
                }
            }
        } else if (player_dead) {
            // ---- death screen, then wake up at the start ----
            death_t += dt;
            if (death_t >= RESPAWN_DELAY) {
                player_dead = 0;
                menu = MENU_NONE;
                px = 0.0f; pz = 6.0f; yaw = 0.0f; pitch = 0.0f;
                do_rest();
                snprintf(toast_buf, sizeof(toast_buf), "YOU AWAKEN AT THE START");
                toast_t = 2.5f;
            }
        } else {
            // ---- menu open / close ----
            if (pressed & SCE_CTRL_START) {
                if (menu == MENU_NONE) { menu = MENU_PAUSE; pause_sel = 0; }
                else                   { menu = MENU_NONE; }
                menu_from_pause = 0;
            } else if ((pressed & SCE_CTRL_TRIANGLE) && (menu == MENU_NONE || menu == MENU_INVENTORY)) {
                menu = (menu == MENU_NONE) ? MENU_INVENTORY : MENU_NONE;
                menu_from_pause = 0;
                eq_focus = 0; eq_slot = active_quick; inv_sel = 0;
            }

            if (menu == MENU_INVENTORY) {
                // Equipment screen: pick one of three weapon slots, then pick what goes in it.
                if (!eq_focus) {
                    if ((pressed & SCE_CTRL_UP) && eq_slot > 0) eq_slot--;
                    if ((pressed & SCE_CTRL_DOWN) && eq_slot < QUICK_SLOTS - 1) eq_slot++;
                    if (pressed & SCE_CTRL_CROSS) {
                        eq_focus = 1;
                        inv_sel = 0;   // start the cursor on whatever is in the slot now
                        for (int i = 0; i < inv_n; i++) if (inv[i] == quick[eq_slot]) inv_sel = i + 1;
                    }
                    if (pressed & SCE_CTRL_CIRCLE) { menu = menu_from_pause ? MENU_PAUSE : MENU_NONE; menu_from_pause = 0; }
                } else {
                    if ((pressed & SCE_CTRL_UP) && inv_sel > 0) inv_sel--;
                    if ((pressed & SCE_CTRL_DOWN) && inv_sel < inv_n) inv_sel++;   // entry 0 is "EMPTY"
                    if (pressed & SCE_CTRL_CROSS) { equip_item(eq_slot, inv_sel == 0 ? -1 : inv[inv_sel - 1]); eq_focus = 0; }
                    if (pressed & SCE_CTRL_CIRCLE) eq_focus = 0;
                }
            } else if (menu == MENU_PAUSE) {
                if ((pressed & SCE_CTRL_UP) && pause_sel > 0) pause_sel--;
                if ((pressed & SCE_CTRL_DOWN) && pause_sel < 4) pause_sel++;
                if (pressed & SCE_CTRL_CROSS) {
                    switch (pause_sel) {
                    case 0: menu = MENU_NONE; break;
                    case 1: menu = MENU_INVENTORY; menu_from_pause = 1; eq_focus = 0; eq_slot = active_quick; inv_sel = 0; break;
                    case 2: menu = MENU_BESTIARY; menu_from_pause = 1; break;
                    case 3:   // back to the main menu (unsaved progress is lost)
                        menu = MENU_NONE;
                        screen = SCREEN_TITLE;
                        title_sel = cur_slot;
                        title_confirm = 0;
                        refresh_slots();
                        break;
                    default: quit = 1; break;
                    }
                }
                if (pressed & SCE_CTRL_CIRCLE) menu = MENU_NONE;
            } else if (menu == MENU_BESTIARY) {
                if ((pressed & SCE_CTRL_UP) && bestiary_sel > 0) bestiary_sel--;
                if ((pressed & SCE_CTRL_DOWN) && bestiary_sel < ENEMY_TYPE_COUNT - 1) bestiary_sel++;
                if (pressed & SCE_CTRL_CIRCLE) { menu = menu_from_pause ? MENU_PAUSE : MENU_NONE; menu_from_pause = 0; }
            } else if (menu == MENU_STATS) {
                // Level-up screen: choose where points go (LEFT/RIGHT), then CONFIRM to spend them.
                int total = pend[0] + pend[1] + pend[2];
                if ((pressed & SCE_CTRL_UP) && stats_sel > 0) stats_sel--;
                if ((pressed & SCE_CTRL_DOWN) && stats_sel < 3) stats_sel++;
                if ((pressed & SCE_CTRL_LEFT) && stats_sel < 3 && pend[stats_sel] > 0) pend[stats_sel]--;
                if (((pressed & SCE_CTRL_RIGHT) || ((pressed & SCE_CTRL_CROSS) && stats_sel < 3)) &&
                    stats_sel < 3 && xp >= levels_cost(player_level(), total + 1)) pend[stats_sel]++;
                if ((pressed & SCE_CTRL_CROSS) && stats_sel == 3) {
                    if (commit_levels(pend[0], pend[1], pend[2])) {
                        pend[0] = pend[1] = pend[2] = 0;
                        snprintf(toast_buf, sizeof(toast_buf), "LEVEL UP! NOW LEVEL %d", player_level());
                    } else {
                        snprintf(toast_buf, sizeof(toast_buf), xp >= level_cost(player_level()) ? "CHOOSE ATTRIBUTES FIRST" : "NOT ENOUGH XP");
                    }
                    toast_t = 1.5f;
                }
                if (pressed & SCE_CTRL_CIRCLE) { pend[0] = pend[1] = pend[2] = 0; menu = menu_return; }
            } else if (menu == MENU_DIALOGUE) {
                dlg_chars += DIALOGUE_CPS * dt;
                if (pressed & SCE_CTRL_CROSS) { if (npc_advance()) menu = MENU_NONE; }
                if (pressed & SCE_CTRL_CIRCLE) menu = MENU_NONE;   // walk away; he picks up where he left off
            } else if (menu == MENU_BEACON) {
                if ((pressed & SCE_CTRL_UP) && beacon_sel > 0) beacon_sel--;
                if ((pressed & SCE_CTRL_DOWN) && beacon_sel < 3) beacon_sel++;
                if (pressed & SCE_CTRL_CROSS) {
                    if (beacon_sel == 0) {          // SAVE
                        snprintf(toast_buf, sizeof(toast_buf), write_save(cur_slot) ? "GAME SAVED" : "SAVE FAILED");
                        toast_t = 2.0f;
                    } else if (beacon_sel == 1) {   // REST
                        do_rest();
                        menu = MENU_NONE;
                        snprintf(toast_buf, sizeof(toast_buf), "RESTED. ENEMIES HAVE RETURNED.");
                        toast_t = 2.5f;
                    } else if (beacon_sel == 2) {   // LEVEL UP
                        menu = MENU_STATS;
                        menu_return = MENU_BEACON;
                        stats_sel = 0;
                        pend[0] = pend[1] = pend[2] = 0;
                    } else {                        // TELEPORT (placeholder for later)
                        snprintf(toast_buf, sizeof(toast_buf), "TELEPORT COMES LATER");
                        toast_t = 2.0f;
                    }
                }
                if (pressed & SCE_CTRL_CIRCLE) menu = MENU_NONE;
            } else {
                // ---- exploration ----
                float lx = axis(pad.lx), ly = axis(pad.ly);
                float rx = axis(pad.rx), ry = axis(pad.ry);

                // Look: stick right turns right, stick up looks up.
                yaw   -= rx * LOOK_SPEED * dt;
                pitch -= ry * LOOK_SPEED * dt;
                if (pitch >  1.4f) pitch =  1.4f;
                if (pitch < -1.4f) pitch = -1.4f;

                float fx = -sinf(yaw), fz = -cosf(yaw);   // forward
                float sx =  cosf(yaw), sz = -sinf(yaw);   // right

                // Debug: SELECT hurts you so you can watch the health bar.
                if (pressed & SCE_CTRL_SELECT) damage_player(DEBUG_DAMAGE);

                // Stamina regen.
                if (stam_delay > 0.0f) {
                    stam_delay -= dt;
                } else {
                    player_stam += STAMINA_REGEN * dt;
                    if (player_stam > player_max_stam) player_stam = player_max_stam;
                }

                // Dodge (O): side-step toward the left stick, back-step if neutral.
                if ((pressed & SCE_CTRL_CIRCLE) && dodge_t < 0.0f && attack_t < 0.0f && player_stam > 0.0f) {
                    float mag = sqrtf(lx * lx + ly * ly);
                    float dright = 0.0f, dfwd = -1.0f;
                    if (mag > 0.3f) { dright = lx / mag; dfwd = -ly / mag; }
                    dodge_vx = fx * dfwd + sx * dright;
                    dodge_vz = fz * dfwd + sz * dright;
                    dodge_side = dright;
                    dodge_t = 0.0f;
                    use_stamina(DODGE_COST);
                }

                // Swap weapons (D-pad left/right): cycles through the filled weapon slots.
                if (swap_t < 0.0f && attack_t < 0.0f && dodge_t < 0.0f && (pressed & (SCE_CTRL_LEFT | SCE_CTRL_RIGHT))) {
                    int dir = (pressed & SCE_CTRL_RIGHT) ? 1 : -1;
                    for (int k = 1; k < QUICK_SLOTS; k++) {
                        int j = ((active_quick + dir * k) % QUICK_SLOTS + QUICK_SLOTS) % QUICK_SLOTS;
                        if (quick[j] >= 0) { swap_to = j; swap_t = 0.0f; swap_done = 0; break; }
                    }
                }
                if (swap_t >= 0.0f) {   // old weapon drops out of view, new one rises in
                    swap_t += dt;
                    if (!swap_done && swap_t >= SWAP_TIME * 0.5f) { active_quick = swap_to; swap_done = 1; }
                    if (swap_t >= SWAP_TIME) swap_t = -1.0f;
                }

                // Attack (R): swing the weapon in hand (style depends on the weapon).
                if ((pressed & SCE_CTRL_RTRIGGER) && attack_t < 0.0f && dodge_t < 0.0f && swap_t < 0.0f) {
                    if (equipped_id() < 0) {
                        snprintf(toast_buf, sizeof(toast_buf), "NO WEAPON EQUIPPED");
                        toast_t = 1.5f;
                    } else if (player_stam > 0.0f) {
                        attack_t = 0.0f;
                        attack_hit_mask = 0;
                        use_stamina(item_defs[equipped_id()].stamina_cost);
                    }
                }

                // Movement: a dodge overrides walking.
                float mx = 0.0f, mz = 0.0f;
                if (dodge_t >= 0.0f) {
                    float u = dodge_t / DODGE_TIME;
                    float speed = (DODGE_DISTANCE / DODGE_TIME) * 2.0f * (1.0f - u);  // eases out
                    mx = dodge_vx * speed * dt;
                    mz = dodge_vz * speed * dt;
                    dodge_t += dt;
                    if (dodge_t >= DODGE_TIME) dodge_t = -1.0f;
                } else {
                    float walk = (attack_t >= 0.0f) ? 0.5f : 1.0f;   // slower while swinging
                    float fwd = -ly, str = lx;
                    mx = (fx * fwd + sx * str) * MOVE_SPEED * walk * dt;
                    mz = (fz * fwd + sz * str) * MOVE_SPEED * walk * dt;
                    moving = sqrtf(fwd * fwd + str * str);
                    if (moving > 1.0f) moving = 1.0f;
                }
                px += mx;
                pz += mz;

                // Stay on the plane, and out of objects and walls.
                float lim = WORLD_HALF - 0.5f;
                if (px >  lim) px =  lim;
                if (px < -lim) px = -lim;
                if (pz >  lim) pz =  lim;
                if (pz < -lim) pz = -lim;
                resolve_collisions(&px, &pz, PLAYER_R);

                // Swing progress + hit checks (training dummy, then enemies).
                if (attack_t >= 0.0f && equipped_id() >= 0) {
                    const ItemDef *wd = &item_defs[equipped_id()];
                    attack_t += dt;
                    float u = attack_t / wd->swing_time;
                    if (u >= wd->hit_start && u <= wd->hit_end) {
                        float cone = cosf(wd->arc_deg * PI_F / 180.0f);

                        if (!(attack_hit_mask & 1u)) {
                            float dx = DUMMY_X - px, dz = DUMMY_Z - pz;
                            float d = sqrtf(dx * dx + dz * dz);
                            if (d < wd->range && d > 1e-4f && (fx * dx + fz * dz) / d > cone) {
                                attack_hit_mask |= 1u;
                                dummy_hits++;
                                dummy_wobble = 0.0f;
                                dummy_hit_type = wd->dmg_type;
                                dummy_hit_amp = weapon_damage(wd) * 0.45f;
                            }
                        }

                        for (int i = 0; i < NUM_ENEMIES; i++) {
                            Enemy *e = &enemies[i];
                            if (e->state == E_DEAD || (attack_hit_mask & (2u << i))) continue;
                            float dx = e->x - px, dz = e->z - pz;
                            float d = sqrtf(dx * dx + dz * dz);
                            if (d < wd->range + enemy_defs[e->type].radius && d > 1e-4f &&
                                (fx * dx + fz * dz) / d > cone) {
                                attack_hit_mask |= (2u << i);
                                hit_enemy(e, wd, px, pz);
                                if (e->state == E_DEAD) give_xp(enemy_defs[e->type].xp);
                            }
                        }
                    }
                    if (u >= 1.0f) attack_t = -1.0f;
                } else if (attack_t >= 0.0f) {
                    attack_t = -1.0f;
                }
                if (dummy_wobble >= 0.0f) {
                    dummy_wobble += dt;
                    if (dummy_wobble > 1.2f) dummy_wobble = -1.0f;
                }

                // Doors: swing open/shut; each doorway collider is only active while its door is shut.
                for (int i = 0; i < NUM_DOORS; i++) {
                    Door *dr = &doors[i];
                    float tgt = dr->target ? 1.0f : 0.0f;
                    if (dr->open_t < tgt) { dr->open_t += DOOR_OPEN_SPEED * dt; if (dr->open_t > tgt) dr->open_t = tgt; }
                    else if (dr->open_t > tgt) { dr->open_t -= DOOR_OPEN_SPEED * dt; if (dr->open_t < tgt) dr->open_t = tgt; }
                    if (dr->wall >= 0) walls[dr->wall].on = (dr->open_t < 0.35f);
                }

                // Enemies.
                for (int i = 0; i < NUM_ENEMIES; i++) update_enemy(&enemies[i], dt, px, pz);

                // Interaction: the nearest of pick-up / door / beacon in range.
                {
                    float best = 1e9f;
                    int kind = 0;
                    Pickup *near_pickup = NULL;
                    int near_door = -1;
                    for (int i = 0; i < NUM_PICKUPS; i++) {
                        if (pickups[i].taken) continue;
                        float dx = px - pickups[i].x, dz = pz - pickups[i].z;
                        float d = sqrtf(dx * dx + dz * dz);
                        if (d < PICKUP_RANGE && d < best) { best = d; kind = 1; near_pickup = &pickups[i]; }
                    }
                    for (int i = 0; i < NUM_DOORS; i++) {   // closed doors, from their near (west) side
                        if (doors[i].target) continue;
                        float dx = px - doors[i].x, dz = pz;
                        float d = sqrtf(dx * dx + dz * dz);
                        if (px < doors[i].x && d < DOOR_RANGE && d < best) { best = d; kind = 2; near_door = i; }
                    }
                    {
                        float dx = px - BEACON_X, dz = pz - BEACON_Z;
                        float d = sqrtf(dx * dx + dz * dz);
                        if (d < BEACON_RANGE && d < best) { best = d; kind = 3; }
                    }

                    {
                        float dx = px - NPC_X, dz = pz - NPC_Z;
                        float d = sqrtf(dx * dx + dz * dz);
                        if (d < NPC_RANGE && d < best) { best = d; kind = 4; }
                    }

                    if (kind == 1) snprintf(prompt_buf, sizeof(prompt_buf), "X: PICK UP %s", item_defs[near_pickup->item].name);
                    else if (kind == 2) snprintf(prompt_buf, sizeof(prompt_buf), "X: OPEN DOOR");
                    else if (kind == 3) snprintf(prompt_buf, sizeof(prompt_buf), "X: USE BEACON");
                    else if (kind == 4) snprintf(prompt_buf, sizeof(prompt_buf), "X: TALK");
                    if (kind) prompt = prompt_buf;

                    if (kind && (pressed & SCE_CTRL_CROSS)) {
                        if (kind == 1) {
                            if (inv_n < INV_MAX) {
                                inv[inv_n++] = near_pickup->item;
                                near_pickup->taken = 1;
                                snprintf(toast_buf, sizeof(toast_buf), "PICKED UP %s", item_defs[near_pickup->item].name);
                            } else {
                                snprintf(toast_buf, sizeof(toast_buf), "INVENTORY FULL");
                            }
                            toast_t = 2.0f;
                            prompt = NULL;
                        } else if (kind == 2) {
                            doors[near_door].target = 1;
                            prompt = NULL;
                        } else if (kind == 3) {
                            menu = MENU_BEACON;
                            beacon_sel = 0;
                            prompt = NULL;
                        } else {
                            menu = MENU_DIALOGUE;
                            dlg_chars = 0.0f;
                            prompt = NULL;
                        }
                    }
                }
            }
        }

        // Camera effects during a dodge.
        if (dodge_t >= 0.0f) {
            float s = sinf(PI_F * dodge_t / DODGE_TIME);
            cam_roll = dodge_side * DODGE_ROLL_DEG * s;
            cam_drop = 0.12f * s;
        } else {
            cam_roll = 0.0f;
            cam_drop = 0.0f;
        }
        bob += dt * moving * 9.0f;

        g_cam_x = px; g_cam_z = pz; g_cam_eye = EYE_HEIGHT - cam_drop;
        g_cam_yaw = yaw; g_cam_pitch = pitch; g_cam_roll = cam_roll * PI_F / 180.0f;

        // ---- draw world ----
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        if (screen == SCREEN_GAME) {
        glEnable(GL_DEPTH_TEST);
        glEnable(GL_FOG);

        set_perspective();
        glLoadIdentity();
        glRotatef(cam_roll, 0, 0, 1);
        glRotatef(-pitch * 180.0f / PI_F, 1, 0, 0);
        glRotatef(-yaw * 180.0f / PI_F, 0, 1, 0);
        glTranslatef(-px, -(EYE_HEIGHT - cam_drop), -pz);

        glEnableClientState(GL_VERTEX_ARRAY);
        glEnableClientState(GL_COLOR_ARRAY);
        draw_mesh(&world_mesh);

        // Floating, spinning pick-ups.
        for (int i = 0; i < NUM_PICKUPS; i++) {
            if (pickups[i].taken) continue;
            glPushMatrix();
            glTranslatef(pickups[i].x, 1.25f + sinf(t * 2.0f + i) * 0.1f, pickups[i].z);
            glRotatef(t * 70.0f + i * 90.0f, 0, 1, 0);
            glTranslatef(0, -0.4f, 0);
            draw_mesh(item_defs[pickups[i].item].mesh);
            glPopMatrix();
        }

        // Training dummy: slashes rock it sideways, blunt blows rock it back.
        glPushMatrix();
        glTranslatef(DUMMY_X, 0.0f, DUMMY_Z);
        if (dummy_wobble >= 0.0f) {
            float ang = sinf(dummy_wobble * 28.0f) * expf(-dummy_wobble * 5.0f) * dummy_hit_amp;
            if (dummy_hit_type == DMG_SLASH) glRotatef(ang, 0, 0, 1);
            else                             glRotatef(ang, 1, 0, 0);
        }
        draw_mesh(&dummy_mesh);
        glPopMatrix();

        // Doors (each swings open about its hinge, into the room beyond).
        for (int i = 0; i < NUM_DOORS; i++) {
            glPushMatrix();
            glTranslatef(doors[i].x, 0.0f, DOOR_HALF);
            glRotatef(-95.0f * smooth01(doors[i].open_t), 0, 1, 0);
            draw_mesh(&door_mesh);
            glPopMatrix();
        }

        // Beacon crystal.
        glPushMatrix();
        glTranslatef(BEACON_X, 1.9f + sinf(t * 2.0f) * 0.08f, BEACON_Z);
        glRotatef(t * 50.0f, 0, 1, 0);
        draw_mesh(&gem_mesh);
        glPopMatrix();

        // Enemies.
        for (int i = 0; i < NUM_ENEMIES; i++) draw_enemy(&enemies[i], t);

        // The wanderer by the door: turns to face you when you're near, breathes gently.
        {
            float tdx = px - NPC_X, tdz = pz - NPC_Z;
            float target = NPC_REST_YAW;
            if (tdx * tdx + tdz * tdz < 49.0f) target = atan2f(tdx, tdz);
            float diff = target - npc_yaw;
            while (diff >  PI_F) diff -= 2.0f * PI_F;
            while (diff < -PI_F) diff += 2.0f * PI_F;
            npc_yaw += diff * fminf(1.0f, 5.0f * dt);
            glPushMatrix();
            glTranslatef(NPC_X, 0.0f, NPC_Z);
            glRotatef(npc_yaw * 180.0f / PI_F, 0, 1, 0);
            glScalef(1.0f, 1.0f + sinf(t * 1.6f) * 0.012f, 1.0f);
            draw_mesh(&npc_mesh);
            glPopMatrix();
        }

        // ---- draw held weapon (view model) ----
        // Depth is cleared so it never clips into walls; no fog on the hand.
        glClear(GL_DEPTH_BUFFER_BIT);
        glDisable(GL_FOG);
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();

        Pose ap = {0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
        const int held = equipped_id();
        if (held >= 0) {
            const ItemDef *wd = &item_defs[held];
            if (attack_t >= 0.0f) ap = swing_pose(wd->swing, attack_t / wd->swing_time);
            ap.dx += wd->hold.dx; ap.dy += wd->hold.dy; ap.dz += wd->hold.dz;
            ap.rz += wd->hold.rz; ap.rx += wd->hold.rx; ap.ry += wd->hold.ry;
        }
        if (swap_t >= 0.0f) {   // lower the weapon out of view and bring the new one up
            float dip = sinf(PI_F * swap_t / SWAP_TIME);
            ap.dy -= 0.80f * dip;
            ap.rx -= 25.0f * dip;
        }
        float dodge_dip = (dodge_t >= 0.0f) ? 0.06f * sinf(PI_F * dodge_t / DODGE_TIME) : 0.0f;
        float vm_tx = VM_X + ap.dx + sinf(bob) * 0.012f * moving;
        float vm_ty = VM_Y + ap.dy - dodge_dip + fabsf(sinf(bob)) * 0.018f * moving + sinf(t * 1.5f) * 0.004f;
        float vm_tz = VM_Z + ap.dz;
        float vm_rz = VM_ROT_Z + ap.rz, vm_rx = VM_ROT_X + ap.rx, vm_ry = ap.ry;

        // Arm first (camera space): stays anchored at the shoulder and stretches to the wrist.
        vec3 wrist = vm_point(V(0.06f, -0.16f, 0.0f), vm_tx, vm_ty, vm_tz, vm_rz, vm_rx, vm_ry);
        build_arm(V(ARM_ANCHOR_X, ARM_ANCHOR_Y, ARM_ANCHOR_Z), wrist);
        draw_mesh(&arm_mesh);

        // Hand + weapon.
        glTranslatef(vm_tx, vm_ty, vm_tz);
        glRotatef(vm_ry, 0, 1, 0);
        glRotatef(vm_rz, 0, 0, 1);
        glRotatef(vm_rx, 1, 0, 0);
        draw_mesh(&hand_mesh);
        if (held >= 0) draw_mesh(item_defs[held].mesh);
        glDisableClientState(GL_COLOR_ARRAY);
        glDisableClientState(GL_VERTEX_ARRAY);

        }   // end of in-game drawing

        // ---- draw HUD ----
        build_hud(prompt, toast_t > 0.0f ? toast_buf : NULL);
        glDisable(GL_DEPTH_TEST);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        glOrtho(0, 960, 544, 0, -1, 1);
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();
        glEnableClientState(GL_VERTEX_ARRAY);
        glEnableClientState(GL_COLOR_ARRAY);
        glVertexPointer(2, GL_FLOAT, 0, hud_v);
        glColorPointer(4, GL_FLOAT, 0, hud_c);
        if (hud_n > 0) glDrawArrays(GL_TRIANGLES, 0, hud_n);
        glDisableClientState(GL_COLOR_ARRAY);
        glDisableClientState(GL_VERTEX_ARRAY);
        glDisable(GL_BLEND);

        // ---- spinning 3D previews (bestiary enemy / equipment weapon) ----
        if (menu == MENU_BESTIARY && bestiary_seen[bestiary_sel]) {
            const EnemyDef *bd = &enemy_defs[bestiary_sel];
            draw_preview(bd->mesh, PREVIEW_X, PREVIEW_Y, PREVIEW_W, PREVIEW_H,
                         bd->preview_scale, bd->preview_cy, bd->preview_cz, 18.0f, t * 40.0f, 0);
        } else if (menu == MENU_INVENTORY && eq_shown_item() >= 0) {
            const ItemDef *id = &item_defs[eq_shown_item()];
            draw_preview(id->mesh, EQ_PREVIEW_X, EQ_PREVIEW_Y, EQ_PREVIEW_W, EQ_PREVIEW_H,
                         id->preview_scale, id->preview_cy, 0.0f, 22.0f, t * 35.0f, 1);
        }

        vglSwapBuffers(GL_FALSE);
    }

    sceKernelExitProcess(0);
    return 0;
}
