// Plain Walk - PS Vita homebrew starter
// First-person camera on a flat plane, PS1-style low-poly props,
// pick-up weapons, a tiny inventory, and a held-weapon view model.
//
// Controls
//   Left stick   walk            Right stick  look
//   O            dodge: side-step toward the stick (back-step if neutral)
//   R            swing the equipped weapon (sword = slash, mace = overhead blow)
//   X            interact (pick up / open door / use beacon)
//   TRIANGLE     inventory       START        pause menu (inventory, bestiary, quit)
//   (menus)      D-pad up/down select, X confirm, O back
//   SELECT       debug: take damage (to test the health bar)
//
// Rendering: vitaGL (fixed-function), flat-shaded, vertex-colored, linear fog.

#include <vitasdk.h>
#include <vitaGL.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>

#define WORLD_HALF  30.0f      // plane spans -30..+30 on X and Z
#define EYE_HEIGHT  1.6f
#define MOVE_SPEED  4.5f       // units / second
#define LOOK_SPEED  2.4f       // radians / second at full stick
#define DEADZONE    0.15f
#define PLAYER_R    0.4f
#define PI_F        3.14159265f

// ---- Held-weapon placement in camera space (tweak these to taste) ----
// The weapon is modelled with its grip at the origin and the blade along +Y.
#define VM_X        0.62f      // + = right
#define VM_Y       -0.25f      // + = up
#define VM_Z       -0.74f      // - = away from camera
#define VM_ROT_Z    2.0f       // lean blade toward the left (degrees); 0 = straight up
#define VM_ROT_X   -8.0f       // tilt blade away from the camera (degrees)
// The arm is anchored off-screen at the shoulder (camera space) and stretches
// to the hand during swings.
#define ARM_ANCHOR_X        1.47f
#define ARM_ANCHOR_Y       -0.80f
#define ARM_ANCHOR_Z       -0.59f

// ---- Player stats / mechanics (tweak these) ----
#define MAX_HEALTH            100.0f
#define MAX_STAMINA           100.0f
#define STAMINA_REGEN          35.0f   // per second
#define STAMINA_REGEN_DELAY     0.8f   // seconds before regen after using stamina
#define STAMINA_EXHAUST_DELAY   1.4f   // longer delay if stamina hits zero
#define DODGE_COST             20.0f
#define DODGE_DISTANCE          3.2f   // world units
#define DODGE_TIME              0.28f  // seconds
#define DODGE_ROLL_DEG          4.0f   // camera tilt during a dodge

// ---- Weapon stats (hit_start / hit_end are fractions of the swing) ----
#define SWORD_DAMAGE         20.0f     // slashing
#define SWORD_SWING_TIME      0.55f
#define SWORD_STAMINA_COST   18.0f
#define SWORD_RANGE           2.6f
#define SWORD_ARC_DEG        80.0f     // half-angle in front of the player
#define SWORD_HIT_START       0.38f
#define SWORD_HIT_END         0.62f

#define MACE_DAMAGE          35.0f     // blunt
#define MACE_SWING_TIME       0.80f
#define MACE_STAMINA_COST    30.0f
#define MACE_RANGE            2.3f
#define MACE_ARC_DEG         50.0f
#define MACE_HIT_START        0.50f
#define MACE_HIT_END          0.72f

#define DEBUG_DAMAGE           10.0f   // SELECT button

// ---- HUD bars (pixels; colors are r, g, b) ----
#define BAR_X               24.0f
#define BAR_Y               22.0f
#define BAR_GAP              8.0f
#define HEALTH_BAR_W       320.0f      // width at 100 max health (scales with max)
#define HEALTH_BAR_H        18.0f
#define STAMINA_BAR_W      250.0f      // width at 100 max stamina (scales with max)
#define STAMINA_BAR_H       12.0f
#define HEALTH_COLOR        0.78f, 0.12f, 0.12f
#define STAMINA_COLOR       0.85f, 0.75f, 0.15f

// Training dummy position
#define DUMMY_X             2.5f
#define DUMMY_Z             0.0f

// ---- Beacon (the crystal): save / rest / teleport ----
#define BEACON_X             0.0f
#define BEACON_Z            -5.0f
#define BEACON_RANGE         2.8f

// ---- Stone room + door (east of the start area) ----
#define ROOM_X0             16.0f      // west wall (the door is in this wall)
#define ROOM_X1             26.0f
#define ROOM_Z0             -5.0f
#define ROOM_Z1              5.0f
#define ROOM_WALL_H          3.6f
#define DOOR_HALF            1.1f      // half the doorway width
#define DOOR_OPEN_SPEED      1.1f      // 1 / seconds to swing open or shut
#define DOOR_RANGE           2.6f

// ---- Giant rat (tweak these) ----
#define RAT_HEALTH          30.0f      // sword (20 dmg) = 2 hits, mace (35 dmg) = 1 hit
#define RAT_RESIST_SLASH     1.0f      // damage multipliers: 1 = neutral, >1 weak, <1 resistant
#define RAT_RESIST_BLUNT     1.0f
#define RAT_SCALE            1.8f
#define RAT_RADIUS           0.45f
#define RAT_AGGRO_RANGE      8.0f
#define RAT_HOP_SPEED        3.4f      // units / second while hopping
#define RAT_HOP_TIME         0.42f     // seconds per hop
#define RAT_ATTACK_RANGE     2.7f      // starts its wind-up this close
#define RAT_WINDUP_TIME      0.60f     // readable crouch before the lunge
#define RAT_LUNGE_TIME       0.22f
#define RAT_LUNGE_SPEED     12.0f
#define RAT_RECOVER_TIME     0.90f     // helpless after a lunge
#define RAT_STAGGER_TIME     0.35f
#define RAT_DAMAGE          12.0f
#define RAT_HIT_RADIUS       0.95f

#define DODGE_IFRAME_FRAC    0.7f      // portion of a dodge where you can't be hurt

// ---- XP / attributes (tweak these) ----
#define XP_BASE             10         // xp for the first attribute point
#define XP_STEP              5         // each point you earn makes the next one cost this much more
#define RAT_XP               5
#define HP_PER_LEVEL        10.0f      // max health per Health point
#define STAM_PER_LEVEL       8.0f      // max stamina per Stamina point
#define STR_BONUS            0.10f     // extra weapon damage per Strength point (0.10 = +10%)

// ---- Save files ----
#ifndef SAVE_DIR
#define SAVE_DIR "ux0:data/PlainWalk"  // saves: save1.dat, save2.dat, save3.dat
#endif
#define NUM_SLOTS 3

// ---- NPC next to the door ----
#define NPC_X               14.6f
#define NPC_Z                3.0f
#define NPC_REST_YAW        -1.9f      // which way he faces when you're not near
#define NPC_RANGE            2.6f
#define DIALOGUE_CPS        38.0f      // typewriter speed (characters / second)
#define RESPAWN_DELAY        2.5f      // seconds on the death screen

#define V(x, y, z)  ((vec3){(x), (y), (z)})
#define C(r, g, b)  ((rgb){(r), (g), (b)})

typedef struct { float x, y, z; } vec3;
typedef struct { float r, g, b; } rgb;
typedef struct { float x, z, r; } collider;

// ---------------------------------------------------------------- mesh ----

typedef struct { float *v; float *c; int n; int max; } Mesh;

#define DECLARE_MESH(name, maxv)                 \
    static float name##_v[(maxv) * 3];           \
    static float name##_c[(maxv) * 4];           \
    static Mesh name = { name##_v, name##_c, 0, (maxv) }

DECLARE_MESH(world_mesh, 30000);
DECLARE_MESH(hand_mesh, 1500);
DECLARE_MESH(sword_mesh, 1000);
DECLARE_MESH(mace_mesh, 1500);
DECLARE_MESH(dummy_mesh, 1500);
DECLARE_MESH(arm_mesh, 400);
DECLARE_MESH(rat_mesh, 600);
DECLARE_MESH(door_mesh, 200);
DECLARE_MESH(gem_mesh, 200);
DECLARE_MESH(npc_mesh, 500);

static Mesh *cur;   // mesh the add_* helpers currently write into

static collider colliders[64];
static int      ncolliders = 0;

static void add_collider(float x, float z, float r) {
    if (ncolliders < 64) colliders[ncolliders++] = (collider){x, z, r};
}

// Axis-aligned wall boxes (the stone room). Can be switched off (the door).
typedef struct { float x0, z0, x1, z1; int on; } wall_t;
static wall_t walls[16];
static int    nwalls = 0;
static int    door_wall = -1;

static int add_wall_collider(float x0, float z0, float x1, float z1) {
    if (nwalls >= 16) return -1;
    walls[nwalls] = (wall_t){x0, z0, x1, z1, 1};
    return nwalls++;
}

// Push a circle (x, z, radius r) out of every circle collider and active wall.
static void resolve_collisions(float *x, float *z, float r) {
    for (int i = 0; i < ncolliders; i++) {
        float dx = *x - colliders[i].x, dz = *z - colliders[i].z;
        float d = sqrtf(dx * dx + dz * dz);
        float minD = colliders[i].r + r;
        if (d < minD && d > 1e-4f) {
            *x = colliders[i].x + dx / d * minD;
            *z = colliders[i].z + dz / d * minD;
        }
    }
    for (int i = 0; i < nwalls; i++) {
        const wall_t *w = &walls[i];
        if (!w->on) continue;
        float cx = fminf(fmaxf(*x, w->x0), w->x1);
        float cz = fminf(fmaxf(*z, w->z0), w->z1);
        float dx = *x - cx, dz = *z - cz;
        float d2 = dx * dx + dz * dz;
        if (d2 >= r * r) continue;
        if (d2 > 1e-8f) {
            float d = sqrtf(d2);
            *x = cx + dx / d * r;
            *z = cz + dz / d * r;
        } else {   // centre is inside the box: leave by the nearest side
            float l = *x - w->x0, rt = w->x1 - *x, tp = *z - w->z0, bt = w->z1 - *z;
            float m = fminf(fminf(l, rt), fminf(tp, bt));
            if (m == l) *x = w->x0 - r;
            else if (m == rt) *x = w->x1 + r;
            else if (m == tp) *z = w->z0 - r;
            else *z = w->z1 + r;
        }
    }
}

static vec3 v_sub(vec3 a, vec3 b) { return V(a.x - b.x, a.y - b.y, a.z - b.z); }
static vec3 v_cross(vec3 a, vec3 b) {
    return V(a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x);
}
static vec3 v_norm(vec3 a) {
    float l = sqrtf(a.x * a.x + a.y * a.y + a.z * a.z);
    return l > 1e-6f ? V(a.x / l, a.y / l, a.z / l) : V(0, 1, 0);
}

// Flat-shaded triangle. Shading is baked from a fixed light direction and is
// two-sided, so winding order doesn't matter.
static void add_tri(vec3 a, vec3 b, vec3 c, rgb col) {
    if (cur->n + 3 > cur->max) return;

    vec3 n = v_cross(v_sub(b, a), v_sub(c, a));
    float len = sqrtf(n.x * n.x + n.y * n.y + n.z * n.z);

    float shade = 0.7f;
    if (len > 1e-6f) {
        float d = fabsf((n.x * 0.45f + n.y * 0.80f + n.z * 0.40f) / len);
        shade = 0.45f + 0.55f * d;
    }

    vec3 p[3] = {a, b, c};
    for (int i = 0; i < 3; i++) {
        int k = cur->n++;
        cur->v[k * 3 + 0] = p[i].x;
        cur->v[k * 3 + 1] = p[i].y;
        cur->v[k * 3 + 2] = p[i].z;
        cur->c[k * 4 + 0] = col.r * shade;
        cur->c[k * 4 + 1] = col.g * shade;
        cur->c[k * 4 + 2] = col.b * shade;
        cur->c[k * 4 + 3] = 1.0f;
    }
}

static void add_quad(vec3 a, vec3 b, vec3 c, vec3 d, rgb col) {
    add_tri(a, b, c, col);
    add_tri(a, c, d, col);
}

static void add_box(float cx, float y0, float cz, float sx, float sy, float sz, rgb col) {
    float x0 = cx - sx / 2, x1 = cx + sx / 2;
    float z0 = cz - sz / 2, z1 = cz + sz / 2;
    float y1 = y0 + sy;
    add_quad(V(x0, y1, z0), V(x1, y1, z0), V(x1, y1, z1), V(x0, y1, z1), col); // top
    add_quad(V(x0, y0, z1), V(x1, y0, z1), V(x1, y1, z1), V(x0, y1, z1), col); // +z
    add_quad(V(x1, y0, z0), V(x0, y0, z0), V(x0, y1, z0), V(x1, y1, z0), col); // -z
    add_quad(V(x1, y0, z1), V(x1, y0, z0), V(x1, y1, z0), V(x1, y1, z1), col); // +x
    add_quad(V(x0, y0, z0), V(x0, y0, z1), V(x0, y1, z1), V(x0, y1, z0), col); // -x
}

static void add_pyramid(float cx, float y0, float cz, float base, float height, rgb col) {
    float h = base / 2;
    vec3 p0 = V(cx - h, y0, cz - h), p1 = V(cx + h, y0, cz - h);
    vec3 p2 = V(cx + h, y0, cz + h), p3 = V(cx - h, y0, cz + h);
    vec3 apex = V(cx, y0 + height, cz);
    add_tri(p0, p1, apex, col);
    add_tri(p1, p2, apex, col);
    add_tri(p2, p3, apex, col);
    add_tri(p3, p0, apex, col);
    add_quad(p0, p1, p2, p3, col);
}

static void add_cylinder(float cx, float y0, float cz, float r, float height, int sides, rgb col) {
    float y1 = y0 + height;
    for (int i = 0; i < sides; i++) {
        float a0 = 2 * PI_F * i / sides, a1 = 2 * PI_F * (i + 1) / sides;
        vec3 b0 = V(cx + cosf(a0) * r, y0, cz + sinf(a0) * r);
        vec3 b1 = V(cx + cosf(a1) * r, y0, cz + sinf(a1) * r);
        vec3 t0 = V(b0.x, y1, b0.z), t1 = V(b1.x, y1, b1.z);
        add_quad(b0, b1, t1, t0, col);
        add_tri(V(cx, y1, cz), t0, t1, col);
    }
}

static void add_cone(float cx, float y0, float cz, float r, float height, int sides, rgb col) {
    vec3 apex = V(cx, y0 + height, cz);
    for (int i = 0; i < sides; i++) {
        float a0 = 2 * PI_F * i / sides, a1 = 2 * PI_F * (i + 1) / sides;
        vec3 b0 = V(cx + cosf(a0) * r, y0, cz + sinf(a0) * r);
        vec3 b1 = V(cx + cosf(a1) * r, y0, cz + sinf(a1) * r);
        add_tri(b0, b1, apex, col);
        add_tri(V(cx, y0, cz), b0, b1, col);
    }
}

// Tube between two arbitrary points (arms, handles, shafts).
static void add_prism(vec3 a, vec3 b, float r, int sides, rgb col) {
    vec3 d = v_norm(v_sub(b, a));
    vec3 ref = fabsf(d.y) < 0.9f ? V(0, 1, 0) : V(1, 0, 0);
    vec3 u = v_norm(v_cross(d, ref));
    vec3 w = v_cross(d, u);
    for (int i = 0; i < sides; i++) {
        float a0 = 2 * PI_F * i / sides, a1 = 2 * PI_F * (i + 1) / sides;
        float c0 = cosf(a0) * r, s0 = sinf(a0) * r, c1 = cosf(a1) * r, s1 = sinf(a1) * r;
        vec3 o0 = V(u.x * c0 + w.x * s0, u.y * c0 + w.y * s0, u.z * c0 + w.z * s0);
        vec3 o1 = V(u.x * c1 + w.x * s1, u.y * c1 + w.y * s1, u.z * c1 + w.z * s1);
        vec3 a0p = V(a.x + o0.x, a.y + o0.y, a.z + o0.z), a1p = V(a.x + o1.x, a.y + o1.y, a.z + o1.z);
        vec3 b0p = V(b.x + o0.x, b.y + o0.y, b.z + o0.z), b1p = V(b.x + o1.x, b.y + o1.y, b.z + o1.z);
        add_quad(a0p, a1p, b1p, b0p, col);
        add_tri(b, b0p, b1p, col);
    }
}

static void add_octahedron(float cx, float cy, float cz, float r, rgb c1, rgb c2) {
    vec3 top = V(cx, cy + r * 1.4f, cz), bot = V(cx, cy - r * 1.4f, cz);
    vec3 e[4] = {V(cx + r, cy, cz), V(cx, cy, cz + r), V(cx - r, cy, cz), V(cx, cy, cz - r)};
    for (int i = 0; i < 4; i++) {
        vec3 a = e[i], b = e[(i + 1) % 4];
        add_tri(a, b, top, (i & 1) ? c1 : c2);
        add_tri(b, a, bot, (i & 1) ? c2 : c1);
    }
}

// --------------------------------------------------------------- scene ----

static void build_ground(void) {
    const int n = 30;
    const float t = 2.0f;
    for (int j = 0; j < n; j++) {
        for (int i = 0; i < n; i++) {
            float x0 = -WORLD_HALF + i * t, z0 = -WORLD_HALF + j * t;
            float var = ((i * 7 + j * 13) % 3) * 0.025f;
            rgb c = ((i + j) & 1) ? C(0.26f + var, 0.50f + var, 0.22f)
                                  : C(0.22f + var, 0.44f + var, 0.19f);
            add_quad(V(x0, 0, z0), V(x0, 0, z0 + t), V(x0 + t, 0, z0 + t), V(x0 + t, 0, z0), c);
        }
    }
}

static void add_tree(float x, float z) {
    add_cylinder(x, 0.0f, z, 0.25f, 1.6f, 6, C(0.40f, 0.26f, 0.14f));
    add_cone(x, 1.4f, z, 1.4f, 3.2f, 7, C(0.10f, 0.35f, 0.14f));
    add_cone(x, 3.0f, z, 1.0f, 2.4f, 7, C(0.13f, 0.42f, 0.17f));
    add_collider(x, z, 0.5f);
}

static void add_wall_block(float x0, float z0, float x1, float z1, float h, rgb col) {
    add_box((x0 + x1) / 2, 0.0f, (z0 + z1) / 2, x1 - x0, h, z1 - z0, col);
    add_wall_collider(x0, z0, x1, z1);
}

// A small enclosed stone room with a door in its west wall.
static void build_room(void) {
    rgb stone = C(0.46f, 0.46f, 0.52f), stone2 = C(0.40f, 0.40f, 0.46f), roof = C(0.26f, 0.26f, 0.31f);
    const float T = 0.25f;   // half wall thickness

    // Floor: dark checkered flagstones just above the grass.
    for (int j = 0; j < 5; j++) {
        for (int i = 0; i < 5; i++) {
            float x0 = ROOM_X0 + i * 2.0f, z0 = ROOM_Z0 + j * 2.0f;
            rgb c = ((i + j) & 1) ? C(0.32f, 0.32f, 0.36f) : C(0.27f, 0.27f, 0.31f);
            add_quad(V(x0, 0.03f, z0), V(x0, 0.03f, z0 + 2), V(x0 + 2, 0.03f, z0 + 2), V(x0 + 2, 0.03f, z0), c);
        }
    }

    add_wall_block(ROOM_X0 - T, ROOM_Z0 - T, ROOM_X1 + T, ROOM_Z0 + T, ROOM_WALL_H, stone);    // north
    add_wall_block(ROOM_X0 - T, ROOM_Z1 - T, ROOM_X1 + T, ROOM_Z1 + T, ROOM_WALL_H, stone);    // south
    add_wall_block(ROOM_X1 - T, ROOM_Z0 + T, ROOM_X1 + T, ROOM_Z1 - T, ROOM_WALL_H, stone2);   // east
    add_wall_block(ROOM_X0 - T, ROOM_Z0 + T, ROOM_X0 + T, -DOOR_HALF, ROOM_WALL_H, stone2);    // west, left of door
    add_wall_block(ROOM_X0 - T, DOOR_HALF, ROOM_X0 + T, ROOM_Z1 - T, ROOM_WALL_H, stone2);     // west, right of door
    add_box(ROOM_X0, 2.8f, 0.0f, 2 * T, ROOM_WALL_H - 2.8f, 2 * DOOR_HALF, stone);            // lintel over the door
    add_box((ROOM_X0 + ROOM_X1) / 2, ROOM_WALL_H, (ROOM_Z0 + ROOM_Z1) / 2,
            (ROOM_X1 - ROOM_X0) + 2 * T + 0.2f, 0.3f, (ROOM_Z1 - ROOM_Z0) + 2 * T + 0.2f, roof);   // roof

    // Invisible-when-open collider that fills the doorway while the door is shut.
    door_wall = add_wall_collider(ROOM_X0 - 0.2f, -DOOR_HALF, ROOM_X0 + 0.2f, DOOR_HALF);

    // A couple of crates for atmosphere.
    add_box(24.6f, 0.0f, -3.6f, 1.4f, 1.4f, 1.4f, C(0.55f, 0.38f, 0.18f));
    add_collider(24.6f, -3.6f, 1.0f);
    add_box(24.8f, 0.0f, 3.7f, 1.2f, 1.2f, 1.2f, C(0.50f, 0.34f, 0.16f));
    add_collider(24.8f, 3.7f, 0.9f);
}

static void build_scene(void) {
    cur = &world_mesh;
    build_ground();

    // Crate stack
    add_box(6.0f, 0.0f, -6.0f, 2.0f, 2.0f, 2.0f, C(0.62f, 0.42f, 0.20f));
    add_box(6.3f, 2.0f, -6.0f, 1.2f, 1.2f, 1.2f, C(0.70f, 0.48f, 0.24f));
    add_collider(6.0f, -6.0f, 1.45f);

    // Sand pyramid
    add_pyramid(-9.0f, 0.0f, -11.0f, 6.0f, 5.0f, C(0.80f, 0.70f, 0.42f));
    add_collider(-9.0f, -11.0f, 3.0f);

    // Trees
    add_tree(-5.0f, 4.0f);
    add_tree(4.0f, 9.0f);
    add_tree(-13.0f, 6.0f);
    add_tree(11.0f, 3.0f);
    add_tree(15.0f, -13.0f);

    // Ring of stone pillars around the start point
    for (int i = 0; i < 8; i++) {
        float a = 2 * PI_F * i / 8;
        float x = cosf(a) * 11.0f, z = sinf(a) * 11.0f;
        add_cylinder(x, 0.0f, z, 0.5f, 3.5f, 8, C(0.58f, 0.58f, 0.62f));
        add_box(x, 3.5f, z, 1.3f, 0.35f, 1.3f, C(0.48f, 0.48f, 0.52f));
        add_collider(x, z, 0.75f);
    }

    // Pedestal (the beacon crystal floats above it and is drawn separately)
    add_box(0.0f, 0.0f, -5.0f, 1.4f, 0.8f, 1.4f, C(0.50f, 0.50f, 0.54f));
    add_collider(0.0f, -5.0f, 1.1f);

    build_room();
}

// ------------------------------------------------- weapons & right hand ----
// Weapon meshes: grip at the origin, blade/shaft along +Y, flat faces toward +Z.

static void build_sword(void) {
    cur = &sword_mesh;
    rgb leather = C(0.35f, 0.22f, 0.12f);
    rgb steel = C(0.70f, 0.76f, 0.80f), steel2 = C(0.52f, 0.60f, 0.66f);
    rgb guard = C(0.42f, 0.50f, 0.58f);

    add_prism(V(0, -0.20f, 0), V(0, 0.0f, 0), 0.022f, 6, leather);   // grip
    add_box(0, -0.25f, 0, 0.07f, 0.05f, 0.07f, guard);               // pommel
    add_box(0, 0.0f, 0, 0.20f, 0.035f, 0.05f, guard);                // cross-guard
    add_box(-0.14f, 0.0f, 0, 0.07f, 0.09f, 0.04f, guard);            // guard wings
    add_box( 0.14f, 0.0f, 0, 0.07f, 0.09f, 0.04f, guard);

    // Diamond cross-section blade with a pointed tip.
    float y0 = 0.035f, ysh = 0.72f, y1 = 0.88f, hw = 0.06f, ht = 0.016f;
    vec3 bl = V(-hw, y0, 0), br = V(hw, y0, 0), bf = V(0, y0, ht), bb = V(0, y0, -ht);
    vec3 sl = V(-hw, ysh, 0), sr = V(hw, ysh, 0), sf = V(0, ysh, ht), sb = V(0, ysh, -ht);
    vec3 tip = V(0, y1, 0);
    add_quad(bl, bf, sf, sl, steel);
    add_quad(bf, br, sr, sf, steel2);
    add_quad(bb, bl, sl, sb, steel2);
    add_quad(br, bb, sb, sr, steel);
    add_tri(sl, sf, tip, steel);
    add_tri(sf, sr, tip, steel2);
    add_tri(sb, sl, tip, steel2);
    add_tri(sr, sb, tip, steel);
}

static void build_mace(void) {
    cur = &mace_mesh;
    rgb wood = C(0.42f, 0.28f, 0.15f), iron = C(0.45f, 0.47f, 0.52f), iron2 = C(0.58f, 0.60f, 0.66f);

    add_prism(V(0, -0.22f, 0), V(0, 0.55f, 0), 0.025f, 6, wood);     // shaft
    add_box(0, -0.27f, 0, 0.07f, 0.05f, 0.07f, iron);                // pommel
    add_cylinder(0, 0.48f, 0, 0.085f, 0.20f, 8, iron);               // head
    add_cone(0, 0.68f, 0, 0.085f, 0.12f, 8, iron2);                  // top spike
    add_box(-0.115f, 0.54f, 0, 0.06f, 0.07f, 0.06f, iron2);          // studs
    add_box( 0.115f, 0.54f, 0, 0.06f, 0.07f, 0.06f, iron2);
    add_box(0, 0.54f, -0.115f, 0.06f, 0.07f, 0.06f, iron2);
    add_box(0, 0.54f,  0.115f, 0.06f, 0.07f, 0.06f, iron2);
}

// Right hand + forearm, fingers wrapped around the grip, arm leaving the
// bottom-right corner of the screen.
static void build_hand(void) {
    cur = &hand_mesh;
    rgb skin = C(0.80f, 0.58f, 0.44f), skin2 = C(0.70f, 0.50f, 0.38f);

    add_box(0.035f, -0.155f, -0.005f, 0.11f, 0.14f, 0.05f, skin2);   // back of hand
    for (int k = 0; k < 4; k++)                                      // fingers
        add_box(0.01f, -0.15f + 0.034f * k, 0.035f, 0.095f, 0.03f, 0.045f, skin);
    add_box(-0.03f, -0.03f, 0.035f, 0.035f, 0.035f, 0.045f, skin);   // thumb
}

// Straw training dummy (origin at its base). Swing at it to test attacks.
static void build_dummy(void) {
    cur = &dummy_mesh;
    rgb wood = C(0.40f, 0.28f, 0.16f), straw = C(0.78f, 0.68f, 0.42f), straw2 = C(0.66f, 0.56f, 0.34f);
    add_cylinder(0, 0.0f, 0, 0.5f, 0.08f, 8, C(0.36f, 0.26f, 0.15f));   // base
    add_cylinder(0, 0.0f, 0, 0.12f, 1.2f, 6, wood);                      // post
    add_box(0, 0.88f, 0, 0.95f, 0.12f, 0.12f, wood);                     // arms
    add_box(0, 0.55f, 0, 0.55f, 0.75f, 0.30f, straw);                    // torso
    add_octahedron(0, 1.55f, 0, 0.22f, straw, straw2);                   // head
    add_collider(DUMMY_X, DUMMY_Z, 0.55f);
}

// Blocky PS1-style rat (origin at its feet, snout toward +Z).
static void build_rat(void) {
    cur = &rat_mesh;
    rgb fur = C(0.46f, 0.38f, 0.32f), fur2 = C(0.38f, 0.31f, 0.26f);
    rgb pink = C(0.80f, 0.55f, 0.55f), eye = C(0.95f, 0.15f, 0.12f), tooth = C(0.92f, 0.90f, 0.80f);

    add_box(0.0f, 0.08f, -0.05f, 0.30f, 0.24f, 0.50f, fur);        // body
    add_box(0.0f, 0.10f, -0.24f, 0.34f, 0.28f, 0.24f, fur2);       // haunches
    add_box(0.0f, 0.12f, 0.28f, 0.20f, 0.18f, 0.22f, fur);         // head
    add_box(0.0f, 0.14f, 0.44f, 0.11f, 0.11f, 0.14f, fur2);        // snout
    add_box(0.0f, 0.17f, 0.52f, 0.05f, 0.05f, 0.04f, pink);        // nose
    add_box(0.0f, 0.08f, 0.46f, 0.05f, 0.05f, 0.03f, tooth);       // buck teeth
    add_box(-0.10f, 0.28f, 0.20f, 0.07f, 0.10f, 0.03f, pink);      // ears
    add_box( 0.10f, 0.28f, 0.20f, 0.07f, 0.10f, 0.03f, pink);
    add_box(-0.075f, 0.22f, 0.385f, 0.035f, 0.035f, 0.03f, eye);   // eyes
    add_box( 0.075f, 0.22f, 0.385f, 0.035f, 0.035f, 0.03f, eye);
    add_box(-0.11f, 0.0f, 0.14f, 0.07f, 0.10f, 0.09f, fur2);       // legs
    add_box( 0.11f, 0.0f, 0.14f, 0.07f, 0.10f, 0.09f, fur2);
    add_box(-0.13f, 0.0f, -0.26f, 0.08f, 0.12f, 0.12f, fur2);
    add_box( 0.13f, 0.0f, -0.26f, 0.08f, 0.12f, 0.12f, fur2);
    add_prism(V(0.0f, 0.16f, -0.36f), V(0.0f, 0.10f, -0.62f), 0.022f, 4, pink);   // tail
    add_prism(V(0.0f, 0.10f, -0.62f), V(0.0f, 0.20f, -0.88f), 0.018f, 4, pink);
}

// Door slab with its hinge at the origin, extending along -Z.
static void build_door(void) {
    cur = &door_mesh;
    rgb wood = C(0.40f, 0.26f, 0.14f), iron = C(0.30f, 0.30f, 0.34f);
    const float w = 2.0f * DOOR_HALF + 0.05f;
    add_box(0.0f, 0.0f, -w / 2, 0.14f, 2.7f, w, wood);
    add_box(0.0f, 0.5f, -w / 2, 0.18f, 0.12f, w, iron);
    add_box(0.0f, 1.9f, -w / 2, 0.18f, 0.12f, w, iron);
    add_box(0.12f, 1.2f, -w + 0.25f, 0.08f, 0.10f, 0.10f, iron);   // handle
}

// Hooded wanderer (origin at his feet, facing +Z).
static void build_npc(void) {
    cur = &npc_mesh;
    rgb cloth = C(0.30f, 0.27f, 0.24f), cloth2 = C(0.24f, 0.21f, 0.19f), hood = C(0.36f, 0.30f, 0.22f);
    rgb skin = C(0.78f, 0.62f, 0.50f), dark = C(0.10f, 0.08f, 0.08f), belt = C(0.45f, 0.30f, 0.14f);

    add_box(-0.12f, 0.0f, 0.0f, 0.16f, 0.7f, 0.20f, dark);            // legs
    add_box( 0.12f, 0.0f, 0.0f, 0.16f, 0.7f, 0.20f, dark);
    add_box(0.0f, 0.12f, 0.0f, 0.72f, 0.55f, 0.46f, cloth2);          // cloak skirt
    add_box(0.0f, 0.60f, 0.0f, 0.60f, 0.80f, 0.38f, cloth);           // torso
    add_box(0.0f, 0.62f, 0.0f, 0.64f, 0.08f, 0.42f, belt);            // belt
    add_box(-0.38f, 0.72f, 0.04f, 0.14f, 0.60f, 0.18f, cloth);        // arms
    add_box( 0.38f, 0.72f, 0.04f, 0.14f, 0.60f, 0.18f, cloth);
    add_box(-0.38f, 0.64f, 0.06f, 0.11f, 0.11f, 0.11f, skin);         // hands
    add_box( 0.38f, 0.64f, 0.06f, 0.11f, 0.11f, 0.11f, skin);
    add_box(0.0f, 1.20f, 0.0f, 0.30f, 0.30f, 0.30f, skin);            // head
    add_box(-0.07f, 1.32f, 0.152f, 0.05f, 0.05f, 0.02f, dark);        // eyes
    add_box( 0.07f, 1.32f, 0.152f, 0.05f, 0.05f, 0.02f, dark);
    add_box(0.0f, 1.48f, -0.02f, 0.42f, 0.12f, 0.40f, hood);          // hood top
    add_box(0.0f, 1.18f, -0.12f, 0.42f, 0.34f, 0.18f, hood);          // hood back
    add_box(-0.21f, 1.18f, 0.03f, 0.06f, 0.34f, 0.32f, hood);         // hood sides
    add_box( 0.21f, 1.18f, 0.03f, 0.06f, 0.34f, 0.32f, hood);
    add_collider(NPC_X, NPC_Z, 0.5f);
}

// The beacon crystal (spins and bobs above the pedestal).
static void build_gem(void) {
    cur = &gem_mesh;
    add_octahedron(0.0f, 0.0f, 0.0f, 0.6f, C(0.25f, 0.85f, 0.95f), C(0.85f, 0.30f, 0.90f));
}

// ----------------------------------------------------------- inventory ----

typedef enum { ITEM_SWORD = 0, ITEM_MACE = 1, ITEM_COUNT } ItemId;

// Damage tags. Enemies can later resist or be weak to these.
typedef enum { DMG_SLASH = 0, DMG_BLUNT = 1, DMG_TYPE_COUNT } DamageType;
static const char *const dmg_type_names[DMG_TYPE_COUNT] = { "SLASHING", "BLUNT" };
static const char *const dmg_type_short[DMG_TYPE_COUNT] = { "SLASH", "BLUNT" };

// Weapon pose offsets (added to the resting view model) for swing animations.
typedef struct { float dx, dy, dz, rz, rx; } Pose;
typedef struct { float t[5]; Pose p[5]; } Swing;   // 5 keyframes, t runs 0..1 over the swing

// Sword: horizontal slash, left to right.
static const Swing sword_swing = {
    {0.00f, 0.30f, 0.52f, 0.62f, 1.00f},
    {
        { 0.00f,  0.00f,  0.00f,   0.0f,   0.0f},   // rest
        {-0.80f,  0.04f,  0.02f,  58.0f, -12.0f},   // wind-up: drawn across to the left
        { 0.05f, -0.10f, -0.16f, -68.0f, -34.0f},   // slash: swept left to right
        { 0.10f, -0.12f, -0.18f, -76.0f, -38.0f},   // follow-through
        { 0.00f,  0.00f,  0.00f,   0.0f,   0.0f},   // back to rest
    }
};

// Mace: overhead hammer blow, top to bottom.
static const Swing mace_swing = {
    {0.00f, 0.34f, 0.56f, 0.68f, 1.00f},
    {
        { 0.00f,  0.00f,  0.00f,   0.0f,   0.0f},   // rest
        {-0.05f,  0.48f,  0.06f,  -2.0f,  24.0f},   // wind-up: hoisted high
        {-0.05f, -0.22f, -0.24f,   0.0f, -92.0f},   // slam: down and forward
        {-0.05f, -0.26f, -0.26f,   0.0f, -100.0f},  // impact
        { 0.00f,  0.00f,  0.00f,   0.0f,   0.0f},   // back to rest
    }
};

typedef struct {
    const char *name;
    const char *desc;
    Mesh *mesh;
    DamageType dmg_type;
    float damage;
    float swing_time, stamina_cost, range, arc_deg, hit_start, hit_end;
    const Swing *swing;
} ItemDef;

static const ItemDef item_defs[ITEM_COUNT] = {
    { "IRON SWORD", "A PLAIN BLADE. STILL SHARP.", &sword_mesh,
      DMG_SLASH, SWORD_DAMAGE, SWORD_SWING_TIME, SWORD_STAMINA_COST, SWORD_RANGE, SWORD_ARC_DEG,
      SWORD_HIT_START, SWORD_HIT_END, &sword_swing },
    { "STONE MACE", "HEAVY AND BLUNT.", &mace_mesh,
      DMG_BLUNT, MACE_DAMAGE, MACE_SWING_TIME, MACE_STAMINA_COST, MACE_RANGE, MACE_ARC_DEG,
      MACE_HIT_START, MACE_HIT_END, &mace_swing },
};

#define INV_MAX 8
static int inv[INV_MAX];          // item ids
static int inv_n = 0;
static int equipped_slot = -1;    // index into inv[], -1 = empty hand
typedef enum { MENU_NONE = 0, MENU_INVENTORY, MENU_PAUSE, MENU_BESTIARY, MENU_BEACON, MENU_DIALOGUE, MENU_STATS } MenuId;
static int menu = MENU_NONE;
static int pause_sel = 0, bestiary_sel = 0, beacon_sel = 0, stats_sel = 0, menu_return = MENU_PAUSE;
static int inv_sel = 0;

// ---- player state ----
static float player_max_hp = MAX_HEALTH,  player_hp = MAX_HEALTH;
static float player_max_stam = MAX_STAMINA, player_stam = MAX_STAMINA;
static float stam_delay = 0.0f;                       // time until stamina regen resumes
static float dodge_t = -1.0f;                         // seconds into a dodge, -1 = idle
static float dodge_vx = 0.0f, dodge_vz = 0.0f, dodge_side = 0.0f;
static float attack_t = -1.0f;                        // seconds into a swing, -1 = idle
static unsigned attack_hit_mask = 0;                  // which targets this swing already hit
static float dummy_wobble = -1.0f;                    // seconds since dummy was hit, -1 = still
static float dummy_hit_amp = 0.0f;
static DamageType dummy_hit_type = DMG_SLASH;
static int   dummy_hits = 0;

static void use_stamina(float cost) {
    player_stam -= cost;
    if (player_stam <= 0.0f) { player_stam = 0.0f; stam_delay = STAMINA_EXHAUST_DELAY; }
    else                     { stam_delay = STAMINA_REGEN_DELAY; }
}

static float smooth01(float u) {
    if (u < 0.0f) u = 0.0f;
    if (u > 1.0f) u = 1.0f;
    return u * u * (3.0f - 2.0f * u);
}

static Pose swing_pose(const Swing *sw, float u) {
    if (u <= 0.0f) return sw->p[0];
    if (u >= 1.0f) return sw->p[4];
    int i = 0;
    while (i < 3 && u > sw->t[i + 1]) i++;
    float f = smooth01((u - sw->t[i]) / (sw->t[i + 1] - sw->t[i]));
    Pose a = sw->p[i], b = sw->p[i + 1], r;
    r.dx = a.dx + (b.dx - a.dx) * f;
    r.dy = a.dy + (b.dy - a.dy) * f;
    r.dz = a.dz + (b.dz - a.dz) * f;
    r.rz = a.rz + (b.rz - a.rz) * f;
    r.rx = a.rx + (b.rx - a.rx) * f;
    return r;
}

typedef struct { float x, z; int item; int taken; } Pickup;
static Pickup pickups[] = {
    { -2.5f, 2.5f, ITEM_SWORD, 0 },
    {  7.0f, -1.5f, ITEM_MACE, 0 },
};
#define NUM_PICKUPS ((int)(sizeof(pickups) / sizeof(pickups[0])))
#define PICKUP_RANGE 2.2f

// ------------------------------------------------------------ enemies ----

typedef enum { ENEMY_RAT = 0, ENEMY_TYPE_COUNT } EnemyType;

typedef struct {
    const char *name;
    const char *desc[2];            // two short lines for the bestiary
    Mesh *mesh;
    float max_hp;
    float resist[DMG_TYPE_COUNT];   // damage multiplier per damage tag: 1 neutral, >1 weak, <1 resistant
    float bar_height;               // world height of the health bar above the ground
    float radius;
    float scale;
    int xp;                         // xp granted when killed
} EnemyDef;

static const EnemyDef enemy_defs[ENEMY_TYPE_COUNT] = {
    { "GIANT RAT",
      { "A BLOCKY SEWER PEST THAT HOPS CLOSER.", "WATCH FOR THE CROUCH - THEN THE LUNGE." },
      &rat_mesh, RAT_HEALTH, { RAT_RESIST_SLASH, RAT_RESIST_BLUNT }, 0.95f, RAT_RADIUS, RAT_SCALE, RAT_XP },
};

typedef enum { E_IDLE = 0, E_CHASE, E_WINDUP, E_LUNGE, E_RECOVER, E_STAGGER, E_DEAD } EnemyState;

typedef struct {
    int type;
    float spawn_x, spawn_z, spawn_yaw;
    float x, z, yaw, hp;
    int state;
    float state_t, hop;
    float lunge_x, lunge_z;
    int lunge_hit;
    float kb_x, kb_z;
} Enemy;

static Enemy enemies[] = {
    { .type = ENEMY_RAT, .spawn_x = 22.5f, .spawn_z = 0.0f, .spawn_yaw = -PI_F / 2.0f },
};
#define NUM_ENEMIES ((int)(sizeof(enemies) / sizeof(enemies[0])))

static int bestiary_seen[ENEMY_TYPE_COUNT];

// ---- NPC dialogue (Dark Souls style: a box at the bottom, text typed out in chunks) ----
// The progress lives in these globals only: resting, dying (and, later, loading a save)
// never touch them, so once he's said his piece he only ever repeats the short line.
static const char *const npc_lines[] = {
    "Who me? I don't know what I'm doing here.",
    "What are you doing here? You don't know either?",
    "Well, this is a test room buddy.",
    "There's a rat behind the door.",
    "Go on, kill it.",
};
#define NPC_LINES ((int)(sizeof(npc_lines) / sizeof(npc_lines[0])))
static const char *const npc_repeat = "Go on buddy, get in there.";
static int   npc_line = 0;        // which chunk he's on
static int   npc_done = 0;        // 1 once the whole speech has been heard
static float dlg_chars = 0.0f;    // characters of the current chunk shown so far
static float npc_yaw = NPC_REST_YAW;
static float g_time = 0.0f;       // seconds since start (for blinking HUD bits)

static const char *npc_text(void) { return npc_done ? npc_repeat : npc_lines[npc_line]; }

// X pressed during dialogue: finish typing, else go to the next chunk. Returns 1 to close the box.
static int npc_advance(void) {
    int len = (int)strlen(npc_text());
    if (dlg_chars < (float)len) { dlg_chars = (float)len; return 0; }
    if (npc_done) return 1;
    if (npc_line + 1 < NPC_LINES) { npc_line++; dlg_chars = 0.0f; return 0; }
    npc_done = 1;
    return 1;
}

// ---- door ----
static float door_open_t = 0.0f;   // 0 shut .. 1 open
static int   door_target = 0;      // 1 = opening / open

// ---- player survival state ----
static int   player_dead = 0;
static float death_t = 0.0f;
static float hurt_flash = 0.0f;

// ---- camera (set each frame; used to project things onto the HUD) ----
static float g_cam_x = 0, g_cam_z = 0, g_cam_eye = 0, g_cam_yaw = 0, g_cam_pitch = 0, g_cam_roll = 0;

static int player_in_room(float x, float z) {
    return x > ROOM_X0 && x < ROOM_X1 && z > ROOM_Z0 && z < ROOM_Z1;
}

static void damage_player(float amount) {
    if (player_dead) return;
    if (dodge_t >= 0.0f && dodge_t < DODGE_TIME * DODGE_IFRAME_FRAC) return;   // dodge i-frames
    player_hp -= amount;
    hurt_flash = 0.4f;
    if (player_hp <= 0.0f) { player_hp = 0.0f; player_dead = 1; death_t = 0.0f; }
}

// World point -> screen pixels (same maths as the GL view + projection). 0 if behind the camera.
static int project_point(float wx, float wy, float wz, float *sx, float *sy) {
    float x = wx - g_cam_x, y = wy - g_cam_eye, z = wz - g_cam_z;
    float x1 = x * cosf(g_cam_yaw) - z * sinf(g_cam_yaw);
    float z1 = x * sinf(g_cam_yaw) + z * cosf(g_cam_yaw);
    float y2 = y * cosf(g_cam_pitch) + z1 * sinf(g_cam_pitch);
    float z2 = -y * sinf(g_cam_pitch) + z1 * cosf(g_cam_pitch);
    float x3 = x1 * cosf(g_cam_roll) - y2 * sinf(g_cam_roll);
    float y3 = x1 * sinf(g_cam_roll) + y2 * cosf(g_cam_roll);
    if (z2 > -0.2f) return 0;
    const float tv = 0.70020753f;   // tan(35 degrees)
    *sx = (x3 / (-z2 * tv * (960.0f / 544.0f)) + 1.0f) * 0.5f * 960.0f;
    *sy = (1.0f - y3 / (-z2 * tv)) * 0.5f * 544.0f;
    return 1;
}

static void reset_enemies(void) {
    for (int i = 0; i < NUM_ENEMIES; i++) {
        Enemy *e = &enemies[i];
        e->x = e->spawn_x;
        e->z = e->spawn_z;
        e->yaw = e->spawn_yaw;
        e->hp = enemy_defs[e->type].max_hp;
        e->state = E_IDLE;
        e->state_t = 0.0f;
        e->hop = 0.0f;
        e->lunge_hit = 0;
        e->kb_x = e->kb_z = 0.0f;
    }
}

// ---------------------------------------------------- xp / attributes ----
// Killing things gives xp. Every time the xp bar fills you earn an attribute point (and the next
// point costs more). Points stack up until you spend them on Health, Stamina or Strength.

static int xp = 0;               // progress toward the next point
static int points_earned = 0;    // total points ever earned (sets the next cost)
static int points_free = 0;      // unspent points
static int lv_hp = 0, lv_stam = 0, lv_str = 0;
static float play_time = 0.0f;   // seconds, shown on the save slots

static int xp_cost(void) { return XP_BASE + XP_STEP * points_earned; }
static int player_level(void) { return 1 + lv_hp + lv_stam + lv_str; }
static float str_mult(void) { return 1.0f + STR_BONUS * (float)lv_str; }
static float weapon_damage(const ItemDef *d) { return d->damage * str_mult(); }

static void recompute_stats(void) {
    player_max_hp   = MAX_HEALTH  + HP_PER_LEVEL   * (float)lv_hp;
    player_max_stam = MAX_STAMINA + STAM_PER_LEVEL * (float)lv_stam;
}

// Adds xp; returns how many attribute points that earned.
static int give_xp(int amount) {
    int gained = 0;
    xp += amount;
    while (xp >= xp_cost()) {
        xp -= xp_cost();
        points_earned++;
        points_free++;
        gained++;
    }
    return gained;
}

// stat: 0 health, 1 stamina, 2 strength. Returns 1 if a point was spent.
static int spend_point(int stat) {
    if (points_free <= 0) return 0;
    float oh = player_max_hp, os = player_max_stam;
    points_free--;
    if (stat == 0) lv_hp++; else if (stat == 1) lv_stam++; else lv_str++;
    recompute_stats();
    player_hp   += player_max_hp   - oh;   // the new capacity arrives full
    player_stam += player_max_stam - os;
    return 1;
}

// Resting at the beacon: heals you, respawns enemies, shuts the door. Items are kept.
static void do_rest(void) {
    player_hp = player_max_hp;
    player_stam = player_max_stam;
    stam_delay = 0.0f;
    dodge_t = -1.0f;
    attack_t = -1.0f;
    dummy_wobble = -1.0f;
    reset_enemies();
    door_target = 0;
}

// ------------------------------------------------------------ saving ----
typedef enum { SCREEN_TITLE = 0, SCREEN_GAME } ScreenId;
static int screen = SCREEN_TITLE;
static int title_sel = 0, title_confirm = 0, cur_slot = 0;

#define SAVE_MAGIC 0x32574C50u   // "PLW2"
typedef struct {
    unsigned magic;
    int xp, points_earned, points_free, lv_hp, lv_stam, lv_str;
    int inv_n, inv[INV_MAX], equipped_slot;
    int pickup_taken[16];
    int npc_done, npc_line;      // the wanderer's dialogue is part of the save
    int bestiary_seen[8];
    float play_time;
} SaveData;
_Static_assert(sizeof(pickups) / sizeof(pickups[0]) <= 16, "save: too many pickups");
_Static_assert(ENEMY_TYPE_COUNT <= 8, "save: too many enemy types");

static SaveData slot_info[NUM_SLOTS];
static int      slot_ok[NUM_SLOTS];

static void save_path(int slot, char *buf, size_t n) { snprintf(buf, n, SAVE_DIR "/save%d.dat", slot + 1); }

static int read_save(int slot, SaveData *out) {
    char path[128];
    save_path(slot, path, sizeof(path));
    FILE *f = fopen(path, "rb");
    if (!f) return 0;
    int ok = fread(out, sizeof(*out), 1, f) == 1 && out->magic == SAVE_MAGIC;
    fclose(f);
    return ok;
}

static int write_save(int slot) {
    SaveData d;
    memset(&d, 0, sizeof(d));
    d.magic = SAVE_MAGIC;
    d.xp = xp; d.points_earned = points_earned; d.points_free = points_free;
    d.lv_hp = lv_hp; d.lv_stam = lv_stam; d.lv_str = lv_str;
    d.inv_n = inv_n;
    for (int i = 0; i < INV_MAX; i++) d.inv[i] = inv[i];
    d.equipped_slot = equipped_slot;
    for (int i = 0; i < NUM_PICKUPS; i++) d.pickup_taken[i] = pickups[i].taken;
    d.npc_done = npc_done; d.npc_line = npc_line;
    for (int i = 0; i < ENEMY_TYPE_COUNT; i++) d.bestiary_seen[i] = bestiary_seen[i];
    d.play_time = play_time;

    mkdir(SAVE_DIR, 0777);
    char path[128];
    save_path(slot, path, sizeof(path));
    FILE *f = fopen(path, "wb");
    if (!f) return 0;
    int ok = fwrite(&d, sizeof(d), 1, f) == 1;
    fclose(f);
    if (ok) { slot_info[slot] = d; slot_ok[slot] = 1; }
    return ok;
}

static void delete_save(int slot) {
    char path[128];
    save_path(slot, path, sizeof(path));
    remove(path);
    slot_ok[slot] = 0;
}

static void refresh_slots(void) {
    for (int i = 0; i < NUM_SLOTS; i++) slot_ok[i] = read_save(i, &slot_info[i]);
}

static void new_game_state(void) {
    xp = points_earned = points_free = 0;
    lv_hp = lv_stam = lv_str = 0;
    play_time = 0.0f;
    inv_n = 0; inv_sel = 0; equipped_slot = -1;
    for (int i = 0; i < NUM_PICKUPS; i++) pickups[i].taken = 0;
    npc_done = 0; npc_line = 0; dlg_chars = 0.0f;
    for (int i = 0; i < ENEMY_TYPE_COUNT; i++) bestiary_seen[i] = 0;
    dummy_hits = 0;
    player_dead = 0; hurt_flash = 0.0f;
    recompute_stats();
    do_rest();
    door_open_t = 0.0f;
    menu = MENU_NONE;
}

static void apply_save(const SaveData *d) {
    new_game_state();
    xp = d->xp; points_earned = d->points_earned; points_free = d->points_free;
    lv_hp = d->lv_hp; lv_stam = d->lv_stam; lv_str = d->lv_str;
    inv_n = d->inv_n < 0 ? 0 : (d->inv_n > INV_MAX ? INV_MAX : d->inv_n);
    for (int i = 0; i < inv_n; i++) inv[i] = (d->inv[i] >= 0 && d->inv[i] < ITEM_COUNT) ? d->inv[i] : 0;
    equipped_slot = (d->equipped_slot >= 0 && d->equipped_slot < inv_n) ? d->equipped_slot : -1;
    for (int i = 0; i < NUM_PICKUPS; i++) pickups[i].taken = d->pickup_taken[i];
    npc_done = d->npc_done ? 1 : 0;
    npc_line = (d->npc_line >= 0 && d->npc_line < NPC_LINES) ? d->npc_line : 0;
    for (int i = 0; i < ENEMY_TYPE_COUNT; i++) bestiary_seen[i] = d->bestiary_seen[i];
    play_time = d->play_time;
    recompute_stats();
    do_rest();   // full health, enemies back, door shut
    door_open_t = 0.0f;
}

// Apply a weapon hit to an enemy. Returns the damage dealt.
static float hit_enemy(Enemy *e, const ItemDef *wd, float px, float pz) {
    const EnemyDef *d = &enemy_defs[e->type];
    float dmg = weapon_damage(wd) * d->resist[wd->dmg_type];
    e->hp -= dmg;
    bestiary_seen[e->type] = 1;
    float dx = e->x - px, dz = e->z - pz, l = sqrtf(dx * dx + dz * dz);
    if (l > 1e-4f) { e->kb_x = dx / l; e->kb_z = dz / l; }
    e->state_t = 0.0f;
    if (e->hp <= 0.0f) { e->hp = 0.0f; e->state = E_DEAD; }
    else               { e->state = E_STAGGER; }   // a hit interrupts whatever it was doing
    return dmg;
}

static void update_enemy(Enemy *e, float dt, float px, float pz) {
    const EnemyDef *d = &enemy_defs[e->type];
    float dx = px - e->x, dz = pz - e->z;
    float dist = sqrtf(dx * dx + dz * dz);
    int same_side = player_in_room(e->x, e->z) == player_in_room(px, pz);
    e->state_t += dt;

    switch (e->state) {
    case E_IDLE:
        // Wakes up when you're close and it can see you (same side of the wall, or the door is open).
        if (!player_dead && dist < RAT_AGGRO_RANGE && (same_side || door_open_t > 0.5f)) {
            e->state = E_CHASE;
            e->state_t = 0.0f;
            e->hop = 0.0f;
            bestiary_seen[e->type] = 1;
        }
        break;

    case E_CHASE: {
        // If you're outside the room it heads for the doorway first.
        float tx = px, tz = pz;
        if (!same_side) { tx = ROOM_X0 - 0.6f; tz = 0.0f; }
        float wx = tx - e->x, wz = tz - e->z, wd = sqrtf(wx * wx + wz * wz);
        if (wd > 1e-4f) e->yaw = atan2f(wx, wz);
        e->hop += dt / RAT_HOP_TIME;
        float f = e->hop - floorf(e->hop);
        if (f < 0.65f && wd > 0.6f) {   // moves only while airborne: hop, hop, hop
            float step = RAT_HOP_SPEED * dt;
            e->x += wx / wd * step;
            e->z += wz / wd * step;
        }
        if (same_side && dist < RAT_ATTACK_RANGE) {
            e->state = E_WINDUP;
            e->state_t = 0.0f;
        } else if (dist > 16.0f || player_dead) {
            e->state = E_IDLE;
            e->state_t = 0.0f;
        }
        break;
    }

    case E_WINDUP:   // crouches and shakes, tracks you, then commits to a direction
        if (e->state_t < RAT_WINDUP_TIME * 0.6f && dist > 1e-4f) e->yaw = atan2f(dx, dz);
        if (e->state_t >= RAT_WINDUP_TIME) {
            e->lunge_x = sinf(e->yaw);
            e->lunge_z = cosf(e->yaw);
            e->lunge_hit = 0;
            e->state = E_LUNGE;
            e->state_t = 0.0f;
        }
        break;

    case E_LUNGE:    // straight-line dash: side-step it with a dodge
        e->x += e->lunge_x * RAT_LUNGE_SPEED * dt;
        e->z += e->lunge_z * RAT_LUNGE_SPEED * dt;
        if (!e->lunge_hit && dist < RAT_HIT_RADIUS) {
            e->lunge_hit = 1;
            damage_player(RAT_DAMAGE);
        }
        if (e->state_t >= RAT_LUNGE_TIME) { e->state = E_RECOVER; e->state_t = 0.0f; }
        break;

    case E_RECOVER:  // open for a counter-attack
        if (e->state_t >= RAT_RECOVER_TIME) { e->state = E_CHASE; e->state_t = 0.0f; e->hop = 0.0f; }
        break;

    case E_STAGGER: {
        float k = 3.5f * (1.0f - e->state_t / RAT_STAGGER_TIME);
        if (k < 0.0f) k = 0.0f;
        e->x += e->kb_x * k * dt;
        e->z += e->kb_z * k * dt;
        if (e->state_t >= RAT_STAGGER_TIME) { e->state = E_CHASE; e->state_t = 0.0f; e->hop = 0.0f; }
        break;
    }

    case E_DEAD:
        break;
    }

    if (e->state != E_DEAD) {
        float lim = WORLD_HALF - 0.5f;
        if (e->x >  lim) e->x =  lim;
        if (e->x < -lim) e->x = -lim;
        if (e->z >  lim) e->z =  lim;
        if (e->z < -lim) e->z = -lim;
        resolve_collisions(&e->x, &e->z, d->radius);
    }
}

// ----------------------------------------------------------- HUD / font ----
// Tiny built-in 5x7 bitmap font (uppercase, digits, a few symbols).

#define FONT_CHARS " ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-.:>[]/!?,'"

static const unsigned char font[][7] = {
    {0, 0, 0, 0, 0, 0, 0},                                                           // space
    {0b01110, 0b10001, 0b10001, 0b11111, 0b10001, 0b10001, 0b10001},                 // A
    {0b11110, 0b10001, 0b10001, 0b11110, 0b10001, 0b10001, 0b11110},                 // B
    {0b01110, 0b10001, 0b10000, 0b10000, 0b10000, 0b10001, 0b01110},                 // C
    {0b11110, 0b10001, 0b10001, 0b10001, 0b10001, 0b10001, 0b11110},                 // D
    {0b11111, 0b10000, 0b10000, 0b11110, 0b10000, 0b10000, 0b11111},                 // E
    {0b11111, 0b10000, 0b10000, 0b11110, 0b10000, 0b10000, 0b10000},                 // F
    {0b01110, 0b10001, 0b10000, 0b10111, 0b10001, 0b10001, 0b01111},                 // G
    {0b10001, 0b10001, 0b10001, 0b11111, 0b10001, 0b10001, 0b10001},                 // H
    {0b01110, 0b00100, 0b00100, 0b00100, 0b00100, 0b00100, 0b01110},                 // I
    {0b00111, 0b00010, 0b00010, 0b00010, 0b00010, 0b10010, 0b01100},                 // J
    {0b10001, 0b10010, 0b10100, 0b11000, 0b10100, 0b10010, 0b10001},                 // K
    {0b10000, 0b10000, 0b10000, 0b10000, 0b10000, 0b10000, 0b11111},                 // L
    {0b10001, 0b11011, 0b10101, 0b10101, 0b10001, 0b10001, 0b10001},                 // M
    {0b10001, 0b11001, 0b10101, 0b10011, 0b10001, 0b10001, 0b10001},                 // N
    {0b01110, 0b10001, 0b10001, 0b10001, 0b10001, 0b10001, 0b01110},                 // O
    {0b11110, 0b10001, 0b10001, 0b11110, 0b10000, 0b10000, 0b10000},                 // P
    {0b01110, 0b10001, 0b10001, 0b10001, 0b10101, 0b10010, 0b01101},                 // Q
    {0b11110, 0b10001, 0b10001, 0b11110, 0b10100, 0b10010, 0b10001},                 // R
    {0b01111, 0b10000, 0b10000, 0b01110, 0b00001, 0b00001, 0b11110},                 // S
    {0b11111, 0b00100, 0b00100, 0b00100, 0b00100, 0b00100, 0b00100},                 // T
    {0b10001, 0b10001, 0b10001, 0b10001, 0b10001, 0b10001, 0b01110},                 // U
    {0b10001, 0b10001, 0b10001, 0b10001, 0b10001, 0b01010, 0b00100},                 // V
    {0b10001, 0b10001, 0b10001, 0b10101, 0b10101, 0b11011, 0b10001},                 // W
    {0b10001, 0b10001, 0b01010, 0b00100, 0b01010, 0b10001, 0b10001},                 // X
    {0b10001, 0b10001, 0b01010, 0b00100, 0b00100, 0b00100, 0b00100},                 // Y
    {0b11111, 0b00001, 0b00010, 0b00100, 0b01000, 0b10000, 0b11111},                 // Z
    {0b01110, 0b10001, 0b10011, 0b10101, 0b11001, 0b10001, 0b01110},                 // 0
    {0b00100, 0b01100, 0b00100, 0b00100, 0b00100, 0b00100, 0b01110},                 // 1
    {0b01110, 0b10001, 0b00001, 0b00010, 0b00100, 0b01000, 0b11111},                 // 2
    {0b11110, 0b00001, 0b00001, 0b01110, 0b00001, 0b00001, 0b11110},                 // 3
    {0b00010, 0b00110, 0b01010, 0b10010, 0b11111, 0b00010, 0b00010},                 // 4
    {0b11111, 0b10000, 0b11110, 0b00001, 0b00001, 0b10001, 0b01110},                 // 5
    {0b00110, 0b01000, 0b10000, 0b11110, 0b10001, 0b10001, 0b01110},                 // 6
    {0b11111, 0b00001, 0b00010, 0b00100, 0b01000, 0b01000, 0b01000},                 // 7
    {0b01110, 0b10001, 0b10001, 0b01110, 0b10001, 0b10001, 0b01110},                 // 8
    {0b01110, 0b10001, 0b10001, 0b01111, 0b00001, 0b00010, 0b01100},                 // 9
    {0, 0, 0, 0b11111, 0, 0, 0},                                                     // -
    {0, 0, 0, 0, 0, 0b01100, 0b01100},                                               // .
    {0, 0b01100, 0b01100, 0, 0b01100, 0b01100, 0},                                   // :
    {0b01000, 0b00100, 0b00010, 0b00001, 0b00010, 0b00100, 0b01000},                 // >
    {0b01110, 0b01000, 0b01000, 0b01000, 0b01000, 0b01000, 0b01110},                 // [
    {0b01110, 0b00010, 0b00010, 0b00010, 0b00010, 0b00010, 0b01110},                 // ]
    {0b00001, 0b00010, 0b00010, 0b00100, 0b01000, 0b01000, 0b10000},                 // /
    {0b00100, 0b00100, 0b00100, 0b00100, 0b00100, 0, 0b00100},                       // !
    {0b01110, 0b10001, 0b00001, 0b00010, 0b00100, 0, 0b00100},                       // ?
    {0, 0, 0, 0, 0b01100, 0b00100, 0b01000},                                         // ,
    {0b00100, 0b00100, 0b01000, 0, 0, 0, 0},                                         // '
};

_Static_assert(sizeof(font) / sizeof(font[0]) == sizeof(FONT_CHARS) - 1, "font table size");

#define HUD_MAX 40000
static float hud_v[HUD_MAX * 2];
static float hud_c[HUD_MAX * 4];
static int   hud_n = 0;

static void hud_rect(float x, float y, float w, float h, float r, float g, float b, float a) {
    if (hud_n + 6 > HUD_MAX) return;
    float xs[6] = {x, x + w, x + w, x, x + w, x};
    float ys[6] = {y, y, y + h, y, y + h, y + h};
    for (int i = 0; i < 6; i++) {
        hud_v[hud_n * 2 + 0] = xs[i];
        hud_v[hud_n * 2 + 1] = ys[i];
        hud_c[hud_n * 4 + 0] = r;
        hud_c[hud_n * 4 + 1] = g;
        hud_c[hud_n * 4 + 2] = b;
        hud_c[hud_n * 4 + 3] = a;
        hud_n++;
    }
}

static float hud_text_width(const char *s, float scale) { return (float)strlen(s) * 6.0f * scale; }

static void hud_text_raw(float x, float y, float scale, const char *s,
                         float r, float g, float b, float a) {
    for (; *s; s++, x += 6.0f * scale) {
        const char *p = strchr(FONT_CHARS, toupper((unsigned char)*s));
        if (!p || !*p) continue;
        const unsigned char *rows = font[p - FONT_CHARS];
        for (int row = 0; row < 7; row++) {
            int col = 0;
            while (col < 5) {
                if (rows[row] & (1 << (4 - col))) {
                    int start = col;
                    while (col < 5 && (rows[row] & (1 << (4 - col)))) col++;
                    hud_rect(x + start * scale, y + row * scale, (col - start) * scale, scale, r, g, b, a);
                } else {
                    col++;
                }
            }
        }
    }
}

static void hud_text(float x, float y, float scale, const char *s, float r, float g, float b) {
    hud_text_raw(x + scale, y + scale, scale, s, 0, 0, 0, 0.8f);   // drop shadow
    hud_text_raw(x, y, scale, s, r, g, b, 1.0f);
}

static void hud_text_centered(float y, float scale, const char *s, float r, float g, float b) {
    hud_text((960.0f - hud_text_width(s, scale)) / 2.0f, y, scale, s, r, g, b);
}

static void hud_bar(float x, float y, float w, float h, float frac,
                    float r, float g, float b) {
    if (frac < 0.0f) frac = 0.0f;
    if (frac > 1.0f) frac = 1.0f;
    hud_rect(x - 3, y - 3, w + 6, h + 6, 0.02f, 0.02f, 0.03f, 0.85f);   // frame
    hud_rect(x, y, w, h, 0.14f, 0.12f, 0.12f, 0.9f);                    // empty part
    hud_rect(x, y, w * frac, h, r, g, b, 1.0f);                         // fill
    hud_rect(x, y, w * frac, h * 0.35f, fminf(r + 0.2f, 1.0f), fminf(g + 0.2f, 1.0f),
             fminf(b + 0.2f, 1.0f), 0.55f);                              // highlight
}

static void hud_bars(void) {
    float hw = HEALTH_BAR_W * (player_max_hp / 100.0f);
    float sw = STAMINA_BAR_W * (player_max_stam / 100.0f);
    hud_bar(BAR_X, BAR_Y, hw, HEALTH_BAR_H, player_hp / player_max_hp, HEALTH_COLOR);
    hud_bar(BAR_X, BAR_Y + HEALTH_BAR_H + BAR_GAP, sw, STAMINA_BAR_H,
            player_stam / player_max_stam, STAMINA_COLOR);
}

#define PREVIEW_X  370.0f
#define PREVIEW_Y  110.0f
#define PREVIEW_W  250.0f
#define PREVIEW_H  230.0f

// Health bar + name floating above each living enemy's head.
static void hud_enemy_bars(void) {
    for (int i = 0; i < NUM_ENEMIES; i++) {
        const Enemy *e = &enemies[i];
        const EnemyDef *d = &enemy_defs[e->type];
        if (e->state == E_DEAD) continue;
        // Hidden while it is behind the closed door.
        if (player_in_room(e->x, e->z) && !player_in_room(g_cam_x, g_cam_z) && door_open_t < 0.3f) continue;
        float dx = e->x - g_cam_x, dz = e->z - g_cam_z;
        float dist = sqrtf(dx * dx + dz * dz);
        if (dist > 18.0f) continue;
        float sx, sy;
        float head = d->bar_height + (e->state == E_LUNGE ? 0.2f : 0.0f);
        if (!project_point(e->x, head, e->z, &sx, &sy)) continue;
        float w = fminf(96.0f, fmaxf(44.0f, 230.0f / (dist + 0.5f)));
        hud_bar(sx - w / 2, sy, w, 7.0f, e->hp / d->max_hp, 0.85f, 0.18f, 0.14f);
        if (dist < 10.0f)
            hud_text(sx - hud_text_width(d->name, 2) / 2, sy - 20.0f, 2, d->name, 0.95f, 0.9f, 0.8f);
        if (e->state == E_WINDUP)   // attack warning
            hud_text(sx - 12.0f, sy - 62.0f, 4, "!", 1.0f, 0.25f, 0.15f);
    }
}

static void hud_panel(float x, float y, float w, float h) {
    hud_rect(0, 0, 960, 544, 0, 0, 0, 0.45f);
    hud_rect(x, y, w, h, 0.05f, 0.05f, 0.08f, 0.88f);
    hud_rect(x, y, w, 4, 0.7f, 0.6f, 0.3f, 1.0f);
    hud_rect(x, y + h - 4, w, 4, 0.7f, 0.6f, 0.3f, 1.0f);
}

static void hud_menu_list(float x, float y, float row, float w, const char *const *labels, int n, int sel) {
    for (int i = 0; i < n; i++) {
        float yy = y + i * row;
        if (i == sel) hud_rect(x - 18, yy - 6, w, 32, 0.25f, 0.22f, 0.12f, 0.9f);
        hud_text(x - 6, yy, 3, i == sel ? ">" : " ", 1.0f, 0.9f, 0.4f);
        hud_text(x + 28, yy, 3, labels[i], 0.9f, 0.9f, 0.9f);
    }
}

static void hud_inventory(void) {
    hud_panel(230, 70, 500, 380);
    hud_text(260, 92, 4, "INVENTORY", 0.95f, 0.85f, 0.5f);
    if (inv_n == 0) hud_text(260, 170, 3, "EMPTY", 0.6f, 0.6f, 0.6f);
    for (int i = 0; i < inv_n; i++) {
        float y = 160 + i * 34;
        if (i == inv_sel) hud_rect(248, y - 6, 464, 32, 0.25f, 0.22f, 0.12f, 0.9f);
        hud_text(262, y, 3, i == inv_sel ? ">" : " ", 1.0f, 0.9f, 0.4f);
        hud_text(300, y, 3, item_defs[inv[i]].name, 0.9f, 0.9f, 0.9f);
        if (i == equipped_slot) hud_text(540, y, 3, "EQUIPPED", 0.5f, 1.0f, 0.5f);
    }
    if (inv_n > 0) {
        const ItemDef *d = &item_defs[inv[inv_sel]];
        char sb[64];
        hud_text(260, 364, 2, d->desc, 0.7f, 0.7f, 0.75f);
        snprintf(sb, sizeof(sb), "TYPE: %s   DAMAGE: %d", dmg_type_names[d->dmg_type], (int)weapon_damage(d));
        hud_text(260, 388, 2, sb, 0.85f, 0.8f, 0.55f);
    }
    hud_text(260, 424, 2, "X: EQUIP / UNEQUIP    O: BACK", 0.8f, 0.8f, 0.8f);
}

static void hud_pause(void) {
    static const char *const labels[6] = { "RESUME", "INVENTORY", "BESTIARY", "STATS", "MAIN MENU", "QUIT GAME" };
    hud_panel(330, 70, 300, 400);
    hud_text(360, 92, 4, "PAUSED", 0.95f, 0.85f, 0.5f);
    hud_menu_list(372, 160, 44, 250, labels, 6, pause_sel);
    hud_text(360, 436, 2, "START: RESUME", 0.8f, 0.8f, 0.8f);
}

static void hud_beacon(void) {
    static const char *const labels[4] = { "SAVE", "REST", "LEVEL UP", "TELEPORT" };
    hud_panel(330, 100, 300, 320);
    hud_text(360, 122, 4, "BEACON", 0.6f, 0.9f, 1.0f);
    hud_menu_list(372, 195, 44, 250, labels, 4, beacon_sel);
    hud_text(360, 384, 2, "O: CLOSE", 0.8f, 0.8f, 0.8f);
}

static void hud_bestiary(void) {
    hud_panel(60, 40, 840, 464);
    hud_text(90, 62, 4, "BESTIARY", 0.95f, 0.85f, 0.5f);
    for (int i = 0; i < ENEMY_TYPE_COUNT; i++) {
        float y = 130 + i * 34;
        if (i == bestiary_sel) hud_rect(78, y - 6, 270, 32, 0.25f, 0.22f, 0.12f, 0.9f);
        hud_text(90, y, 3, i == bestiary_sel ? ">" : " ", 1.0f, 0.9f, 0.4f);
        hud_text(126, y, 3, bestiary_seen[i] ? enemy_defs[i].name : "UNKNOWN", 0.9f, 0.9f, 0.9f);
    }

    // Frame for the spinning 3D model (the model itself is drawn after the HUD).
    hud_rect(PREVIEW_X - 3, PREVIEW_Y - 3, PREVIEW_W + 6, PREVIEW_H + 6, 0.7f, 0.6f, 0.3f, 1.0f);
    hud_rect(PREVIEW_X, PREVIEW_Y, PREVIEW_W, PREVIEW_H, 0.10f, 0.10f, 0.14f, 1.0f);

    if (!bestiary_seen[bestiary_sel]) {
        hud_text(PREVIEW_X + 62, PREVIEW_Y + 100, 3, "UNKNOWN", 0.6f, 0.6f, 0.65f);
        hud_text(PREVIEW_X, PREVIEW_Y + PREVIEW_H + 20, 2, "ENCOUNTER IT TO RECORD IT.", 0.7f, 0.7f, 0.75f);
    } else {
        const EnemyDef *d = &enemy_defs[bestiary_sel];
        char b[64];
        hud_text(PREVIEW_X, PREVIEW_Y + PREVIEW_H + 20, 2, d->desc[0], 0.75f, 0.75f, 0.8f);
        hud_text(PREVIEW_X, PREVIEW_Y + PREVIEW_H + 44, 2, d->desc[1], 0.75f, 0.75f, 0.8f);

        snprintf(b, sizeof(b), "HEALTH: %d", (int)d->max_hp);
        hud_text(640, 120, 3, b, 0.9f, 0.85f, 0.55f);

        char wk[64];
        int any = 0;
        snprintf(wk, sizeof(wk), "WEAK TO:");
        for (int k = 0; k < DMG_TYPE_COUNT; k++) {
            if (d->resist[k] > 1.05f) {
                size_t l = strlen(wk);
                snprintf(wk + l, sizeof(wk) - l, " %s", dmg_type_short[k]);
                any = 1;
            }
        }
        if (!any) {
            size_t l = strlen(wk);
            snprintf(wk + l, sizeof(wk) - l, " NONE");
        }
        snprintf(b, sizeof(b), "XP REWARD: %d", d->xp);
        hud_text(640, 144, 2, b, 0.7f, 0.9f, 0.7f);
        hud_text(640, 168, 2, wk, 0.9f, 0.9f, 0.9f);

        hud_text(640, 204, 2, "DAMAGE TAKEN:", 0.7f, 0.7f, 0.75f);
        for (int k = 0; k < DMG_TYPE_COUNT; k++) {
            float m = d->resist[k];
            snprintf(b, sizeof(b), "%s: %s X%.1f", dmg_type_short[k],
                     m > 1.05f ? "WEAK" : (m < 0.95f ? "RESISTANT" : "NEUTRAL"), m);
            hud_text(640, 232 + k * 28, 2, b, 0.85f, 0.85f, 0.85f);
        }
    }
    hud_text(90, 470, 2, "O: BACK", 0.8f, 0.8f, 0.8f);
}

// Draws s word-wrapped at maxc characters per line, revealing only the first `shown` characters.
static void hud_text_wrapped(float x, float y, float scale, const char *s, int maxc, int shown,
                             float r, float g, float b) {
    int len = (int)strlen(s), pos = 0, line = 0;
    while (pos < len) {
        int end = pos + maxc;
        if (end >= len) end = len;
        else { int k = end; while (k > pos && s[k] != ' ') k--; if (k > pos) end = k; }
        int n = end - pos, vis = shown - pos;
        if (vis <= 0) break;
        if (vis < n) n = vis;
        char buf[96];
        if (n > 95) n = 95;
        memcpy(buf, s + pos, n);
        buf[n] = 0;
        hud_text(x, y + line * scale * 10.0f, scale, buf, r, g, b);
        pos = end;
        while (pos < len && s[pos] == ' ') pos++;
        line++;
    }
}

static void hud_dialogue(void) {
    const float x = 60, y = 366, w = 840, h = 136;
    hud_rect(x, y, w, h, 0.03f, 0.03f, 0.05f, 0.88f);
    hud_rect(x, y, w, 3, 0.7f, 0.6f, 0.3f, 1.0f);
    hud_rect(x, y + h - 3, w, 3, 0.7f, 0.6f, 0.3f, 1.0f);
    hud_text(x + 30, y + 16, 2, "WANDERER", 0.85f, 0.75f, 0.45f);
    const char *txt = npc_text();
    int shown = (int)dlg_chars;
    hud_text_wrapped(x + 30, y + 48, 3, txt, 42, shown, 0.92f, 0.9f, 0.85f);
    if (shown >= (int)strlen(txt) && ((int)(g_time * 2.0f) & 1))
        hud_text(x + w - 50, y + h - 34, 2, npc_done || npc_line + 1 >= NPC_LINES ? "X" : ">", 0.9f, 0.8f, 0.4f);
}

static void hud_stats(void) {
    static const char *const names[3] = { "HEALTH", "STAMINA", "STRENGTH" };
    hud_panel(110, 50, 740, 380);
    hud_text(140, 72, 4, "LEVEL UP", 0.95f, 0.85f, 0.5f);

    char b[96];
    snprintf(b, sizeof(b), "LEVEL %d     POINTS TO SPEND: %d", player_level(), points_free);
    hud_text(140, 120, 3, b, 0.9f, 0.9f, 0.9f);
    snprintf(b, sizeof(b), "XP %d/%d TO NEXT POINT", xp, xp_cost());
    hud_text(140, 156, 2, b, 0.7f, 0.9f, 0.7f);
    hud_bar(140, 180, 400, 8, (float)xp / (float)xp_cost(), 0.3f, 0.8f, 0.4f);

    int lv[3] = { lv_hp, lv_stam, lv_str };
    for (int i = 0; i < 3; i++) {
        float y = 220 + i * 46;
        char eff[48];
        if (i == 0)      snprintf(eff, sizeof(eff), "MAX HP %d > %d", (int)player_max_hp, (int)(player_max_hp + HP_PER_LEVEL));
        else if (i == 1) snprintf(eff, sizeof(eff), "MAX STAM %d > %d", (int)player_max_stam, (int)(player_max_stam + STAM_PER_LEVEL));
        else             snprintf(eff, sizeof(eff), "DAMAGE X%.1f > X%.1f", str_mult(), str_mult() + STR_BONUS);
        if (i == stats_sel) hud_rect(128, y - 8, 704, 40, 0.25f, 0.22f, 0.12f, 0.9f);
        hud_text(140, y, 3, i == stats_sel ? ">" : " ", 1.0f, 0.9f, 0.4f);
        snprintf(b, sizeof(b), "%-9s %2d   %s", names[i], lv[i] + 1, eff);
        float c = points_free > 0 ? 0.92f : 0.55f;
        hud_text(176, y, 3, b, c, c, c);
    }
    hud_text(140, 390, 2, points_free > 0 ? "X: SPEND A POINT    O: BACK" : "NO POINTS - KILL THINGS TO GAIN XP    O: BACK", 0.8f, 0.8f, 0.8f);
}

static void hud_title(const char *toast) {
    hud_rect(0, 0, 960, 544, 0.04f, 0.04f, 0.07f, 1.0f);
    hud_text_centered(50, 9, "PLAIN WALK", 0.9f, 0.8f, 0.5f);
    hud_text_centered(150, 2, "SELECT A SAVE FILE", 0.7f, 0.7f, 0.75f);
    for (int i = 0; i < NUM_SLOTS + 1; i++) {
        float y = 200 + i * 60;
        if (i == title_sel) hud_rect(130, y - 8, 700, 48, 0.25f, 0.22f, 0.12f, 0.9f);
        hud_text(150, y, 3, i == title_sel ? ">" : " ", 1.0f, 0.9f, 0.4f);
        char b[96];
        if (i == NUM_SLOTS) {
            snprintf(b, sizeof(b), "QUIT GAME");
        } else if (slot_ok[i]) {
            const SaveData *d = &slot_info[i];
            int mins = (int)(d->play_time / 60.0f);
            snprintf(b, sizeof(b), "SLOT %d  LEVEL %d  PLAYED %d:%02d", i + 1,
                     1 + d->lv_hp + d->lv_stam + d->lv_str, mins / 60, mins % 60);
        } else {
            snprintf(b, sizeof(b), "SLOT %d  EMPTY - NEW GAME", i + 1);
        }
        float c = (i < NUM_SLOTS && !slot_ok[i]) ? 0.6f : 0.92f;
        hud_text(190, y, 3, b, c, c, c);
    }
    hud_text(130, 500, 2, "X: SELECT    SQUARE: DELETE SLOT", 0.7f, 0.7f, 0.75f);
    if (toast) hud_text_centered(455, 3, toast, 0.7f, 1.0f, 0.7f);
    if (title_confirm) {
        hud_rect(0, 0, 960, 544, 0, 0, 0, 0.6f);
        hud_rect(210, 190, 540, 150, 0.05f, 0.05f, 0.08f, 1.0f);
        hud_rect(210, 190, 540, 4, 0.7f, 0.6f, 0.3f, 1.0f);
        hud_rect(210, 336, 540, 4, 0.7f, 0.6f, 0.3f, 1.0f);
        char b[48];
        snprintf(b, sizeof(b), "DELETE SLOT %d?", title_sel + 1);
        hud_text_centered(225, 4, b, 0.95f, 0.85f, 0.5f);
        hud_text_centered(290, 3, "X: YES    O: NO", 0.9f, 0.9f, 0.9f);
    }
}

static void build_hud(const char *prompt, const char *toast) {
    hud_n = 0;
    if (screen == SCREEN_TITLE) { hud_title(toast); return; }
    hud_bars();

    if (menu == MENU_NONE && !player_dead) {
        hud_enemy_bars();
        {   // xp readout under the bars
            char xb[64];
            float yy = BAR_Y + HEALTH_BAR_H + BAR_GAP + STAMINA_BAR_H + 10.0f;
            snprintf(xb, sizeof(xb), "LV %d   XP %d/%d", player_level(), xp, xp_cost());
            hud_text(BAR_X, yy, 2, xb, 0.8f, 0.9f, 0.8f);
            if (points_free > 0 && ((int)(g_time * 2.0f) & 1)) {
                snprintf(xb, sizeof(xb), "POINTS TO SPEND: %d", points_free);
                hud_text(BAR_X, yy + 22.0f, 2, xb, 1.0f, 0.9f, 0.4f);
            }
        }
        hud_text(12, 518, 2, "TRIANGLE: INVENTORY   START: MENU   O: DODGE   R: ATTACK", 0.9f, 0.9f, 0.9f);
        if (prompt) hud_text_centered(470, 3, prompt, 1.0f, 0.95f, 0.6f);
    }

    if (hurt_flash > 0.0f) hud_rect(0, 0, 960, 544, 0.7f, 0.0f, 0.0f, fminf(hurt_flash * 0.9f, 0.35f));

    if (menu == MENU_INVENTORY) hud_inventory();
    else if (menu == MENU_PAUSE) hud_pause();
    else if (menu == MENU_BESTIARY) hud_bestiary();
    else if (menu == MENU_BEACON) hud_beacon();
    else if (menu == MENU_DIALOGUE) hud_dialogue();
    else if (menu == MENU_STATS) hud_stats();

    if (toast && menu != MENU_DIALOGUE) hud_text_centered(menu == MENU_BEACON ? 450 : 425, 3, toast, 0.7f, 1.0f, 0.7f);

    if (player_dead) {
        float a = fminf(death_t * 0.8f, 0.8f);
        hud_rect(0, 0, 960, 544, 0, 0, 0, a);
        hud_text_centered(230, 8, "YOU DIED", 0.8f, 0.1f, 0.1f);
    }
}

// --------------------------------------------------------------- input ----

// Transform a point from weapon-local space to camera space, exactly like the GL
// calls glTranslatef(tx,ty,tz); glRotatef(rz,0,0,1); glRotatef(rx,1,0,0).
static vec3 vm_point(vec3 p, float tx, float ty, float tz, float rz_deg, float rx_deg) {
    float rz = rz_deg * PI_F / 180.0f, rx = rx_deg * PI_F / 180.0f;
    float y1 = p.y * cosf(rx) - p.z * sinf(rx);
    float z1 = p.y * sinf(rx) + p.z * cosf(rx);
    float x2 = p.x * cosf(rz) - y1 * sinf(rz);
    float y2 = p.x * sinf(rz) + y1 * cosf(rz);
    return V(x2 + tx, y2 + ty, z1 + tz);
}

// Rebuild the forearm each frame in camera space: anchored at the shoulder
// (off-screen, bottom right) and stretching out to the wrist.
static void build_arm(vec3 shoulder, vec3 wrist) {
    rgb skin = C(0.80f, 0.58f, 0.44f), brace = C(0.38f, 0.30f, 0.24f);
    cur = &arm_mesh;
    arm_mesh.n = 0;
    add_prism(shoulder, wrist, 0.065f, 6, skin);
    vec3 b0 = V(wrist.x + (shoulder.x - wrist.x) * 0.25f, wrist.y + (shoulder.y - wrist.y) * 0.25f,
                wrist.z + (shoulder.z - wrist.z) * 0.25f);
    vec3 b1 = V(wrist.x + (shoulder.x - wrist.x) * 0.55f, wrist.y + (shoulder.y - wrist.y) * 0.55f,
                wrist.z + (shoulder.z - wrist.z) * 0.55f);
    add_prism(b0, b1, 0.085f, 6, brace);
}

static float axis(unsigned char raw) {
    float f = ((int)raw - 128) / 128.0f;
    float a = fabsf(f);
    if (a < DEADZONE) return 0.0f;
    a = (a - DEADZONE) / (1.0f - DEADZONE);
    return f < 0 ? -a : a;
}

static void draw_mesh(const Mesh *m) {
    if (m->n == 0) return;
    glVertexPointer(3, GL_FLOAT, 0, m->v);
    glColorPointer(4, GL_FLOAT, 0, m->c);
    glDrawArrays(GL_TRIANGLES, 0, m->n);
}

// ---------------------------------------------------------------- main ----

static void set_perspective(void) {
    const float near_ = 0.1f, far_ = 100.0f;
    float top = near_ * tanf(35.0f * PI_F / 180.0f);   // 70 degree vertical FOV
    float right = top * (960.0f / 544.0f);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glFrustum(-right, right, -top, top, near_, far_);
    glMatrixMode(GL_MODELVIEW);
}

// Rat animation: hop, crouch + shake (wind-up), stretched lunge, recovery, stagger, death.
static void draw_enemy(const Enemy *e, float t) {
    const EnemyDef *d = &enemy_defs[e->type];
    float hop_y = 0.0f, pitch = 0.0f, roll = 0.0f, shake = 0.0f, back = 0.0f, lift = 0.0f;
    float sx = 1.0f, sy = 1.0f, sz = 1.0f, u;

    switch (e->state) {
    case E_IDLE:
        sy = 1.0f + sinf(t * 2.5f) * 0.03f;
        break;
    case E_CHASE: {
        float f = e->hop - floorf(e->hop);
        if (f < 0.65f) {
            float a = sinf(PI_F * f / 0.65f);
            hop_y = a * 0.30f;
            pitch = -a * 22.0f;
        } else {
            sy = 0.85f; sz = 1.08f; pitch = 6.0f;   // landing squash
        }
        break;
    }
    case E_WINDUP:
        u = fminf(e->state_t / RAT_WINDUP_TIME, 1.0f);
        sy = 1.0f - 0.30f * u;
        sz = 1.0f - 0.10f * u;
        back = -0.20f * u;
        pitch = 10.0f * u;
        shake = sinf(t * 70.0f) * 0.035f * u;
        break;
    case E_LUNGE:
        u = fminf(e->state_t / RAT_LUNGE_TIME, 1.0f);
        sz = 1.40f; sy = 0.85f; pitch = -12.0f;
        hop_y = sinf(PI_F * u) * 0.22f;
        break;
    case E_RECOVER:
        sy = 0.88f; pitch = 14.0f;
        break;
    case E_STAGGER:
        roll = sinf(e->state_t * 45.0f) * 12.0f;
        back = -0.1f; pitch = -10.0f;
        break;
    case E_DEAD:
        u = smooth01(e->state_t / 0.25f);
        roll = u * 90.0f;
        lift = 0.17f * d->scale * u;   // lies on its side
        break;
    }

    glPushMatrix();
    glTranslatef(e->x, hop_y + lift, e->z);
    glRotatef(e->yaw * 180.0f / PI_F, 0, 1, 0);
    glTranslatef(shake, 0.0f, back);
    glRotatef(pitch, 1, 0, 0);
    glRotatef(roll, 0, 0, 1);
    glScalef(d->scale * sx, d->scale * sy, d->scale * sz);
    draw_mesh(d->mesh);
    glPopMatrix();
}

int main(void) {
    sceCtrlSetSamplingMode(SCE_CTRL_MODE_ANALOG);

    vglInit(0x800000);
    glViewport(0, 0, 960, 544);

    build_scene();
    build_hand();
    build_sword();
    build_mace();
    build_dummy();
    build_rat();
    build_door();
    build_gem();
    build_npc();
    reset_enemies();

    const float sky[4] = {0.45f, 0.55f, 0.75f, 1.0f};
    glClearColor(sky[0], sky[1], sky[2], sky[3]);
    glFogi(GL_FOG_MODE, GL_LINEAR);
    glFogf(GL_FOG_START, 14.0f);
    glFogf(GL_FOG_END, 52.0f);
    glFogfv(GL_FOG_COLOR, sky);

    float px = 0.0f, pz = 6.0f;   // player position
    float yaw = 0.0f, pitch = 0.0f;
    float t = 0.0f, bob = 0.0f;
    float cam_roll = 0.0f, cam_drop = 0.0f;
    char toast_buf[64];
    float toast_t = 0.0f;
    unsigned int prev_buttons = 0;
    int quit = 0, menu_from_pause = 0;
    uint64_t last = sceKernelGetProcessTimeWide();

    while (!quit) {
        uint64_t now = sceKernelGetProcessTimeWide();
        float dt = (now - last) / 1000000.0f;
        last = now;
        if (dt > 0.1f) dt = 0.1f;
        t += dt;
        g_time = t;
        if (screen == SCREEN_GAME) play_time += dt;
        if (toast_t > 0.0f) toast_t -= dt;
        if (hurt_flash > 0.0f) hurt_flash -= dt;

        SceCtrlData pad;
        memset(&pad, 0, sizeof(pad));
        sceCtrlPeekBufferPositive(0, &pad, 1);
        unsigned int pressed = pad.buttons & ~prev_buttons;
        prev_buttons = pad.buttons;

        float moving = 0.0f;
        char prompt_buf[64];
        const char *prompt = NULL;

        if (screen == SCREEN_TITLE) {
            // ---- main menu: three save slots ----
            if (title_confirm) {
                if (pressed & SCE_CTRL_CROSS) {
                    delete_save(title_sel);
                    title_confirm = 0;
                    snprintf(toast_buf, sizeof(toast_buf), "SLOT %d DELETED", title_sel + 1);
                    toast_t = 2.0f;
                }
                if (pressed & SCE_CTRL_CIRCLE) title_confirm = 0;
            } else {
                if ((pressed & SCE_CTRL_UP) && title_sel > 0) title_sel--;
                if ((pressed & SCE_CTRL_DOWN) && title_sel < NUM_SLOTS) title_sel++;
                if ((pressed & SCE_CTRL_SQUARE) && title_sel < NUM_SLOTS && slot_ok[title_sel]) title_confirm = 1;
                if (pressed & SCE_CTRL_CROSS) {
                    if (title_sel == NUM_SLOTS) {
                        quit = 1;
                    } else {
                        cur_slot = title_sel;
                        yaw = 0.0f; pitch = 0.0f;
                        if (slot_ok[cur_slot]) {          // continue: wake up at the beacon
                            apply_save(&slot_info[cur_slot]);
                            px = BEACON_X; pz = BEACON_Z + 3.0f;
                            snprintf(toast_buf, sizeof(toast_buf), "GAME LOADED");
                        } else {                          // new game
                            new_game_state();
                            px = 0.0f; pz = 6.0f;
                            snprintf(toast_buf, sizeof(toast_buf), "NEW GAME - SLOT %d", cur_slot + 1);
                        }
                        toast_t = 2.5f;
                        screen = SCREEN_GAME;
                    }
                }
            }
        } else if (player_dead) {
            // ---- death screen, then wake up at the start ----
            death_t += dt;
            if (death_t >= RESPAWN_DELAY) {
                player_dead = 0;
                menu = MENU_NONE;
                px = 0.0f; pz = 6.0f; yaw = 0.0f; pitch = 0.0f;
                do_rest();
                snprintf(toast_buf, sizeof(toast_buf), "YOU AWAKEN AT THE START");
                toast_t = 2.5f;
            }
        } else {
            // ---- menu open / close ----
            if (pressed & SCE_CTRL_START) {
                if (menu == MENU_NONE) { menu = MENU_PAUSE; pause_sel = 0; }
                else                   { menu = MENU_NONE; }
                menu_from_pause = 0;
            } else if ((pressed & SCE_CTRL_TRIANGLE) && (menu == MENU_NONE || menu == MENU_INVENTORY)) {
                menu = (menu == MENU_NONE) ? MENU_INVENTORY : MENU_NONE;
                menu_from_pause = 0;
                if (inv_sel >= inv_n) inv_sel = inv_n > 0 ? inv_n - 1 : 0;
            }

            if (menu == MENU_INVENTORY) {
                if ((pressed & SCE_CTRL_UP) && inv_sel > 0) inv_sel--;
                if ((pressed & SCE_CTRL_DOWN) && inv_sel < inv_n - 1) inv_sel++;
                if ((pressed & SCE_CTRL_CROSS) && inv_n > 0) {
                    equipped_slot = (equipped_slot == inv_sel) ? -1 : inv_sel;
                    attack_t = -1.0f;
                }
                if (pressed & SCE_CTRL_CIRCLE) { menu = menu_from_pause ? MENU_PAUSE : MENU_NONE; menu_from_pause = 0; }
            } else if (menu == MENU_PAUSE) {
                if ((pressed & SCE_CTRL_UP) && pause_sel > 0) pause_sel--;
                if ((pressed & SCE_CTRL_DOWN) && pause_sel < 5) pause_sel++;
                if (pressed & SCE_CTRL_CROSS) {
                    switch (pause_sel) {
                    case 0: menu = MENU_NONE; break;
                    case 1: menu = MENU_INVENTORY; menu_from_pause = 1; break;
                    case 2: menu = MENU_BESTIARY; menu_from_pause = 1; break;
                    case 3: menu = MENU_STATS; menu_return = MENU_PAUSE; stats_sel = 0; break;
                    case 4:   // back to the main menu (unsaved progress is lost)
                        menu = MENU_NONE;
                        screen = SCREEN_TITLE;
                        title_sel = cur_slot;
                        title_confirm = 0;
                        refresh_slots();
                        break;
                    default: quit = 1; break;
                    }
                }
                if (pressed & SCE_CTRL_CIRCLE) menu = MENU_NONE;
            } else if (menu == MENU_BESTIARY) {
                if ((pressed & SCE_CTRL_UP) && bestiary_sel > 0) bestiary_sel--;
                if ((pressed & SCE_CTRL_DOWN) && bestiary_sel < ENEMY_TYPE_COUNT - 1) bestiary_sel++;
                if (pressed & SCE_CTRL_CIRCLE) { menu = menu_from_pause ? MENU_PAUSE : MENU_NONE; menu_from_pause = 0; }
            } else if (menu == MENU_STATS) {
                if ((pressed & SCE_CTRL_UP) && stats_sel > 0) stats_sel--;
                if ((pressed & SCE_CTRL_DOWN) && stats_sel < 2) stats_sel++;
                if (pressed & SCE_CTRL_CROSS) {
                    if (spend_point(stats_sel)) snprintf(toast_buf, sizeof(toast_buf), "LEVEL UP! NOW LEVEL %d", player_level());
                    else                        snprintf(toast_buf, sizeof(toast_buf), "NO POINTS TO SPEND");
                    toast_t = 1.5f;
                }
                if (pressed & SCE_CTRL_CIRCLE) menu = menu_return;
            } else if (menu == MENU_DIALOGUE) {
                dlg_chars += DIALOGUE_CPS * dt;
                if (pressed & SCE_CTRL_CROSS) { if (npc_advance()) menu = MENU_NONE; }
                if (pressed & SCE_CTRL_CIRCLE) menu = MENU_NONE;   // walk away; he picks up where he left off
            } else if (menu == MENU_BEACON) {
                if ((pressed & SCE_CTRL_UP) && beacon_sel > 0) beacon_sel--;
                if ((pressed & SCE_CTRL_DOWN) && beacon_sel < 3) beacon_sel++;
                if (pressed & SCE_CTRL_CROSS) {
                    if (beacon_sel == 0) {          // SAVE
                        snprintf(toast_buf, sizeof(toast_buf), write_save(cur_slot) ? "GAME SAVED" : "SAVE FAILED");
                        toast_t = 2.0f;
                    } else if (beacon_sel == 1) {   // REST
                        do_rest();
                        menu = MENU_NONE;
                        snprintf(toast_buf, sizeof(toast_buf), "RESTED. ENEMIES HAVE RETURNED.");
                        toast_t = 2.5f;
                    } else if (beacon_sel == 2) {   // LEVEL UP
                        menu = MENU_STATS;
                        menu_return = MENU_BEACON;
                        stats_sel = 0;
                    } else {                        // TELEPORT (placeholder for later)
                        snprintf(toast_buf, sizeof(toast_buf), "TELEPORT COMES LATER");
                        toast_t = 2.0f;
                    }
                }
                if (pressed & SCE_CTRL_CIRCLE) menu = MENU_NONE;
            } else {
                // ---- exploration ----
                float lx = axis(pad.lx), ly = axis(pad.ly);
                float rx = axis(pad.rx), ry = axis(pad.ry);

                // Look: stick right turns right, stick up looks up.
                yaw   -= rx * LOOK_SPEED * dt;
                pitch -= ry * LOOK_SPEED * dt;
                if (pitch >  1.4f) pitch =  1.4f;
                if (pitch < -1.4f) pitch = -1.4f;

                float fx = -sinf(yaw), fz = -cosf(yaw);   // forward
                float sx =  cosf(yaw), sz = -sinf(yaw);   // right

                // Debug: SELECT hurts you so you can watch the health bar.
                if (pressed & SCE_CTRL_SELECT) damage_player(DEBUG_DAMAGE);

                // Stamina regen.
                if (stam_delay > 0.0f) {
                    stam_delay -= dt;
                } else {
                    player_stam += STAMINA_REGEN * dt;
                    if (player_stam > player_max_stam) player_stam = player_max_stam;
                }

                // Dodge (O): side-step toward the left stick, back-step if neutral.
                if ((pressed & SCE_CTRL_CIRCLE) && dodge_t < 0.0f && attack_t < 0.0f && player_stam > 0.0f) {
                    float mag = sqrtf(lx * lx + ly * ly);
                    float dright = 0.0f, dfwd = -1.0f;
                    if (mag > 0.3f) { dright = lx / mag; dfwd = -ly / mag; }
                    dodge_vx = fx * dfwd + sx * dright;
                    dodge_vz = fz * dfwd + sz * dright;
                    dodge_side = dright;
                    dodge_t = 0.0f;
                    use_stamina(DODGE_COST);
                }

                // Attack (R): swing the equipped weapon (style depends on the weapon).
                if ((pressed & SCE_CTRL_RTRIGGER) && attack_t < 0.0f && dodge_t < 0.0f) {
                    if (equipped_slot < 0) {
                        snprintf(toast_buf, sizeof(toast_buf), "NO WEAPON EQUIPPED");
                        toast_t = 1.5f;
                    } else if (player_stam > 0.0f) {
                        attack_t = 0.0f;
                        attack_hit_mask = 0;
                        use_stamina(item_defs[inv[equipped_slot]].stamina_cost);
                    }
                }

                // Movement: a dodge overrides walking.
                float mx = 0.0f, mz = 0.0f;
                if (dodge_t >= 0.0f) {
                    float u = dodge_t / DODGE_TIME;
                    float speed = (DODGE_DISTANCE / DODGE_TIME) * 2.0f * (1.0f - u);  // eases out
                    mx = dodge_vx * speed * dt;
                    mz = dodge_vz * speed * dt;
                    dodge_t += dt;
                    if (dodge_t >= DODGE_TIME) dodge_t = -1.0f;
                } else {
                    float walk = (attack_t >= 0.0f) ? 0.5f : 1.0f;   // slower while swinging
                    float fwd = -ly, str = lx;
                    mx = (fx * fwd + sx * str) * MOVE_SPEED * walk * dt;
                    mz = (fz * fwd + sz * str) * MOVE_SPEED * walk * dt;
                    moving = sqrtf(fwd * fwd + str * str);
                    if (moving > 1.0f) moving = 1.0f;
                }
                px += mx;
                pz += mz;

                // Stay on the plane, and out of objects and walls.
                float lim = WORLD_HALF - 0.5f;
                if (px >  lim) px =  lim;
                if (px < -lim) px = -lim;
                if (pz >  lim) pz =  lim;
                if (pz < -lim) pz = -lim;
                resolve_collisions(&px, &pz, PLAYER_R);

                // Swing progress + hit checks (training dummy, then enemies).
                if (attack_t >= 0.0f && equipped_slot >= 0) {
                    const ItemDef *wd = &item_defs[inv[equipped_slot]];
                    attack_t += dt;
                    float u = attack_t / wd->swing_time;
                    if (u >= wd->hit_start && u <= wd->hit_end) {
                        float cone = cosf(wd->arc_deg * PI_F / 180.0f);

                        if (!(attack_hit_mask & 1u)) {
                            float dx = DUMMY_X - px, dz = DUMMY_Z - pz;
                            float d = sqrtf(dx * dx + dz * dz);
                            if (d < wd->range && d > 1e-4f && (fx * dx + fz * dz) / d > cone) {
                                attack_hit_mask |= 1u;
                                dummy_hits++;
                                dummy_wobble = 0.0f;
                                dummy_hit_type = wd->dmg_type;
                                dummy_hit_amp = weapon_damage(wd) * 0.45f;
                                snprintf(toast_buf, sizeof(toast_buf), "%s HIT! %d DMG",
                                         dmg_type_short[wd->dmg_type], (int)weapon_damage(wd));
                                toast_t = 1.0f;
                            }
                        }

                        for (int i = 0; i < NUM_ENEMIES; i++) {
                            Enemy *e = &enemies[i];
                            if (e->state == E_DEAD || (attack_hit_mask & (2u << i))) continue;
                            float dx = e->x - px, dz = e->z - pz;
                            float d = sqrtf(dx * dx + dz * dz);
                            if (d < wd->range + enemy_defs[e->type].radius && d > 1e-4f &&
                                (fx * dx + fz * dz) / d > cone) {
                                attack_hit_mask |= (2u << i);
                                float dmg = hit_enemy(e, wd, px, pz);
                                if (e->state == E_DEAD) {
                                    int xpg = enemy_defs[e->type].xp;
                                    int pts = give_xp(xpg);
                                    snprintf(toast_buf, sizeof(toast_buf), pts ? "%s SLAIN  +%d XP  POINT GAINED!" : "%s SLAIN  +%d XP",
                                             enemy_defs[e->type].name, xpg);
                                } else
                                    snprintf(toast_buf, sizeof(toast_buf), "%s HIT! %d DMG",
                                             dmg_type_short[wd->dmg_type], (int)dmg);
                                toast_t = 1.2f;
                            }
                        }
                    }
                    if (u >= 1.0f) attack_t = -1.0f;
                } else if (attack_t >= 0.0f) {
                    attack_t = -1.0f;
                }
                if (dummy_wobble >= 0.0f) {
                    dummy_wobble += dt;
                    if (dummy_wobble > 1.2f) dummy_wobble = -1.0f;
                }

                // Door: swings open/shut; the doorway collider is only active while it's shut.
                {
                    float tgt = door_target ? 1.0f : 0.0f;
                    if (door_open_t < tgt) { door_open_t += DOOR_OPEN_SPEED * dt; if (door_open_t > tgt) door_open_t = tgt; }
                    else if (door_open_t > tgt) { door_open_t -= DOOR_OPEN_SPEED * dt; if (door_open_t < tgt) door_open_t = tgt; }
                    if (door_wall >= 0) walls[door_wall].on = (door_open_t < 0.35f);
                }

                // Enemies.
                for (int i = 0; i < NUM_ENEMIES; i++) update_enemy(&enemies[i], dt, px, pz);

                // Interaction: the nearest of pick-up / door / beacon in range.
                {
                    float best = 1e9f;
                    int kind = 0;
                    Pickup *near_pickup = NULL;
                    for (int i = 0; i < NUM_PICKUPS; i++) {
                        if (pickups[i].taken) continue;
                        float dx = px - pickups[i].x, dz = pz - pickups[i].z;
                        float d = sqrtf(dx * dx + dz * dz);
                        if (d < PICKUP_RANGE && d < best) { best = d; kind = 1; near_pickup = &pickups[i]; }
                    }
                    if (!door_target) {
                        float dx = px - ROOM_X0, dz = pz;
                        float d = sqrtf(dx * dx + dz * dz);
                        if (px < ROOM_X0 && d < DOOR_RANGE && d < best) { best = d; kind = 2; }
                    }
                    {
                        float dx = px - BEACON_X, dz = pz - BEACON_Z;
                        float d = sqrtf(dx * dx + dz * dz);
                        if (d < BEACON_RANGE && d < best) { best = d; kind = 3; }
                    }

                    {
                        float dx = px - NPC_X, dz = pz - NPC_Z;
                        float d = sqrtf(dx * dx + dz * dz);
                        if (d < NPC_RANGE && d < best) { best = d; kind = 4; }
                    }

                    if (kind == 1) snprintf(prompt_buf, sizeof(prompt_buf), "X: PICK UP %s", item_defs[near_pickup->item].name);
                    else if (kind == 2) snprintf(prompt_buf, sizeof(prompt_buf), "X: OPEN DOOR");
                    else if (kind == 3) snprintf(prompt_buf, sizeof(prompt_buf), "X: USE BEACON");
                    else if (kind == 4) snprintf(prompt_buf, sizeof(prompt_buf), "X: TALK");
                    if (kind) prompt = prompt_buf;

                    if (kind && (pressed & SCE_CTRL_CROSS)) {
                        if (kind == 1) {
                            if (inv_n < INV_MAX) {
                                inv[inv_n++] = near_pickup->item;
                                near_pickup->taken = 1;
                                snprintf(toast_buf, sizeof(toast_buf), "PICKED UP %s", item_defs[near_pickup->item].name);
                            } else {
                                snprintf(toast_buf, sizeof(toast_buf), "INVENTORY FULL");
                            }
                            toast_t = 2.0f;
                            prompt = NULL;
                        } else if (kind == 2) {
                            door_target = 1;
                            prompt = NULL;
                        } else if (kind == 3) {
                            menu = MENU_BEACON;
                            beacon_sel = 0;
                            prompt = NULL;
                        } else {
                            menu = MENU_DIALOGUE;
                            dlg_chars = 0.0f;
                            prompt = NULL;
                        }
                    }
                }
            }
        }

        // Camera effects during a dodge.
        if (dodge_t >= 0.0f) {
            float s = sinf(PI_F * dodge_t / DODGE_TIME);
            cam_roll = dodge_side * DODGE_ROLL_DEG * s;
            cam_drop = 0.12f * s;
        } else {
            cam_roll = 0.0f;
            cam_drop = 0.0f;
        }
        bob += dt * moving * 9.0f;

        g_cam_x = px; g_cam_z = pz; g_cam_eye = EYE_HEIGHT - cam_drop;
        g_cam_yaw = yaw; g_cam_pitch = pitch; g_cam_roll = cam_roll * PI_F / 180.0f;

        // ---- draw world ----
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        if (screen == SCREEN_GAME) {
        glEnable(GL_DEPTH_TEST);
        glEnable(GL_FOG);

        set_perspective();
        glLoadIdentity();
        glRotatef(cam_roll, 0, 0, 1);
        glRotatef(-pitch * 180.0f / PI_F, 1, 0, 0);
        glRotatef(-yaw * 180.0f / PI_F, 0, 1, 0);
        glTranslatef(-px, -(EYE_HEIGHT - cam_drop), -pz);

        glEnableClientState(GL_VERTEX_ARRAY);
        glEnableClientState(GL_COLOR_ARRAY);
        draw_mesh(&world_mesh);

        // Floating, spinning pick-ups.
        for (int i = 0; i < NUM_PICKUPS; i++) {
            if (pickups[i].taken) continue;
            glPushMatrix();
            glTranslatef(pickups[i].x, 1.25f + sinf(t * 2.0f + i) * 0.1f, pickups[i].z);
            glRotatef(t * 70.0f + i * 90.0f, 0, 1, 0);
            glTranslatef(0, -0.4f, 0);
            draw_mesh(item_defs[pickups[i].item].mesh);
            glPopMatrix();
        }

        // Training dummy: slashes rock it sideways, blunt blows rock it back.
        glPushMatrix();
        glTranslatef(DUMMY_X, 0.0f, DUMMY_Z);
        if (dummy_wobble >= 0.0f) {
            float ang = sinf(dummy_wobble * 28.0f) * expf(-dummy_wobble * 5.0f) * dummy_hit_amp;
            if (dummy_hit_type == DMG_SLASH) glRotatef(ang, 0, 0, 1);
            else                             glRotatef(ang, 1, 0, 0);
        }
        draw_mesh(&dummy_mesh);
        glPopMatrix();

        // Door (swings open about its hinge, into the room).
        glPushMatrix();
        glTranslatef(ROOM_X0, 0.0f, DOOR_HALF);
        glRotatef(-95.0f * smooth01(door_open_t), 0, 1, 0);
        draw_mesh(&door_mesh);
        glPopMatrix();

        // Beacon crystal.
        glPushMatrix();
        glTranslatef(BEACON_X, 1.9f + sinf(t * 2.0f) * 0.08f, BEACON_Z);
        glRotatef(t * 50.0f, 0, 1, 0);
        draw_mesh(&gem_mesh);
        glPopMatrix();

        // Enemies.
        for (int i = 0; i < NUM_ENEMIES; i++) draw_enemy(&enemies[i], t);

        // The wanderer by the door: turns to face you when you're near, breathes gently.
        {
            float tdx = px - NPC_X, tdz = pz - NPC_Z;
            float target = NPC_REST_YAW;
            if (tdx * tdx + tdz * tdz < 49.0f) target = atan2f(tdx, tdz);
            float diff = target - npc_yaw;
            while (diff >  PI_F) diff -= 2.0f * PI_F;
            while (diff < -PI_F) diff += 2.0f * PI_F;
            npc_yaw += diff * fminf(1.0f, 5.0f * dt);
            glPushMatrix();
            glTranslatef(NPC_X, 0.0f, NPC_Z);
            glRotatef(npc_yaw * 180.0f / PI_F, 0, 1, 0);
            glScalef(1.0f, 1.0f + sinf(t * 1.6f) * 0.012f, 1.0f);
            draw_mesh(&npc_mesh);
            glPopMatrix();
        }

        // ---- draw held weapon (view model) ----
        // Depth is cleared so it never clips into walls; no fog on the hand.
        glClear(GL_DEPTH_BUFFER_BIT);
        glDisable(GL_FOG);
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();

        Pose ap = {0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
        if (attack_t >= 0.0f && equipped_slot >= 0) {
            const ItemDef *wd = &item_defs[inv[equipped_slot]];
            ap = swing_pose(wd->swing, attack_t / wd->swing_time);
        }
        float dodge_dip = (dodge_t >= 0.0f) ? 0.06f * sinf(PI_F * dodge_t / DODGE_TIME) : 0.0f;
        float vm_tx = VM_X + ap.dx + sinf(bob) * 0.012f * moving;
        float vm_ty = VM_Y + ap.dy - dodge_dip + fabsf(sinf(bob)) * 0.018f * moving + sinf(t * 1.5f) * 0.004f;
        float vm_tz = VM_Z + ap.dz;
        float vm_rz = VM_ROT_Z + ap.rz, vm_rx = VM_ROT_X + ap.rx;

        // Arm first (camera space): stays anchored at the shoulder and stretches to the wrist.
        vec3 wrist = vm_point(V(0.06f, -0.16f, 0.0f), vm_tx, vm_ty, vm_tz, vm_rz, vm_rx);
        build_arm(V(ARM_ANCHOR_X, ARM_ANCHOR_Y, ARM_ANCHOR_Z), wrist);
        draw_mesh(&arm_mesh);

        // Hand + weapon.
        glTranslatef(vm_tx, vm_ty, vm_tz);
        glRotatef(vm_rz, 0, 0, 1);
        glRotatef(vm_rx, 1, 0, 0);
        draw_mesh(&hand_mesh);
        if (equipped_slot >= 0) draw_mesh(item_defs[inv[equipped_slot]].mesh);
        glDisableClientState(GL_COLOR_ARRAY);
        glDisableClientState(GL_VERTEX_ARRAY);

        }   // end of in-game drawing

        // ---- draw HUD ----
        build_hud(prompt, toast_t > 0.0f ? toast_buf : NULL);
        glDisable(GL_DEPTH_TEST);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        glOrtho(0, 960, 544, 0, -1, 1);
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();
        glEnableClientState(GL_VERTEX_ARRAY);
        glEnableClientState(GL_COLOR_ARRAY);
        glVertexPointer(2, GL_FLOAT, 0, hud_v);
        glColorPointer(4, GL_FLOAT, 0, hud_c);
        if (hud_n > 0) glDrawArrays(GL_TRIANGLES, 0, hud_n);
        glDisableClientState(GL_COLOR_ARRAY);
        glDisableClientState(GL_VERTEX_ARRAY);
        glDisable(GL_BLEND);

        // ---- bestiary: spinning 3D model inside the preview frame ----
        if (menu == MENU_BESTIARY && bestiary_seen[bestiary_sel]) {
            const EnemyDef *bd = &enemy_defs[bestiary_sel];
            const float dist = 2.2f;
            float ndc_x = (PREVIEW_X + PREVIEW_W / 2.0f) / 480.0f - 1.0f;
            float ndc_y = 1.0f - (PREVIEW_Y + PREVIEW_H / 2.0f) / 272.0f;
            glClear(GL_DEPTH_BUFFER_BIT);
            glEnable(GL_DEPTH_TEST);
            set_perspective();
            glLoadIdentity();
            glTranslatef(ndc_x * dist * 0.70020753f * (960.0f / 544.0f), ndc_y * dist * 0.70020753f, -dist);
            glRotatef(18.0f, 1, 0, 0);
            glRotatef(t * 40.0f, 0, 1, 0);
            glScalef(0.85f, 0.85f, 0.85f);
            glTranslatef(0.0f, -0.15f, 0.12f);   // centre the model
            glEnableClientState(GL_VERTEX_ARRAY);
            glEnableClientState(GL_COLOR_ARRAY);
            draw_mesh(bd->mesh);
            glDisableClientState(GL_COLOR_ARRAY);
            glDisableClientState(GL_VERTEX_ARRAY);
            glDisable(GL_DEPTH_TEST);
        }

        vglSwapBuffers(GL_FALSE);
    }

    sceKernelExitProcess(0);
    return 0;
}
