// Claude Field - PS Vita homebrew (a nod to King's Field)
// First-person camera, PS1-style low-poly world, held-weapon view model,
// three weapon slots, enemies, rooms, beacons, XP and save files.
//
// Controls
//   Left stick   walk            Right stick  look
//   O            dodge: side-step toward the stick (back-step if neutral)
//   R            attack with the weapon in hand (slash / blunt / thrust)
//   L            left hand (fireball spell, or the torch is just held)
//   TRIANGLE     jump (height grows with the Athletics attribute)
//   SQUARE       use the selected hot-bar item (herb / potion / bomb)
//   D-pad U/D    swap between your three equipped weapons
//   D-pad L/R    choose the hot-bar item
//   X            interact (pick up / open door / talk / use beacon)
//   SELECT       equipment + items (L / R switch pages)
//   START        action menu (bestiary, main menu, close game); START again closes it
//   (menus)      D-pad up/down select, X confirm, O back
//
// Rendering: vitaGL (fixed-function), flat-shaded, vertex-colored, linear fog.

#include <vitasdk.h>
#include <vitaGL.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <stddef.h>

/* Build-time padding (set by CMake) to keep vita-elf-create happy. */
#ifndef PAD_BYTES
#define PAD_BYTES 0
#endif
#define PAD_STR2(x) #x
#define PAD_STR(x) PAD_STR2(x)
#if PAD_BYTES > 0
__asm__(".text\n.space " PAD_STR(PAD_BYTES) "\n");
#endif


#define WORLD_HALF  70.0f      // the grass spans -70..+80 on X and Z
#define EYE_HEIGHT  1.6f
#define MOVE_SPEED  4.5f       // units / second
#define LOOK_SPEED  2.4f       // radians / second at full stick
#define DEADZONE    0.15f
#define PLAYER_R    0.4f
#define PI_F        3.14159265f

// ---- Held-weapon placement in camera space (tweak these to taste) ----
// The weapon is modelled with its grip at the origin and the blade along +Y.
#define VM_X        0.62f      // + = right
#define VM_Y       -0.25f      // + = up
#define VM_Z       -0.74f      // - = away from camera
#define VM_ROT_Z    2.0f       // lean blade toward the left (degrees); 0 = straight up
#define VM_ROT_X   -8.0f       // tilt blade away from the camera (degrees)
// The arm is anchored off-screen at the shoulder (camera space) and stretches
// to the hand during swings.
#define ARM_ANCHOR_X        1.47f
#define ARM_ANCHOR_Y       -0.80f
#define ARM_ANCHOR_Z       -0.59f

// ---- Player stats / mechanics (tweak these) ----
#define MAX_HEALTH            100.0f
#define MAX_STAMINA           100.0f
#define STAMINA_REGEN          35.0f   // per second
#define STAMINA_REGEN_DELAY     0.8f   // seconds before regen after using stamina
#define STAMINA_EXHAUST_DELAY   1.4f   // longer delay if stamina hits zero
#define DODGE_COST             20.0f
#define DODGE_DISTANCE          3.2f   // world units
#define DODGE_TIME              0.28f  // seconds
#define DODGE_ROLL_DEG          4.0f   // camera tilt during a dodge
#define SPRINT_MULT             1.65f  // hold O while moving
#define SPRINT_DRAIN           14.0f   // stamina per second
#define SPRINT_HOLD_TIME        0.20f  // a tap shorter than this is a dodge

// ---- Weapon stats (hit_start / hit_end are fractions of the swing) ----
#define SWORD_DAMAGE         20.0f     // slashing
#define SWORD_SWING_TIME      0.66f
#define SWORD_STAMINA_COST   18.0f
#define SWORD_RANGE           2.6f
#define SWORD_ARC_DEG        80.0f     // half-angle in front of the player
#define SWORD_HIT_START       0.36f
#define SWORD_HIT_END         0.60f

#define MACE_DAMAGE          35.0f     // blunt
#define MACE_SWING_TIME       1.15f
#define MACE_STAMINA_COST    38.0f
#define MACE_RANGE            2.3f
#define MACE_ARC_DEG         50.0f
#define MACE_HIT_START        0.52f
#define MACE_HIT_END          0.72f

#define GLOAM_DAMAGE         36.0f     // the tower's secret slashing sword
#define SPEAR_DAMAGE         24.0f     // piercing
#define SPEAR_SWING_TIME      0.46f
#define SPEAR_STAMINA_COST   10.0f
#define SPEAR_RANGE           3.5f
#define SPEAR_ARC_DEG        24.0f     // narrow: a thrust only hits what you point at
#define SPEAR_HIT_START       0.34f
#define SPEAR_HIT_END         0.62f

#define SWAP_TIME             0.34f    // weapon swap animation (the weapon changes at the halfway point)

#define DUMMY_XP              500      // XP the training dummy pays per hit (a testing aid: lower or remove it later)
#define HERB_HEAL              30.0f
#define POTION_HEAL            75.0f
#define BOMB_DAMAGE            70.0f   // blast damage at the centre of the explosion
#define BOMB_RADIUS             3.6f
#define BOMB_SPEED             10.0f
#define BOMB_LOFT               4.2f
#define BOMB_GRAVITY           16.0f
#define USE_TIME                0.70f  // item use animation
#define USE_EFFECT_AT           0.50f  // fraction of it when the herb / potion works, or the bomb leaves your hand
#define CONS_MAX               99

// ---- HUD bars (pixels; colors are r, g, b) ----
#define BAR_X               24.0f
#define BAR_Y               22.0f
#define BAR_GAP              8.0f
#define HEALTH_BAR_W       320.0f      // width at 100 max health (scales with max)
#define HEALTH_BAR_H        18.0f
#define STAMINA_BAR_W      250.0f      // width at 100 max stamina (scales with max)
#define STAMINA_BAR_H       12.0f
#define HEALTH_COLOR        0.78f, 0.12f, 0.12f
#define STAMINA_COLOR       0.85f, 0.75f, 0.15f

// Training dummy position
#define DUMMY_X             2.5f
#define DUMMY_Z             0.0f

// ---- Beacon (the crystal): save / rest / teleport ----
#define BEACON_X             0.0f
#define BEACON_Z            -5.0f
#define BEACON_RANGE         2.8f

// ---- Stone room + door (east of the start area) ----
#define ROOM_X0             16.0f      // west wall (the door is in this wall)
#define ROOM_X1             26.0f
#define ROOM_Z0             -5.0f
#define ROOM_Z1              5.0f
#define ROOM_WALL_H          3.6f
#define DOOR_HALF            1.1f      // half the doorway width
#define DOOR_OPEN_SPEED      1.1f      // 1 / seconds to swing open or shut
#define DOOR_RANGE           2.6f
#define ROOM2_X1            36.0f      // the second room shares the first room's east wall (x = ROOM_X1)

// ---- Giant rat (tweak these) ----
#define WORLD_MIN          -69.5f
#define WORLD_MAX           79.5f

// ---- vertical movement / athletics ----
#define GRAVITY             20.0f
#define JUMP_BASE            0.40f     // jump apex (world units) with no athletics
#define JUMP_PER_LEVEL       0.055f    // extra apex per athletics point (before the soft cap)
#define JUMP_STAMINA         6.0f
#define STEP_TOL             0.22f     // you can step onto a ledge this far above your feet
#define ATTR_CAP            99         // every attribute tops out here (shown 1..99)
#define SOFTCAP_START       40         // attribute points after which each one is worth a little less...
#define SOFTCAP_END         60         // ...falling to SOFTCAP_SLOPE of a point by here
#define SOFTCAP_SLOPE        0.30f

// ---- the climbing tower (centre of the ring) ----
#define PZ_CX              -36.0f
#define PZ_CZ              -32.0f
#define PZ_RING_R            3.2f
#define PZ_HALF              1.0f      // half the width of each pillar top
#define PZ_CHEST_TOP         6.68f
#define PYR_X              -24.0f      // the sand pyramid
#define PYR_Z              -26.0f
#define CLOTH_CHEST_X      -24.0f      // tucked away behind the sand pyramid
#define CLOTH_CHEST_Z      -31.4f

// ---- the labyrinth: a walled maze building south-east of the start ----
#define MZ_COLS              7
#define MZ_ROWS              9
#define MZ_CELL              3.0f
#define MZ_X0               11.0f
#define MZ_Z0                8.0f
#define MZ_X1               (MZ_X0 + MZ_COLS * MZ_CELL)
#define MZ_Z1               (MZ_Z0 + MZ_ROWS * MZ_CELL)
#define MZ_WALL_H            3.2f
#define MZ_DOOR_ROW          3
#define MZ_DOOR_Z           (MZ_Z0 + (MZ_DOOR_ROW + 0.5f) * MZ_CELL)
#define MZ_PORTAL_ROW        4          // the door in the labyrinth's east wall that leads down to the cave
#define MZ_PZ               (MZ_Z0 + (MZ_PORTAL_ROW + 0.5f) * MZ_CELL)
#define TOME_X              (MZ_X0 + (MZ_COLS - 0.5f) * MZ_CELL)   // far corner cell
#define TOME_Z              (MZ_Z0 + (MZ_ROWS - 0.5f) * MZ_CELL)

// ---- the cave (a separate zone, built far from the overworld) ----
#define CV_W                40
#define CV_H                40
#define CV_CELL              2.4f
#define CV_X0              200.0f
#define CV_Z0                0.0f
#define CV_X1              (CV_X0 + CV_W * CV_CELL)
#define CV_Z1              (CV_Z0 + CV_H * CV_CELL)
#define CV_CEIL              9.0f
#define CV_ENT_ROW          20          // the entrance chamber's middle row
#define CV_DOOR_X          (CV_X0 + CV_CELL)
#define CV_DOOR_Z          (CV_Z0 + ((float)CV_ENT_ROW + 0.5f) * CV_CELL)
#define CV_START_X         (CV_X0 + 2.6f * CV_CELL)
#define CV_START_Z         CV_DOOR_Z
#define CVN_X              (CV_START_X + 1.2f)         // the dying man sits against the entrance chamber's north wall
#define CVN_Z              (CV_Z0 + 18.0f * CV_CELL + 0.6f)
#define DARK_FOG_END         7.0f       // without a torch you can barely see a few steps
#define TORCH_FOG_END       15.0f

#define RAT_HEALTH          30.0f      // sword (20 dmg) = 2 hits, mace (35 dmg) = 1 hit
#define RAT_RESIST_SLASH     1.0f      // damage multipliers: 1 = neutral, >1 weak, <1 resistant
#define RAT_RESIST_BLUNT     1.0f
#define RAT_RESIST_PIERCE    1.0f
#define RAT_SCALE            1.8f
#define RAT_RADIUS           0.45f
#define RAT_AGGRO_RANGE      8.0f
#define RAT_HOP_SPEED        3.4f      // units / second while hopping
#define RAT_HOP_TIME         0.42f     // seconds per hop
#define RAT_ATTACK_RANGE     2.7f      // starts its wind-up this close
#define RAT_WINDUP_TIME      0.60f     // readable crouch before the lunge
#define RAT_LUNGE_TIME       0.22f
#define RAT_LUNGE_SPEED     12.0f
#define RAT_RECOVER_TIME     0.90f     // helpless after a lunge
#define RAT_STAGGER_TIME     0.35f
#define RAT_DAMAGE           8.0f
#define RAT_HIT_RADIUS       0.95f

// ---- Rock crab (tweak these) ----
#define CRAB_HEALTH         60.0f      // mace (35 x 1.5) = 2 hits; sword and spear take many more
#define CRAB_RESIST_SLASH    0.4f      // strong against slashing
#define CRAB_RESIST_BLUNT    1.5f      // weak to blunt
#define CRAB_RESIST_PIERCE   0.5f      // strong against piercing
#define CRAB_SCALE           1.4f
#define CRAB_RADIUS          0.8f
#define CRAB_AGGRO_RANGE     7.0f
#define CRAB_SPEED           1.9f      // chasing
#define CRAB_WANDER_SPEED    0.9f      // strolling around its room
#define CRAB_ATTACK_RANGE    2.3f
#define CRAB_WINDUP_TIME     0.85f     // rears up, claws raised
#define CRAB_LUNGE_TIME      0.16f
#define CRAB_LUNGE_SPEED    10.0f
#define CRAB_RECOVER_TIME    1.2f
#define CRAB_STAGGER_TIME    0.2f
#define CRAB_DAMAGE         24.0f
#define CRAB_HIT_RADIUS      1.5f
#define CRAB_XP             15
#define CRAB_RESIST_FIRE     1.0f
#define CRAB_RESIST_BLAST    1.5f      // rock cracks under a blast

// ---- worm: weak to blunt and piercing, immune to slashing (which splits it in two instead) ----
#define WORM_HEALTH         44.0f
#define WORM_RESIST_SLASH    0.0f
#define WORM_RESIST_BLUNT    1.4f
#define WORM_RESIST_PIERCE   1.7f
#define WORM_RESIST_FIRE     1.0f
#define WORM_RESIST_BLAST    1.2f
#define WORM_SCALE           1.3f
#define WORM_RADIUS          0.55f
#define WORM_AGGRO_RANGE     7.5f
#define WORM_SPEED           3.0f
#define WORM_WANDER_SPEED    1.0f
#define WORM_ATTACK_RANGE    2.2f
#define WORM_WINDUP_TIME     0.95f     // rears up with its maw open
#define WORM_LUNGE_TIME      0.22f
#define WORM_LUNGE_SPEED     9.0f
#define WORM_RECOVER_TIME    1.2f
#define WORM_STAGGER_TIME    0.3f
#define WORM_DAMAGE        13.0f
#define WORM_HIT_RADIUS      1.3f
#define WORM_XP             10
#define WORM_MAX_SPLITS      2         // a worm splits at most twice (1 -> 2 -> 4 worms), each half smaller

// ---- risen soldier (undead): weak to piercing and fire ----
#define UNDEAD_HEALTH       70.0f
#define UNDEAD_RESIST_SLASH  0.8f
#define UNDEAD_RESIST_BLUNT  1.0f
#define UNDEAD_RESIST_PIERCE 1.6f
#define UNDEAD_RESIST_FIRE   1.0f
#define UNDEAD_RESIST_BLAST  1.0f
#define UNDEAD_RADIUS        0.5f
#define UNDEAD_AGGRO_RANGE   8.0f
#define UNDEAD_SPEED         1.7f
#define UNDEAD_WANDER_SPEED  0.8f
#define UNDEAD_ATTACK_RANGE  2.3f
#define UNDEAD_WINDUP_TIME   1.0f      // raises its sword overhead
#define UNDEAD_LUNGE_TIME    0.22f
#define UNDEAD_LUNGE_SPEED   6.5f
#define UNDEAD_RECOVER_TIME  1.3f
#define UNDEAD_STAGGER_TIME  0.25f
#define UNDEAD_DAMAGE       40.0f
#define UNDEAD_HIT_RADIUS    1.6f
#define UNDEAD_XP           25

// Zombie: slow and heavy-handed; same weaknesses as the risen soldier for now.
#define ZOMBIE_HEALTH       90.0f
#define ZOMBIE_RESIST_SLASH  0.8f
#define ZOMBIE_RESIST_BLUNT  1.0f
#define ZOMBIE_RESIST_PIERCE 1.6f
#define ZOMBIE_RESIST_FIRE   1.0f
#define ZOMBIE_RESIST_BLAST  1.0f
#define ZOMBIE_RADIUS        0.55f
#define ZOMBIE_AGGRO_RANGE   7.5f
#define ZOMBIE_SPEED         1.35f
#define ZOMBIE_WANDER_SPEED  0.6f
#define ZOMBIE_ATTACK_RANGE  2.1f
#define ZOMBIE_WINDUP_TIME   1.1f      // both arms hauled overhead
#define ZOMBIE_LUNGE_TIME    0.25f
#define ZOMBIE_LUNGE_SPEED   5.5f
#define ZOMBIE_RECOVER_TIME  1.4f
#define ZOMBIE_STAGGER_TIME  0.2f
#define ZOMBIE_DAMAGE       32.0f
#define ZOMBIE_HIT_RADIUS    1.55f
#define ZOMBIE_XP           30

// ---- left hand: the fireball spell ----
#define FIRE_DAMAGE         32.0f
#define FIRE_STAMINA        22.0f
#define FIRE_SPEED          12.0f
#define FIRE_RANGE          20.0f
#define CAST_TIME            0.80f
#define CAST_SPAWN           0.42f     // the fireball leaves your hand this far into the cast

#define DODGE_IFRAME_FRAC    0.7f      // portion of a dodge where you can't be hurt

// ---- XP / attributes (tweak these) ----
// XP is a currency you carry. At a beacon you spend it to raise your level: going from level L to
// Going from level L to L+1 costs XP_BASE * XP_GROWTH^(L-1): exponential, so farming weak enemies stops paying off.
#define CORPSE_LINGER        4.0f      // seconds a body lies there before it starts to fade
#define CORPSE_FADE          1.5f
#define XP_BASE              6
#define XP_GROWTH            1.2966f     // each level costs this much more than the one before
#define XP_POP_DELAY         1.1f      // seconds a "+N" waits before it merges into the counter
#define RAT_XP               5
#define RAT_RESIST_FIRE      1.0f      // (fire hurts everything equally for now)
#define RAT_RESIST_BLAST     1.0f
#define HP_PER_LEVEL        10.0f      // max health per Health point
#define STAM_PER_LEVEL       8.0f      // max stamina per Stamina point
#define STR_BONUS            0.10f     // extra weapon damage per Strength point (0.10 = +10%)

// ---- Save files ----
#ifndef SAVE_DIR
#define SAVE_DIR "ux0:data/PlainWalk"  // saves: save1.dat, save2.dat, save3.dat
#endif
#define NUM_SLOTS 3

// ---- NPC next to the door ----
#define NPC_X               14.6f
#define NPC_Z                3.0f
#define NPC_REST_YAW        -1.9f      // which way he faces when you're not near
#define NPC_RANGE            2.6f
#define SMITH_X             -4.0f      // the blacksmith's hut, next to the rest point
#define SMITH_Z             -8.9f
#define ANVIL_Z             -7.9f
#define FORGE_X             -2.8f
#define FORGE_Z             -9.5f
#define DIALOGUE_CPS        38.0f      // typewriter speed (characters / second)
#define RESPAWN_DELAY        2.5f      // seconds on the death screen

#define V(x, y, z)  ((vec3){(x), (y), (z)})
#define C(r, g, b)  ((rgb){(r), (g), (b)})

typedef struct { float x, y, z; } vec3;
typedef struct { float r, g, b; } rgb;
typedef struct { float x, z, r; } collider;

// ---------------------------------------------------------------- mesh ----

typedef struct { float *v; float *c; int n; int max; float *uv; float *uv0; unsigned *tex; float *vs; int use_vs; } Mesh;   // uv: textured meshes only

#define DECLARE_MESH(name, maxv)                 \
    static float name##_v[(maxv) * 3];           \
    static float name##_c[(maxv) * 4];           \
    static Mesh name = { name##_v, name##_c, 0, (maxv), NULL, NULL, NULL, NULL, 0 }

// A mesh that is drawn with a (procedural) texture: uv is the shimmering copy, uv0 the baked original.
static unsigned tex_grain, tex_brick, tex_rock;
#define DECLARE_TEX_MESH(name, maxv, texvar)     \
    static float name##_v[(maxv) * 3];           \
    static float name##_c[(maxv) * 4];           \
    static float name##_uv[(maxv) * 2];          \
    static float name##_uv0[(maxv) * 2];         \
    static Mesh name = { name##_v, name##_c, 0, (maxv), name##_uv, name##_uv0, &texvar, NULL, 0 }

DECLARE_TEX_MESH(world_mesh, 70000, tex_grain);   // ground, trees, props
DECLARE_TEX_MESH(brick_mesh, 24000, tex_brick);   // the walls of the buildings
DECLARE_TEX_MESH(cave_mesh, 90000, tex_rock);     // the whole cave
DECLARE_MESH(hand_mesh, 1500);
DECLARE_MESH(sword_mesh, 1000);
DECLARE_MESH(mace_mesh, 1500);
DECLARE_MESH(dummy_mesh, 1500);
DECLARE_MESH(arm_mesh, 400);
DECLARE_MESH(rat_mesh, 600);
DECLARE_MESH(door_mesh, 200);
DECLARE_MESH(gem_mesh, 200);
DECLARE_MESH(npc_mesh, 500);
DECLARE_MESH(smith_mesh, 700);
DECLARE_MESH(smitharm_mesh, 200);
DECLARE_MESH(bonespear_mesh, 600);
DECLARE_MESH(axe_mesh, 600);
DECLARE_MESH(basaltmace_mesh, 1500);
DECLARE_MESH(brute_mesh, 1400);
DECLARE_MESH(brutearms_mesh, 600);
DECLARE_MESH(warden_mesh, 1800);
DECLARE_MESH(wardenarms_mesh, 800);
DECLARE_MESH(spear_mesh, 600);
DECLARE_MESH(crab_mesh, 1800);
DECLARE_MESH(gloam_mesh, 1400);
DECLARE_MESH(chest_mesh, 400);
DECLARE_MESH(chestlid_mesh, 300);
DECLARE_MESH(worm_mesh, 1400);
DECLARE_MESH(undead_mesh, 1800);
DECLARE_MESH(undeadarm_mesh, 800);
DECLARE_MESH(lhand_mesh, 700);
DECLARE_MESH(fire_mesh, 200);
DECLARE_MESH(herb_mesh, 300);
DECLARE_MESH(potion_mesh, 300);
DECLARE_MESH(bomb_mesh, 300);
DECLARE_MESH(torch_mesh, 300);
DECLARE_MESH(spark_mesh, 60);
DECLARE_MESH(ember_mesh, 60);
DECLARE_MESH(pick_mesh, 700);
DECLARE_MESH(zombie_mesh, 1400);
DECLARE_MESH(zombiearms_mesh, 600);
DECLARE_MESH(dying_mesh, 900);

static Mesh *cur;   // mesh the add_* helpers currently write into

#define MAX_COLLIDERS 420
#define MAX_WALLS     720
static collider colliders[MAX_COLLIDERS];
static int      ncolliders = 0;

static void add_collider(float x, float z, float r) {
    if (ncolliders < MAX_COLLIDERS) colliders[ncolliders++] = (collider){x, z, r};
}

// Axis-aligned wall boxes (the stone room). Can be switched off (the door).
typedef struct { float x0, z0, x1, z1; int on; } wall_t;
static wall_t walls[MAX_WALLS];
static int    nwalls = 0;

// Zones: 0 = the overworld (grass, rooms, labyrinth), 1 = the cave. The cave sits far away in the same coordinate
// space; only the walls and colliders of the zone you are in are ever tested.
static int zone = 0;
static int zw0 = 0, zw1 = 0, zc0 = 0, zc1 = 0;
static int nw_over = 0, nc_over = 0;
static void set_zone(int z) {
    zone = z;
    if (z == 0) { zw0 = 0; zw1 = nw_over; zc0 = 0; zc1 = nc_over; }
    else        { zw0 = nw_over; zw1 = nwalls; zc0 = nc_over; zc1 = ncolliders; }
}

// Doors: 0 = outside -> first room (west wall), 1 = first room -> second room (east wall).
typedef struct { float x, z; float open_t; int target; int wall; int locked; } Door;   // open_t 0 shut .. 1 open
#define NUM_DOORS 3   // [2] is the labyrinth door (locked until you have the key)
static Door doors[NUM_DOORS] = {
    { ROOM_X0, 0.0f, 0.0f, 0, -1, 0 },
    { ROOM_X1, 0.0f, 0.0f, 0, -1, 0 },
    { MZ_X0, MZ_DOOR_Z, 0.0f, 0, -1, 1 },
};

// Portals: a door you open with X that carries you to the other zone (with a fade).
typedef struct { float x, z; int zone; float dest_x, dest_z, dest_yaw; int dest_zone; const char *prompt; } Portal;
#define NUM_PORTALS 2
static const Portal portals[NUM_PORTALS] = {
    { MZ_X1, MZ_PZ, 0, CV_START_X, CV_START_Z, -PI_F / 2.0f, 1, "X: OPEN THE DOOR" },
    { CV_DOOR_X, CV_DOOR_Z, 1, MZ_X1 - 1.6f, MZ_PZ, PI_F / 2.0f, 0, "X: GO BACK UP" },
};

// The maze layout: bit k set = open passage toward direction k (0 +x, 1 -x, 2 +z, 3 -z).
static unsigned char maze_open[MZ_ROWS][MZ_COLS];
static const int mz_dc[4] = { 1, -1, 0, 0 };
static const int mz_dr[4] = { 0, 0, 1, -1 };

static int add_wall_collider(float x0, float z0, float x1, float z1) {
    if (nwalls >= MAX_WALLS) return -1;
    walls[nwalls] = (wall_t){x0, z0, x1, z1, 1};
    return nwalls++;
}

// Push a circle (x, z, radius r) out of every circle collider and active wall.
static void resolve_collisions(float *x, float *z, float r) {
    for (int i = zc0; i < zc1; i++) {
        float dx = *x - colliders[i].x, dz = *z - colliders[i].z;
        float d = sqrtf(dx * dx + dz * dz);
        float minD = colliders[i].r + r;
        if (d < minD && d > 1e-4f) {
            *x = colliders[i].x + dx / d * minD;
            *z = colliders[i].z + dz / d * minD;
        }
    }
    for (int i = zw0; i < zw1; i++) {
        const wall_t *w = &walls[i];
        if (!w->on) continue;
        float cx = fminf(fmaxf(*x, w->x0), w->x1);
        float cz = fminf(fmaxf(*z, w->z0), w->z1);
        float dx = *x - cx, dz = *z - cz;
        float d2 = dx * dx + dz * dz;
        if (d2 >= r * r) continue;
        if (d2 > 1e-8f) {
            float d = sqrtf(d2);
            *x = cx + dx / d * r;
            *z = cz + dz / d * r;
        } else {   // centre is inside the box: leave by the nearest side
            float l = *x - w->x0, rt = w->x1 - *x, tp = *z - w->z0, bt = w->z1 - *z;
            float m = fminf(fminf(l, rt), fminf(tp, bt));
            if (m == l) *x = w->x0 - r;
            else if (m == rt) *x = w->x1 + r;
            else if (m == tp) *z = w->z0 - r;
            else *z = w->z1 + r;
        }
    }
}

// The play area: the grass plane, plus the two rooms that stick out past its east edge.
static void clamp_world(float *x, float *z) {
    float lx = WORLD_MIN, hx = WORLD_MAX, lz = WORLD_MIN, hz = WORLD_MAX;
    if (zone == 1) { lx = CV_X0 + 0.6f; hx = CV_X1 - 0.6f; lz = CV_Z0 + 0.6f; hz = CV_Z1 - 0.6f; }
    if (*x > hx) *x = hx;
    if (*x < lx) *x = lx;
    if (*z > hz) *z = hz;
    if (*z < lz) *z = lz;
}

// Push a circle out of a box (shared by walls and platforms).
static void push_out_aabb(float *x, float *z, float r, float x0, float z0, float x1, float z1) {
    float cx = fminf(fmaxf(*x, x0), x1);
    float cz = fminf(fmaxf(*z, z0), z1);
    float dx = *x - cx, dz = *z - cz;
    float d2 = dx * dx + dz * dz;
    if (d2 >= r * r) return;
    if (d2 > 1e-8f) {
        float d = sqrtf(d2);
        *x = cx + dx / d * r;
        *z = cz + dz / d * r;
    } else {
        float l = *x - x0, rt = x1 - *x, tp = *z - z0, bt = z1 - *z;
        float m = fminf(fminf(l, rt), fminf(tp, bt));
        if (m == l) *x = x0 - r;
        else if (m == rt) *x = x1 + r;
        else if (m == tp) *z = z0 - r;
        else *z = z1 + r;
    }
}

// Climbable platforms (the tower). You can only walk onto one if your feet are high enough.
typedef struct { float x0, z0, x1, z1, top, y0; } plat_t;   // y0 = underside (0 = a solid block from the ground)
#define MAX_PLATS 128
static plat_t plats[MAX_PLATS];
static int    nplats = 0;

static float floor_at(float x, float z, float feet) {
    float best = 0.0f;
    for (int i = 0; i < nplats; i++) {
        const plat_t *p = &plats[i];
        if (x >= p->x0 && x <= p->x1 && z >= p->z0 && z <= p->z1 && p->top <= feet + STEP_TOL && p->top > best) best = p->top;
    }
    return best;
}

static void resolve_plats(float *x, float *z, float r, float feet) {
    for (int i = 0; i < nplats; i++) {
        const plat_t *p = &plats[i];
        if (feet < p->top - STEP_TOL && feet + 1.8f > p->y0) push_out_aabb(x, z, r, p->x0, p->z0, p->x1, p->z1);
    }
}

// Is the straight line between two floor points free of walls (closed doors count as walls)?
static int los_clear(float ax, float az, float bx, float bz) {
    float dx = bx - ax, dz = bz - az;
    for (int i = zw0; i < zw1; i++) {
        const wall_t *w = &walls[i];
        if (!w->on) continue;
        float t0 = 0.0f, t1 = 1.0f;
        int miss = 0;
        for (int ax_i = 0; ax_i < 2 && !miss; ax_i++) {
            float a = ax_i ? az : ax, d = ax_i ? dz : dx;
            float lo = ax_i ? w->z0 : w->x0, hi = ax_i ? w->z1 : w->x1;
            if (fabsf(d) < 1e-6f) { if (a < lo || a > hi) miss = 1; }
            else {
                float ta = (lo - a) / d, tb = (hi - a) / d;
                if (ta > tb) { float tt = ta; ta = tb; tb = tt; }
                if (ta > t0) t0 = ta;
                if (tb < t1) t1 = tb;
                if (t0 > t1) miss = 1;
            }
        }
        if (!miss) return 0;
    }
    return 1;
}

// First wall / object hit by the segment a -> b (floor plane). Returns 1 and the hit point if there is one.
static int ray_hit(float ax, float az, float bx, float bz, float *hx, float *hz) {
    float dx = bx - ax, dz = bz - az, best = 2.0f;
    for (int i = zw0; i < zw1; i++) {
        const wall_t *w = &walls[i];
        if (!w->on) continue;
        float t0 = 0.0f, t1 = 1.0f;
        int miss = 0;
        for (int k = 0; k < 2 && !miss; k++) {
            float a = k ? az : ax, d = k ? dz : dx;
            float lo = k ? w->z0 : w->x0, hi = k ? w->z1 : w->x1;
            if (fabsf(d) < 1e-6f) { if (a < lo || a > hi) miss = 1; }
            else {
                float ta = (lo - a) / d, tb = (hi - a) / d;
                if (ta > tb) { float tt = ta; ta = tb; tb = tt; }
                if (ta > t0) t0 = ta;
                if (tb < t1) t1 = tb;
                if (t0 > t1) miss = 1;
            }
        }
        if (!miss && t0 < best) best = t0;
    }
    for (int i = zc0; i < zc1; i++) {
        float fx = ax - colliders[i].x, fz = az - colliders[i].z, r = colliders[i].r;
        float A = dx * dx + dz * dz, B = 2.0f * (fx * dx + fz * dz), Cc = fx * fx + fz * fz - r * r;
        if (A < 1e-9f) continue;
        float disc = B * B - 4.0f * A * Cc;
        if (disc < 0.0f) continue;
        float t = (-B - sqrtf(disc)) / (2.0f * A);
        if (Cc < 0.0f) t = 0.0f;
        if (t >= 0.0f && t < best) best = t;
    }
    if (best > 1.0f) return 0;
    *hx = ax + dx * best; *hz = az + dz * best;
    return 1;
}

static vec3 v_sub(vec3 a, vec3 b) { return V(a.x - b.x, a.y - b.y, a.z - b.z); }
static vec3 v_cross(vec3 a, vec3 b) {
    return V(a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x);
}
static vec3 v_norm(vec3 a) {
    float l = sqrtf(a.x * a.x + a.y * a.y + a.z * a.z);
    return l > 1e-6f ? V(a.x / l, a.y / l, a.z / l) : V(0, 1, 0);
}

// Flat-shaded triangle. Shading is baked from a fixed light direction and is
// two-sided, so winding order doesn't matter.
static void add_tri(vec3 a, vec3 b, vec3 c, rgb col) {
    if (cur->n + 3 > cur->max) return;

    vec3 n = v_cross(v_sub(b, a), v_sub(c, a));
    float len = sqrtf(n.x * n.x + n.y * n.y + n.z * n.z);

    float shade = 0.7f;
    if (len > 1e-6f) {
        float d = fabsf((n.x * 0.45f + n.y * 0.80f + n.z * 0.40f) / len);
        shade = 0.45f + 0.55f * d;
    }

    vec3 p[3] = {a, b, c};
    for (int i = 0; i < 3; i++) {
        int k = cur->n++;
        cur->v[k * 3 + 0] = p[i].x;
        cur->v[k * 3 + 1] = p[i].y;
        cur->v[k * 3 + 2] = p[i].z;
        cur->c[k * 4 + 0] = col.r * shade;
        cur->c[k * 4 + 1] = col.g * shade;
        cur->c[k * 4 + 2] = col.b * shade;
        cur->c[k * 4 + 3] = 1.0f;
    }
}

static void add_quad(vec3 a, vec3 b, vec3 c, vec3 d, rgb col) {
    add_tri(a, b, c, col);
    add_tri(a, c, d, col);
}

static void add_box(float cx, float y0, float cz, float sx, float sy, float sz, rgb col) {
    float x0 = cx - sx / 2, x1 = cx + sx / 2;
    float z0 = cz - sz / 2, z1 = cz + sz / 2;
    float y1 = y0 + sy;
    add_quad(V(x0, y1, z0), V(x1, y1, z0), V(x1, y1, z1), V(x0, y1, z1), col); // top
    add_quad(V(x0, y0, z1), V(x1, y0, z1), V(x1, y1, z1), V(x0, y1, z1), col); // +z
    add_quad(V(x1, y0, z0), V(x0, y0, z0), V(x0, y1, z0), V(x1, y1, z0), col); // -z
    add_quad(V(x1, y0, z1), V(x1, y0, z0), V(x1, y1, z0), V(x1, y1, z1), col); // +x
    add_quad(V(x0, y0, z0), V(x0, y0, z1), V(x0, y1, z1), V(x0, y1, z0), col); // -x
}

static void add_pyramid(float cx, float y0, float cz, float base, float height, rgb col) {
    float h = base / 2;
    vec3 p0 = V(cx - h, y0, cz - h), p1 = V(cx + h, y0, cz - h);
    vec3 p2 = V(cx + h, y0, cz + h), p3 = V(cx - h, y0, cz + h);
    vec3 apex = V(cx, y0 + height, cz);
    add_tri(p0, p1, apex, col);
    add_tri(p1, p2, apex, col);
    add_tri(p2, p3, apex, col);
    add_tri(p3, p0, apex, col);
    add_quad(p0, p1, p2, p3, col);
}

static void add_cylinder(float cx, float y0, float cz, float r, float height, int sides, rgb col) {
    float y1 = y0 + height;
    for (int i = 0; i < sides; i++) {
        float a0 = 2 * PI_F * i / sides, a1 = 2 * PI_F * (i + 1) / sides;
        vec3 b0 = V(cx + cosf(a0) * r, y0, cz + sinf(a0) * r);
        vec3 b1 = V(cx + cosf(a1) * r, y0, cz + sinf(a1) * r);
        vec3 t0 = V(b0.x, y1, b0.z), t1 = V(b1.x, y1, b1.z);
        add_quad(b0, b1, t1, t0, col);
        add_tri(V(cx, y1, cz), t0, t1, col);
    }
}

static void add_cone(float cx, float y0, float cz, float r, float height, int sides, rgb col) {
    vec3 apex = V(cx, y0 + height, cz);
    for (int i = 0; i < sides; i++) {
        float a0 = 2 * PI_F * i / sides, a1 = 2 * PI_F * (i + 1) / sides;
        vec3 b0 = V(cx + cosf(a0) * r, y0, cz + sinf(a0) * r);
        vec3 b1 = V(cx + cosf(a1) * r, y0, cz + sinf(a1) * r);
        add_tri(b0, b1, apex, col);
        add_tri(V(cx, y0, cz), b0, b1, col);
    }
}

// Tube between two arbitrary points (arms, handles, shafts).
static void add_prism(vec3 a, vec3 b, float r, int sides, rgb col) {
    vec3 d = v_norm(v_sub(b, a));
    vec3 ref = fabsf(d.y) < 0.9f ? V(0, 1, 0) : V(1, 0, 0);
    vec3 u = v_norm(v_cross(d, ref));
    vec3 w = v_cross(d, u);
    for (int i = 0; i < sides; i++) {
        float a0 = 2 * PI_F * i / sides, a1 = 2 * PI_F * (i + 1) / sides;
        float c0 = cosf(a0) * r, s0 = sinf(a0) * r, c1 = cosf(a1) * r, s1 = sinf(a1) * r;
        vec3 o0 = V(u.x * c0 + w.x * s0, u.y * c0 + w.y * s0, u.z * c0 + w.z * s0);
        vec3 o1 = V(u.x * c1 + w.x * s1, u.y * c1 + w.y * s1, u.z * c1 + w.z * s1);
        vec3 a0p = V(a.x + o0.x, a.y + o0.y, a.z + o0.z), a1p = V(a.x + o1.x, a.y + o1.y, a.z + o1.z);
        vec3 b0p = V(b.x + o0.x, b.y + o0.y, b.z + o0.z), b1p = V(b.x + o1.x, b.y + o1.y, b.z + o1.z);
        add_quad(a0p, a1p, b1p, b0p, col);
        add_tri(b, b0p, b1p, col);
    }
}

static void add_octahedron(float cx, float cy, float cz, float r, rgb c1, rgb c2) {
    vec3 top = V(cx, cy + r * 1.4f, cz), bot = V(cx, cy - r * 1.4f, cz);
    vec3 e[4] = {V(cx + r, cy, cz), V(cx, cy, cz + r), V(cx - r, cy, cz), V(cx, cy, cz - r)};
    for (int i = 0; i < 4; i++) {
        vec3 a = e[i], b = e[(i + 1) % 4];
        add_tri(a, b, top, (i & 1) ? c1 : c2);
        add_tri(b, a, bot, (i & 1) ? c2 : c1);
    }
}

// --------------------------------------------------------------- scene ----

static void build_ground(void) {
    const int n = 50;   // -70 .. +80
    const float t = 3.0f;
    for (int j = 0; j < n; j++) {
        for (int i = 0; i < n; i++) {
            float x0 = -WORLD_HALF + i * t, z0 = -WORLD_HALF + j * t;
            float var = ((i * 7 + j * 13) % 3) * 0.025f;
            rgb c = ((i + j) & 1) ? C(0.26f + var, 0.50f + var, 0.22f)
                                  : C(0.22f + var, 0.44f + var, 0.19f);
            add_quad(V(x0, 0, z0), V(x0, 0, z0 + t), V(x0 + t, 0, z0 + t), V(x0 + t, 0, z0), c);
        }
    }
}

static void add_tree(float x, float z) {
    add_cylinder(x, 0.0f, z, 0.25f, 1.6f, 6, C(0.40f, 0.26f, 0.14f));
    add_cone(x, 1.4f, z, 1.4f, 3.2f, 7, C(0.10f, 0.35f, 0.14f));
    add_cone(x, 3.0f, z, 1.0f, 2.4f, 7, C(0.13f, 0.42f, 0.17f));
    add_collider(x, z, 0.5f);
}

// A dead tree: grey bark, a crooked trunk and a few bare branches. Branch directions vary with where it stands.
static void add_dead_tree(float x, float z, float h) {
    rgb bark = C(0.34f, 0.29f, 0.25f), bark2 = C(0.26f, 0.22f, 0.19f);
    float a = x * 1.7f + z * 2.9f, c = cosf(a), s = sinf(a);
    add_cylinder(x, 0.0f, z, 0.30f, 0.7f, 6, bark2);
    add_prism(V(x, 0.6f, z), V(x + 0.07f, h * 0.55f, z - 0.05f), 0.17f, 5, bark);
    add_prism(V(x + 0.07f, h * 0.52f, z - 0.05f), V(x + 0.02f, h, z + 0.06f), 0.09f, 5, bark);
    float bx[3] = { 0.95f, -0.85f, 0.25f }, bz[3] = { 0.20f, -0.40f, -0.80f };
    float by[3] = { h * 0.80f, h * 0.96f, h * 1.14f }, sy[3] = { h * 0.45f, h * 0.62f, h * 0.80f };
    for (int i = 0; i < 3; i++) {
        float ex = x + bx[i] * c - bz[i] * s, ez = z + bx[i] * s + bz[i] * c;
        add_prism(V(x + 0.05f, sy[i], z - 0.03f), V(ex, by[i], ez), 0.07f - 0.012f * i, 4, i == 2 ? bark2 : bark);
        add_prism(V(ex, by[i], ez), V(ex + (bx[i] > 0 ? 0.35f : -0.35f) * c, by[i] + 0.38f, ez + 0.2f * s), 0.035f, 4, bark2);
    }
    add_collider(x, z, 0.45f);
}

// Building walls go into their own (brick-textured) mesh.
static void add_brick_box(float cx, float y0, float cz, float sx, float sy, float sz, rgb col) {
    Mesh *prev = cur;
    cur = &brick_mesh;
    add_box(cx, y0, cz, sx, sy, sz, col);
    cur = prev;
}

static void add_wall_block(float x0, float z0, float x1, float z1, float h, rgb col) {
    add_brick_box((x0 + x1) / 2, 0.0f, (z0 + z1) / 2, x1 - x0, h, z1 - z0, col);
    add_wall_collider(x0, z0, x1, z1);
}

// A small enclosed stone room with a door in its west wall.
static void build_room(void) {
    rgb stone = C(0.46f, 0.46f, 0.52f), stone2 = C(0.40f, 0.40f, 0.46f), roof = C(0.26f, 0.26f, 0.31f);
    const float T = 0.25f;   // half wall thickness

    // Floor: dark checkered flagstones just above the grass.
    for (int j = 0; j < 5; j++) {
        for (int i = 0; i < 5; i++) {
            float x0 = ROOM_X0 + i * 2.0f, z0 = ROOM_Z0 + j * 2.0f;
            rgb c = ((i + j) & 1) ? C(0.32f, 0.32f, 0.36f) : C(0.27f, 0.27f, 0.31f);
            add_quad(V(x0, 0.05f, z0), V(x0, 0.05f, z0 + 2), V(x0 + 2, 0.05f, z0 + 2), V(x0 + 2, 0.05f, z0), c);
        }
    }

    add_wall_block(ROOM_X0 - T, ROOM_Z0 - T, ROOM_X1 + T, ROOM_Z0 + T, ROOM_WALL_H, stone);    // north
    add_wall_block(ROOM_X0 - T, ROOM_Z1 - T, ROOM_X1 + T, ROOM_Z1 + T, ROOM_WALL_H, stone);    // south
    add_wall_block(ROOM_X1 - T, ROOM_Z0 + T, ROOM_X1 + T, -DOOR_HALF, ROOM_WALL_H, stone2);    // east, left of door
    add_wall_block(ROOM_X1 - T, DOOR_HALF, ROOM_X1 + T, ROOM_Z1 - T, ROOM_WALL_H, stone2);     // east, right of door
    add_brick_box(ROOM_X1, 2.8f, 0.0f, 2 * T, ROOM_WALL_H - 2.8f, 2 * DOOR_HALF, stone);            // lintel over the back door
    add_wall_block(ROOM_X0 - T, ROOM_Z0 + T, ROOM_X0 + T, -DOOR_HALF, ROOM_WALL_H, stone2);    // west, left of door
    add_wall_block(ROOM_X0 - T, DOOR_HALF, ROOM_X0 + T, ROOM_Z1 - T, ROOM_WALL_H, stone2);     // west, right of door
    add_brick_box(ROOM_X0, 2.8f, 0.0f, 2 * T, ROOM_WALL_H - 2.8f, 2 * DOOR_HALF, stone);            // lintel over the door
    add_brick_box((ROOM_X0 + ROOM_X1) / 2, ROOM_WALL_H, (ROOM_Z0 + ROOM_Z1) / 2,
            (ROOM_X1 - ROOM_X0) + 2 * T + 0.2f, 0.3f, (ROOM_Z1 - ROOM_Z0) + 2 * T + 0.2f, roof);   // roof

    // Invisible-when-open collider that fills the doorway while the door is shut.
    doors[0].wall = add_wall_collider(ROOM_X0 - 0.2f, -DOOR_HALF, ROOM_X0 + 0.2f, DOOR_HALF);
    doors[1].wall = add_wall_collider(ROOM_X1 - 0.2f, -DOOR_HALF, ROOM_X1 + 0.2f, DOOR_HALF);

    // A couple of crates for atmosphere.
    add_box(24.6f, 0.0f, -3.6f, 1.4f, 1.4f, 1.4f, C(0.55f, 0.38f, 0.18f));
    add_collider(24.6f, -3.6f, 1.0f);
    add_box(24.8f, 0.0f, 3.7f, 1.2f, 1.2f, 1.2f, C(0.50f, 0.34f, 0.16f));
    add_collider(24.8f, 3.7f, 0.9f);

    // ---- Second room, behind the first (its door is in the shared east wall) ----
    for (int j = 0; j < 5; j++) {
        for (int i = 0; i < 5; i++) {
            float x0 = ROOM_X1 + i * 2.0f, z0 = ROOM_Z0 + j * 2.0f;
            rgb c = ((i + j) & 1) ? C(0.21f, 0.25f, 0.23f) : C(0.17f, 0.21f, 0.19f);
            add_quad(V(x0, 0.05f, z0), V(x0, 0.05f, z0 + 2), V(x0 + 2, 0.05f, z0 + 2), V(x0 + 2, 0.05f, z0), c);
        }
    }
    add_wall_block(ROOM_X1 + T, ROOM_Z0 - T, ROOM2_X1 + T, ROOM_Z0 + T, ROOM_WALL_H, stone2);   // north
    add_wall_block(ROOM_X1 + T, ROOM_Z1 - T, ROOM2_X1 + T, ROOM_Z1 + T, ROOM_WALL_H, stone2);   // south
    add_wall_block(ROOM2_X1 - T, ROOM_Z0 + T, ROOM2_X1 + T, ROOM_Z1 - T, ROOM_WALL_H, stone);   // east
    add_brick_box((ROOM_X1 + ROOM2_X1) / 2, ROOM_WALL_H + 0.01f, (ROOM_Z0 + ROOM_Z1) / 2,
            (ROOM2_X1 - ROOM_X1) + 2 * T + 0.2f, 0.3f, (ROOM_Z1 - ROOM_Z0) + 2 * T + 0.2f, roof);   // roof

    // Boulders and stalagmites: a rocky den.
    rgb rk = C(0.40f, 0.39f, 0.38f), rk2 = C(0.28f, 0.28f, 0.29f);
    add_octahedron(34.8f, 0.8f, -3.5f, 1.0f, rk, rk2);   add_collider(34.8f, -3.5f, 0.9f);
    add_octahedron(34.6f, 0.6f,  3.6f, 0.8f, rk, rk2);   add_collider(34.6f,  3.6f, 0.7f);
    add_octahedron(28.0f, 0.5f, -4.0f, 0.6f, rk, rk2);   add_collider(28.0f, -4.0f, 0.55f);
    add_cone(30.5f, 0.0f, -4.2f, 0.4f, 1.6f, 6, rk2);
    add_cone(32.6f, 0.0f,  4.3f, 0.5f, 2.0f, 6, rk);
    add_cone(28.6f, 0.0f,  4.3f, 0.3f, 1.2f, 6, rk2);
}

// ---------------------------------------------------------- climbing tower ----
// Seven stone pillars: six in a ring that climb one step each, one in the middle (the chest).
// The steps get taller, so a low Athletics level cannot make the last jumps.
// Each step is taller than the last, so reaching the top takes real Athletics training (about 17 points).
static const float pz_tops[7] = { 0.55f, 1.20f, 1.98f, 2.90f, 3.98f, 5.23f, PZ_CHEST_TOP };

static void add_plat(float cx, float cz, float top, int idx) {
    rgb stone = C(0.50f, 0.49f, 0.52f), stone2 = C(0.42f, 0.41f, 0.46f);
    rgb moss  = (idx & 1) ? C(0.30f, 0.46f, 0.24f) : C(0.26f, 0.42f, 0.22f);
    add_box(cx, 0.0f, cz, 2 * PZ_HALF, top - 0.12f, 2 * PZ_HALF, (idx & 1) ? stone : stone2);
    add_box(cx, top - 0.12f, cz, 2 * PZ_HALF + 0.14f, 0.12f, 2 * PZ_HALF + 0.14f, moss);
    if (nplats < MAX_PLATS) plats[nplats++] = (plat_t){ cx - PZ_HALF - 0.07f, cz - PZ_HALF - 0.07f, cx + PZ_HALF + 0.07f, cz + PZ_HALF + 0.07f, top, 0.0f };
}

static void build_tower(void) {
    for (int i = 0; i < 6; i++) {
        float a = (PI_F / 2.0f) + (PI_F / 3.0f) * (float)i;
        add_plat(PZ_CX + cosf(a) * PZ_RING_R, PZ_CZ + sinf(a) * PZ_RING_R, pz_tops[i], i);
    }
    add_plat(PZ_CX, PZ_CZ, pz_tops[6], 6);
    // Rubble at the foot of the tower.
    rgb rk = C(0.40f, 0.39f, 0.38f), rk2 = C(0.30f, 0.30f, 0.32f);
    add_collider(CLOTH_CHEST_X, CLOTH_CHEST_Z, 0.85f);
    add_octahedron(PZ_CX - 5.5f, 0.5f, PZ_CZ + 4.5f, 0.7f, rk, rk2);  add_collider(PZ_CX - 5.5f, PZ_CZ + 4.5f, 0.6f);
    add_octahedron(PZ_CX + 5.2f, 0.4f, PZ_CZ + 5.0f, 0.55f, rk, rk2); add_collider(PZ_CX + 5.2f, PZ_CZ + 5.0f, 0.5f);
    add_cone(PZ_CX - 4.8f, 0.0f, PZ_CZ - 4.5f, 0.35f, 1.4f, 6, rk2);
    add_cone(PZ_CX + 5.0f, 0.0f, PZ_CZ - 4.2f, 0.45f, 1.8f, 6, rk);
}

// ---------------------------------------------------------- spiral tower ----
// A square brick tower with a square spiral staircase round a solid core. The stairs climb two turns to the summit.
#define TW_CX     46.0f
#define TW_CZ    -40.0f
#define TW_STEPS  64
#define TW_RISE    0.2f
#define TW_TOP    (TW_STEPS * TW_RISE + TW_RISE)    // the core's top: one step above the last stair
static void build_spiral_tower(void) {
    rgb brk = C(0.52f, 0.47f, 0.44f), brk2 = C(0.45f, 0.41f, 0.40f);
    rgb sa = C(0.50f, 0.49f, 0.52f), sb = C(0.42f, 0.41f, 0.46f);
    const float I = 4.4f, L = 2.4f, D = 0.85f, WT = 0.5f, WH = TW_TOP + 1.6f;
    add_quad(V(TW_CX - I, 0.05f, TW_CZ - I), V(TW_CX - I, 0.05f, TW_CZ + I), V(TW_CX + I, 0.05f, TW_CZ + I), V(TW_CX + I, 0.05f, TW_CZ - I), C(0.30f, 0.30f, 0.34f));
    // the solid core (its top is the summit)
    add_brick_box(TW_CX, 0.0f, TW_CZ, 2 * L, TW_TOP, 2 * L, brk2);
    if (nplats < MAX_PLATS) plats[nplats++] = (plat_t){ TW_CX - L, TW_CZ - L, TW_CX + L, TW_CZ + L, TW_TOP, 0.0f };
    // outer walls, with a doorway at the foot of the stairs (south-west corner)
    add_wall_block(TW_CX - I - WT, TW_CZ - I - WT, TW_CX + I + WT, TW_CZ - I, WH, brk);                 // north
    add_wall_block(TW_CX + I, TW_CZ - I, TW_CX + I + WT, TW_CZ + I, WH, brk);                           // east
    add_wall_block(TW_CX - I - WT, TW_CZ - I, TW_CX - I, TW_CZ + I, WH, brk);                           // west
    add_wall_block(TW_CX - I - WT, TW_CZ + I, TW_CX - I, TW_CZ + I + WT, WH, brk);                      // south, left of the door
    add_wall_block(TW_CX - L, TW_CZ + I, TW_CX + I + WT, TW_CZ + I + WT, WH, brk);                      // south, right of the door
    add_brick_box(TW_CX - (I + L) / 2, 3.2f, TW_CZ + I + WT / 2, I - L, WH - 3.2f, WT, brk2);         // over the door
    // the stairs
    for (int k = 0; k < TW_STEPS; k++) {
        int r = (k / 8) & 3, i = k % 8;
        float x0, x1, z0, z1;
        if (r == 0)      { x0 = TW_CX - I + i * D; x1 = x0 + D; z0 = TW_CZ + L; z1 = TW_CZ + I; }
        else if (r == 1) { z1 = TW_CZ + I - i * D; z0 = z1 - D; x0 = TW_CX + L; x1 = TW_CX + I; }
        else if (r == 2) { x1 = TW_CX + I - i * D; x0 = x1 - D; z0 = TW_CZ - I; z1 = TW_CZ - L; }
        else             { z0 = TW_CZ - I + i * D; z1 = z0 + D; x0 = TW_CX - I; x1 = TW_CX - L; }
        float top = (float)(k + 1) * TW_RISE;
        add_box((x0 + x1) / 2, top - 0.3f, (z0 + z1) / 2, x1 - x0, 0.3f, z1 - z0, (k & 1) ? sa : sb);
        if (nplats < MAX_PLATS) plats[nplats++] = (plat_t){ x0 - 0.03f, z0 - 0.03f, x1 + 0.03f, z1 + 0.03f, top, top - 0.3f };
    }
}

// ------------------------------------------------------------- labyrinth ----
static unsigned mz_rng = 0x2545F491u;
static unsigned mz_rand(void) { mz_rng ^= mz_rng << 13; mz_rng ^= mz_rng >> 17; mz_rng ^= mz_rng << 5; return mz_rng; }

// Carve a maze with a depth-first walk from the door cell, then knock out a few extra walls for loops.
static void maze_generate(void) {
    int seen[MZ_ROWS][MZ_COLS];
    memset(seen, 0, sizeof(seen));
    memset(maze_open, 0, sizeof(maze_open));
    int stack[MZ_ROWS * MZ_COLS][2], sp = 0;
    stack[sp][0] = 0; stack[sp][1] = MZ_DOOR_ROW; sp++;
    seen[MZ_DOOR_ROW][0] = 1;
    while (sp > 0) {
        int c = stack[sp - 1][0], r = stack[sp - 1][1];
        int opts[4], n = 0;
        for (int k = 0; k < 4; k++) {
            int nc = c + mz_dc[k], nr = r + mz_dr[k];
            if (nc >= 0 && nc < MZ_COLS && nr >= 0 && nr < MZ_ROWS && !seen[nr][nc]) opts[n++] = k;
        }
        if (n == 0) { sp--; continue; }
        int k = opts[mz_rand() % (unsigned)n];
        int nc = c + mz_dc[k], nr = r + mz_dr[k];
        maze_open[r][c] |= (unsigned char)(1 << k);
        maze_open[nr][nc] |= (unsigned char)(1 << (k ^ 1));
        seen[nr][nc] = 1;
        stack[sp][0] = nc; stack[sp][1] = nr; sp++;
    }
    for (int i = 0; i < 9; i++) {   // loops: a perfect maze has exactly one route, which is dull
        int c = (int)(mz_rand() % MZ_COLS), r = (int)(mz_rand() % MZ_ROWS), k = (int)(mz_rand() % 4);
        int nc = c + mz_dc[k], nr = r + mz_dr[k];
        if (nc < 0 || nc >= MZ_COLS || nr < 0 || nr >= MZ_ROWS) continue;
        maze_open[r][c] |= (unsigned char)(1 << k);
        maze_open[nr][nc] |= (unsigned char)(1 << (k ^ 1));
    }
}

static void build_maze(void) {
    rgb stone = C(0.36f, 0.38f, 0.37f), stone2 = C(0.31f, 0.34f, 0.32f), roof = C(0.20f, 0.21f, 0.22f);
    const float T = 0.20f;   // half thickness of the outer wall
    const float I = 0.15f;   // half thickness of the inner walls
    maze_generate();

    for (int r = 0; r < MZ_ROWS; r++) {          // mossy flagstones, four per cell
        for (int c = 0; c < MZ_COLS; c++) {
            for (int q = 0; q < 4; q++) {
                float x0 = MZ_X0 + c * MZ_CELL + (q & 1) * (MZ_CELL / 2), z0 = MZ_Z0 + r * MZ_CELL + (q >> 1) * (MZ_CELL / 2), h = MZ_CELL / 2;
                rgb f = (((c + r + (q & 1) + (q >> 1)) & 1) ? C(0.20f, 0.23f, 0.21f) : C(0.16f, 0.19f, 0.17f));
                add_quad(V(x0, 0.03f, z0), V(x0, 0.03f, z0 + h), V(x0 + h, 0.03f, z0 + h), V(x0 + h, 0.03f, z0), f);
            }
        }
    }

    // Outer walls (the west one has the doorway).
    add_wall_block(MZ_X0 - T, MZ_Z0 - T, MZ_X1 + T, MZ_Z0 + T, MZ_WALL_H, stone);    // north
    add_wall_block(MZ_X0 - T, MZ_Z1 - T, MZ_X1 + T, MZ_Z1 + T, MZ_WALL_H, stone);    // south
    add_wall_block(MZ_X1 - T, MZ_Z0 + T, MZ_X1 + T, MZ_PZ - DOOR_HALF, MZ_WALL_H, stone);    // east, above the cave door
    add_wall_block(MZ_X1 - T, MZ_PZ + DOOR_HALF, MZ_X1 + T, MZ_Z1 - T, MZ_WALL_H, stone);    // east, below it
    add_brick_box(MZ_X1, 2.8f, MZ_PZ, 2 * T, MZ_WALL_H - 2.8f, 2 * DOOR_HALF, stone);       // lintel
    add_wall_collider(MZ_X1 - 0.2f, MZ_PZ - DOOR_HALF, MZ_X1 + 0.2f, MZ_PZ + DOOR_HALF);    // the shut door
    add_box(MZ_X1 - 0.12f, 0.0f, MZ_PZ - DOOR_HALF - 0.14f, 0.30f, 2.8f, 0.28f, C(0.30f, 0.20f, 0.12f));   // dark timber frame
    add_box(MZ_X1 - 0.12f, 0.0f, MZ_PZ + DOOR_HALF + 0.14f, 0.30f, 2.8f, 0.28f, C(0.30f, 0.20f, 0.12f));
    add_wall_block(MZ_X0 - T, MZ_Z0 + T, MZ_X0 + T, MZ_DOOR_Z - DOOR_HALF, MZ_WALL_H, stone2);   // west, above the door
    add_wall_block(MZ_X0 - T, MZ_DOOR_Z + DOOR_HALF, MZ_X0 + T, MZ_Z1 - T, MZ_WALL_H, stone2);   // west, below the door
    add_brick_box(MZ_X0, 2.8f, MZ_DOOR_Z, 2 * T, MZ_WALL_H - 2.8f, 2 * DOOR_HALF, stone);             // lintel
    doors[2].wall = add_wall_collider(MZ_X0 - 0.2f, MZ_DOOR_Z - DOOR_HALF, MZ_X0 + 0.2f, MZ_DOOR_Z + DOOR_HALF);
    add_brick_box((MZ_X0 + MZ_X1) / 2, MZ_WALL_H, (MZ_Z0 + MZ_Z1) / 2,
            (MZ_X1 - MZ_X0) + 2 * T + 0.2f, 0.3f, (MZ_Z1 - MZ_Z0) + 2 * T + 0.2f, roof);    // roof

    // Inner walls: every cell edge that was not carved open.
    for (int r = 0; r < MZ_ROWS; r++) {
        for (int c = 0; c < MZ_COLS; c++) {
            float x0 = MZ_X0 + c * MZ_CELL, z0 = MZ_Z0 + r * MZ_CELL;
            rgb col = ((c + r) & 1) ? stone : stone2;
            if (c < MZ_COLS - 1 && !(maze_open[r][c] & 1))
                add_wall_block(x0 + MZ_CELL - I, z0 - I, x0 + MZ_CELL + I, z0 + MZ_CELL + I, MZ_WALL_H, col);
            if (r < MZ_ROWS - 1 && !(maze_open[r][c] & 4))
                add_wall_block(x0 - I, z0 + MZ_CELL - I, x0 + MZ_CELL + I, z0 + MZ_CELL + I, MZ_WALL_H, col);
        }
    }
}

static void build_gloam(void);

static void build_scene(void) {
    cur = &world_mesh;
    build_ground();

    // Crate stack
    add_box(6.0f, 0.0f, -6.0f, 2.0f, 2.0f, 2.0f, C(0.62f, 0.42f, 0.20f));
    add_box(6.3f, 2.0f, -6.0f, 1.2f, 1.2f, 1.2f, C(0.70f, 0.48f, 0.24f));
    add_collider(6.0f, -6.0f, 1.45f);

    // Sand pyramid
    add_pyramid(PYR_X, 0.0f, PYR_Z, 6.0f, 5.0f, C(0.80f, 0.70f, 0.42f));
    add_collider(PYR_X, PYR_Z, 3.0f);

    // Trees
    add_tree(-5.0f, 4.0f);
    add_tree(4.0f, 9.0f);
    add_dead_tree(-13.0f, 6.0f, 3.4f);
    add_dead_tree(-16.0f, -3.0f, 2.9f);
    add_dead_tree(9.0f, -14.0f, 3.6f);
    add_tree(11.0f, 3.0f);
    add_dead_tree(15.0f, -13.0f, 3.1f);

    // Ring of stone pillars around the start point
    for (int i = 0; i < 8; i++) {
        float a = 2 * PI_F * i / 8;
        float x = cosf(a) * 11.0f, z = sinf(a) * 11.0f;
        add_cylinder(x, 0.0f, z, 0.5f, 3.5f, 8, C(0.58f, 0.58f, 0.62f));
        add_box(x, 3.5f, z, 1.3f, 0.35f, 1.3f, C(0.48f, 0.48f, 0.52f));
        add_collider(x, z, 0.75f);
    }

    // Pedestal (the beacon crystal floats above it and is drawn separately)
    add_box(0.0f, 0.0f, -5.0f, 1.4f, 0.8f, 1.4f, C(0.50f, 0.50f, 0.54f));
    add_collider(0.0f, -5.0f, 1.1f);

    // The smithy: three brick walls and a wooden roof, open to the south, right beside the rest point.
    {
        rgb br = C(0.66f, 0.52f, 0.44f), wood = C(0.36f, 0.24f, 0.13f), wood2 = C(0.28f, 0.19f, 0.10f);
        add_wall_block(-6.4f, -10.4f, -1.6f, -10.1f, 2.9f, br);
        add_wall_block(-6.4f, -10.1f, -6.1f, -7.0f, 2.9f, br);
        add_wall_block(-1.9f, -10.1f, -1.6f, -7.0f, 2.9f, br);
        add_box(-4.0f, 2.9f, -8.7f, 5.4f, 0.25f, 4.4f, wood);
        add_box(-4.0f, 3.15f, -8.7f, 4.6f, 0.15f, 3.6f, wood2);
        add_brick_box(FORGE_X, 3.0f, FORGE_Z, 0.7f, 1.5f, 0.7f, br);                   // chimney
        add_box(-4.0f, 0.0f, ANVIL_Z, 0.50f, 0.62f, 0.50f, wood2);                       // anvil block
        add_box(-4.0f, 0.62f, ANVIL_Z, 0.85f, 0.24f, 0.30f, C(0.34f, 0.35f, 0.40f));     // anvil body
        add_box(-4.58f, 0.70f, ANVIL_Z, 0.34f, 0.12f, 0.20f, C(0.30f, 0.31f, 0.36f));    // horn
        add_collider(-4.0f, ANVIL_Z, 0.5f);
        add_box(FORGE_X, 0.0f, FORGE_Z, 0.90f, 0.90f, 0.90f, C(0.40f, 0.38f, 0.38f));    // forge
        add_box(FORGE_X, 0.90f, FORGE_Z, 0.62f, 0.04f, 0.62f, C(1.00f, 0.50f, 0.12f));   // its glowing bed
        add_collider(FORGE_X, FORGE_Z, 0.75f);
        add_box(-5.6f, 0.0f, -9.5f, 0.55f, 0.55f, 0.55f, wood);                          // a crate
        add_box(-5.7f, 0.55f, -7.6f, 0.08f, 0.9f, 0.08f, wood2);                          // tool rack post
        add_collider(-5.6f, -9.5f, 0.45f);
    }

    build_room();
    build_tower();
    build_spiral_tower();
    build_maze();

    // The big open plane: scattered trees, boulders and broken columns, kept clear of the buildings.
    {
        unsigned rs = 0x9E3779B1u;
        #define SC_RND() (rs ^= rs << 13, rs ^= rs >> 17, rs ^= rs << 5, (float)(rs & 0xFFFFFF) / 16777216.0f)
        rgb rk = C(0.40f, 0.39f, 0.38f), rk2 = C(0.30f, 0.30f, 0.33f), col = C(0.58f, 0.58f, 0.62f), col2 = C(0.48f, 0.48f, 0.52f);
        int placed = 0, tries = 0;
        while (placed < 90 && tries < 2000) {
            tries++;
            float x = -66.0f + SC_RND() * 140.0f, z = -66.0f + SC_RND() * 140.0f;
            if (x > 6.0f && x < 42.0f && z > -12.0f && z < 42.0f) continue;                    // rooms + labyrinth
            if (x * x + z * z < 17.0f * 17.0f) continue;                                         // the start ring
            if ((x - PZ_CX) * (x - PZ_CX) + (z - PZ_CZ) * (z - PZ_CZ) < 11.0f * 11.0f) continue;   // the tower
            if ((x - PYR_X) * (x - PYR_X) + (z - PYR_Z) * (z - PYR_Z) < 8.0f * 8.0f) continue;     // the pyramid
            if ((x + 3.0f) * (x + 3.0f) + (z - 8.0f) * (z - 8.0f) < 9.0f) continue;               // supplies near the start
            if ((x - 7.5f) * (x - 7.5f) + (z - 14.0f) * (z - 14.0f) < 9.0f) continue;
            if (x > -10.0f && x < 1.0f && z > -14.0f && z < -4.0f) continue;
            if ((x - TW_CX) * (x - TW_CX) + (z - TW_CZ) * (z - TW_CZ) < 10.0f * 10.0f) continue;   // the spiral tower                       // the smithy
            float kind = SC_RND();
            if (kind < 0.38f) {
                add_tree(x, z);
            } else if (kind < 0.62f) {
                add_dead_tree(x, z, 2.6f + SC_RND() * 1.2f);
            } else if (kind < 0.88f) {
                float r = 0.5f + SC_RND() * 0.9f;
                add_octahedron(x, r * 0.7f, z, r, rk, rk2);
                add_collider(x, z, r * 0.9f);
            } else {
                float h = 1.4f + SC_RND() * 2.2f;
                add_cylinder(x, 0.0f, z, 0.5f, h, 8, col);
                add_box(x + 0.3f, h, z, 0.9f, 0.3f, 0.9f, col2);
                add_collider(x, z, 0.7f);
            }
            placed++;
        }
        #undef SC_RND
    }
}

// ------------------------------------------------- weapons & right hand ----
// Weapon meshes: grip at the origin, blade/shaft along +Y, flat faces toward +Z.

static void build_sword(void) {
    cur = &sword_mesh;
    rgb leather = C(0.35f, 0.22f, 0.12f);
    rgb steel = C(0.70f, 0.76f, 0.80f), steel2 = C(0.52f, 0.60f, 0.66f);
    rgb guard = C(0.42f, 0.50f, 0.58f);

    add_prism(V(0, -0.20f, 0), V(0, 0.0f, 0), 0.022f, 6, leather);   // grip
    add_box(0, -0.25f, 0, 0.07f, 0.05f, 0.07f, guard);               // pommel
    add_box(0, 0.0f, 0, 0.20f, 0.035f, 0.05f, guard);                // cross-guard
    add_box(-0.14f, 0.0f, 0, 0.07f, 0.09f, 0.04f, guard);            // guard wings
    add_box( 0.14f, 0.0f, 0, 0.07f, 0.09f, 0.04f, guard);

    // Diamond cross-section blade with a pointed tip.
    float y0 = 0.035f, ysh = 0.72f, y1 = 0.88f, hw = 0.06f, ht = 0.016f;
    vec3 bl = V(-hw, y0, 0), br = V(hw, y0, 0), bf = V(0, y0, ht), bb = V(0, y0, -ht);
    vec3 sl = V(-hw, ysh, 0), sr = V(hw, ysh, 0), sf = V(0, ysh, ht), sb = V(0, ysh, -ht);
    vec3 tip = V(0, y1, 0);
    add_quad(bl, bf, sf, sl, steel);
    add_quad(bf, br, sr, sf, steel2);
    add_quad(bb, bl, sl, sb, steel2);
    add_quad(br, bb, sb, sr, steel);
    add_tri(sl, sf, tip, steel);
    add_tri(sf, sr, tip, steel2);
    add_tri(sb, sl, tip, steel2);
    add_tri(sr, sb, tip, steel);
}

static void build_mace(void) {
    cur = &mace_mesh;
    rgb wood = C(0.42f, 0.28f, 0.15f), iron = C(0.45f, 0.47f, 0.52f), iron2 = C(0.58f, 0.60f, 0.66f);

    add_prism(V(0, -0.22f, 0), V(0, 0.55f, 0), 0.025f, 6, wood);     // shaft
    add_box(0, -0.27f, 0, 0.07f, 0.05f, 0.07f, iron);                // pommel
    add_cylinder(0, 0.48f, 0, 0.085f, 0.20f, 8, iron);               // head
    add_cone(0, 0.68f, 0, 0.085f, 0.12f, 8, iron2);                  // top spike
    add_box(-0.115f, 0.54f, 0, 0.06f, 0.07f, 0.06f, iron2);          // studs
    add_box( 0.115f, 0.54f, 0, 0.06f, 0.07f, 0.06f, iron2);
    add_box(0, 0.54f, -0.115f, 0.06f, 0.07f, 0.06f, iron2);
    add_box(0, 0.54f,  0.115f, 0.06f, 0.07f, 0.06f, iron2);
}

// Battle axe: a long haft with a broad single-bladed head (grip at the origin, head up the +Y end, blade to +X).
static void build_axe(void) {
    cur = &axe_mesh;
    rgb wood = C(0.40f, 0.27f, 0.14f), iron = C(0.42f, 0.44f, 0.49f), steel = C(0.74f, 0.77f, 0.82f), edge = C(0.92f, 0.94f, 0.97f);
    add_prism(V(0, -0.25f, 0), V(0, 0.62f, 0), 0.026f, 6, wood);     // haft
    add_box(0, -0.30f, 0, 0.07f, 0.05f, 0.07f, iron);                // butt cap
    add_box(0, 0.44f, 0, 0.09f, 0.26f, 0.07f, iron);                 // socket
    add_box(0.115f, 0.41f, 0, 0.17f, 0.32f, 0.03f, steel);           // blade body
    add_box(0.225f, 0.37f, 0, 0.05f, 0.40f, 0.025f, edge);           // the cutting edge, flared
    add_box(-0.07f, 0.48f, 0, 0.07f, 0.12f, 0.05f, iron);            // poll
}

// Spear: long shaft with a leaf-shaped head (grip at the origin, tip along +Y).
static void build_spear(void) {
    cur = &spear_mesh;
    rgb wood = C(0.45f, 0.30f, 0.16f), iron = C(0.50f, 0.52f, 0.58f);
    rgb steel = C(0.86f, 0.89f, 0.93f), steel2 = C(0.66f, 0.72f, 0.78f), red = C(0.65f, 0.15f, 0.12f);

    add_prism(V(0, -0.35f, 0), V(0, 1.30f, 0), 0.022f, 6, wood);     // shaft
    add_box(0, -0.40f, 0, 0.055f, 0.06f, 0.055f, iron);              // butt cap
    add_prism(V(0, 1.08f, 0), V(0, 1.18f, 0), 0.034f, 6, red);       // cloth band
    add_prism(V(0, 1.26f, 0), V(0, 1.38f, 0), 0.034f, 6, iron);      // socket
    vec3 pb = V(0, 1.38f, 0), tip = V(0, 2.00f, 0);
    vec3 L = V(-0.11f, 1.58f, 0), R = V(0.11f, 1.58f, 0), F = V(0, 1.58f, 0.03f), B = V(0, 1.58f, -0.03f);
    add_tri(pb, F, L, steel);  add_tri(pb, R, F, steel2);
    add_tri(pb, B, R, steel);  add_tri(pb, L, B, steel2);
    add_tri(L, F, tip, steel); add_tri(F, R, tip, steel2);
    add_tri(R, B, tip, steel); add_tri(B, L, tip, steel2);
}

// The tower's treasure: a long dark blade with a glowing ridge and a gold crescent guard.
static void build_gloam(void) {
    cur = &gloam_mesh;
    rgb leather = C(0.16f, 0.11f, 0.22f), gold = C(0.90f, 0.74f, 0.30f), gold2 = C(0.66f, 0.50f, 0.18f);
    rgb blade = C(0.46f, 0.50f, 0.76f), blade2 = C(0.30f, 0.34f, 0.60f), glow = C(0.60f, 0.98f, 1.0f);

    add_prism(V(0, -0.22f, 0), V(0, 0.0f, 0), 0.024f, 6, leather);               // grip
    add_octahedron(0, -0.29f, 0, 0.055f, C(0.50f, 0.98f, 1.0f), C(0.20f, 0.60f, 0.85f));   // pommel gem
    add_box(0, -0.01f, 0, 0.32f, 0.045f, 0.065f, gold);                           // cross-guard
    add_box(-0.17f, 0.03f, 0, 0.07f, 0.11f, 0.05f, gold2);                        // upswept tips
    add_box( 0.17f, 0.03f, 0, 0.07f, 0.11f, 0.05f, gold2);
    add_box(-0.22f, 0.10f, 0, 0.05f, 0.08f, 0.04f, gold);
    add_box( 0.22f, 0.10f, 0, 0.05f, 0.08f, 0.04f, gold);

    float y0 = 0.04f, ysh = 1.0f, y1 = 1.22f, hw = 0.075f, ht = 0.02f;
    vec3 bl = V(-hw, y0, 0), br = V(hw, y0, 0), bf = V(0, y0, ht), bb = V(0, y0, -ht);
    vec3 sl = V(-hw, ysh, 0), sr = V(hw, ysh, 0), sf = V(0, ysh, ht), sb = V(0, ysh, -ht);
    vec3 tip = V(0, y1, 0);
    add_quad(bl, bf, sf, sl, blade);
    add_quad(bf, br, sr, sf, blade2);
    add_quad(bb, bl, sl, sb, blade2);
    add_quad(br, bb, sb, sr, blade);
    add_tri(sl, sf, tip, blade);
    add_tri(sf, sr, tip, blade2);
    add_tri(sb, sl, tip, blade2);
    add_tri(sr, sb, tip, blade);
    add_box(0, 0.10f, 0, 0.024f, 0.84f, 2 * ht + 0.01f, glow);                    // glowing ridge, visible on both faces
}

// Treasure chest: a body, and a lid that is drawn hinged open once it has been looted.
static void build_chest(void) {
    rgb wood = C(0.42f, 0.26f, 0.13f), wood2 = C(0.34f, 0.20f, 0.10f), gold = C(0.90f, 0.74f, 0.30f);
    cur = &chest_mesh;
    add_box(0, 0, 0, 1.0f, 0.55f, 0.70f, wood);
    add_box(-0.40f, 0, 0, 0.08f, 0.56f, 0.72f, gold);
    add_box( 0.40f, 0, 0, 0.08f, 0.56f, 0.72f, gold);
    add_box(0, 0.38f, 0.35f, 0.14f, 0.14f, 0.04f, gold);
    cur = &chestlid_mesh;   // origin on the back hinge, lid extends toward +Z
    add_box(0, 0.0f, 0.35f, 1.0f, 0.20f, 0.70f, wood2);
    add_box(0, 0.20f, 0.35f, 0.88f, 0.08f, 0.58f, wood);
    add_box(-0.40f, 0.0f, 0.35f, 0.08f, 0.22f, 0.72f, gold);
    add_box( 0.40f, 0.0f, 0.35f, 0.08f, 0.22f, 0.72f, gold);
}

// Cave worm: a chain of pale segments lying along +Z (tail at the origin, head at the far end).
static void build_worm(void) {
    cur = &worm_mesh;
    rgb a = C(0.80f, 0.64f, 0.68f), b = C(0.66f, 0.48f, 0.56f);
    rgb dark = C(0.20f, 0.05f, 0.09f), tooth = C(0.96f, 0.94f, 0.86f), eye = C(0.98f, 0.86f, 0.20f);
    static const float zs[6] = { 0.16f, 0.44f, 0.72f, 1.00f, 1.27f, 1.52f };
    static const float rs[6] = { 0.15f, 0.21f, 0.26f, 0.29f, 0.30f, 0.30f };
    for (int i = 0; i < 6; i++)
        add_octahedron(0.0f, rs[i], zs[i], rs[i] * 1.05f, (i & 1) ? a : b, (i & 1) ? b : a);
    add_octahedron(0.0f, 0.36f, 1.80f, 0.37f, a, b);                  // head
    add_box(0.0f, 0.14f, 2.06f, 0.34f, 0.26f, 0.12f, dark);           // open maw
    add_box(-0.11f, 0.30f, 2.10f, 0.05f, 0.10f, 0.04f, tooth);        // fangs
    add_box( 0.11f, 0.30f, 2.10f, 0.05f, 0.10f, 0.04f, tooth);
    add_box(-0.11f, 0.10f, 2.10f, 0.05f, 0.08f, 0.04f, tooth);
    add_box( 0.11f, 0.10f, 2.10f, 0.05f, 0.08f, 0.04f, tooth);
    add_box(-0.19f, 0.52f, 1.95f, 0.07f, 0.07f, 0.05f, eye);          // eyes
    add_box( 0.19f, 0.52f, 1.95f, 0.07f, 0.07f, 0.05f, eye);
}

// Risen soldier: bone body (feet at the origin, facing +Z). The sword arm is a separate mesh so it can be raised.
static void build_undead(void) {
    cur = &undead_mesh;
    rgb bone = C(0.86f, 0.82f, 0.70f), bone2 = C(0.66f, 0.62f, 0.50f), rag = C(0.30f, 0.12f, 0.12f);
    rgb rust = C(0.50f, 0.34f, 0.24f), eye = C(1.0f, 0.30f, 0.10f);
    add_box(-0.14f, 0.0f, 0.0f, 0.10f, 0.80f, 0.10f, bone);            // legs
    add_box( 0.14f, 0.0f, 0.0f, 0.10f, 0.80f, 0.10f, bone);
    add_box(-0.14f, 0.36f, 0.02f, 0.14f, 0.10f, 0.14f, bone2);         // knees
    add_box( 0.14f, 0.36f, 0.02f, 0.14f, 0.10f, 0.14f, bone2);
    add_box(-0.14f, 0.0f, 0.07f, 0.13f, 0.06f, 0.24f, bone2);          // feet
    add_box( 0.14f, 0.0f, 0.07f, 0.13f, 0.06f, 0.24f, bone2);
    add_box(0.0f, 0.78f, 0.0f, 0.46f, 0.16f, 0.24f, bone2);            // pelvis
    add_box(0.0f, 0.40f, 0.14f, 0.38f, 0.42f, 0.03f, rag);             // tattered loincloth
    add_box(0.0f, 0.80f, -0.14f, 0.42f, 0.62f, 0.03f, rag);            // ragged cloak
    add_box(0.0f, 0.90f, -0.02f, 0.07f, 0.46f, 0.07f, bone);           // spine
    for (int i = 0; i < 3; i++) add_box(0.0f, 1.02f + 0.12f * (float)i, 0.0f, 0.42f - 0.03f * (float)i, 0.05f, 0.24f, bone);   // ribs
    add_box(0.0f, 1.38f, 0.0f, 0.64f, 0.09f, 0.20f, bone2);            // shoulders
    add_box(-0.34f, 1.33f, 0.0f, 0.20f, 0.13f, 0.28f, rust);           // rusty pauldron
    add_box(0.0f, 1.46f, 0.0f, 0.06f, 0.10f, 0.06f, bone);             // neck
    add_box(0.0f, 1.54f, 0.01f, 0.27f, 0.27f, 0.27f, bone);            // skull
    add_box(0.0f, 1.49f, 0.08f, 0.20f, 0.07f, 0.18f, bone2);           // jaw
    add_box(-0.07f, 1.64f, 0.14f, 0.06f, 0.06f, 0.03f, eye);           // glowing eyes
    add_box( 0.07f, 1.64f, 0.14f, 0.06f, 0.06f, 0.03f, eye);
    add_box(-0.36f, 0.98f, 0.0f, 0.07f, 0.42f, 0.07f, bone);           // left arm (hangs)
    add_box(-0.37f, 0.62f, 0.02f, 0.06f, 0.36f, 0.06f, bone);
    add_box(-0.37f, 0.54f, 0.02f, 0.09f, 0.09f, 0.09f, bone2);

    cur = &undeadarm_mesh;   // origin at the shoulder; hangs down along -Y with a rusty sword in the hand
    rgb steel = C(0.62f, 0.56f, 0.50f), steel2 = C(0.48f, 0.42f, 0.38f);
    add_box(0.0f, -0.42f, 0.0f, 0.07f, 0.42f, 0.07f, bone);
    add_box(0.0f, -0.84f, 0.02f, 0.06f, 0.40f, 0.06f, bone);
    add_box(0.0f, -0.94f, 0.02f, 0.10f, 0.10f, 0.10f, bone2);          // hand
    add_box(0.0f, -1.02f, 0.03f, 0.24f, 0.05f, 0.07f, rust);           // cross-guard
    add_box(0.0f, -1.80f, 0.03f, 0.10f, 0.78f, 0.025f, steel);         // blade
    add_box(0.0f, -1.95f, 0.03f, 0.06f, 0.16f, 0.022f, steel2);        // tip
}

// Your left hand, raised palm-out to cast (view model; origin at the palm, fingers along +Y).
static void build_lhand(void) {
    cur = &lhand_mesh;
    rgb skin = C(0.80f, 0.58f, 0.44f), skin2 = C(0.70f, 0.50f, 0.38f), cloth = C(0.28f, 0.26f, 0.30f);
    add_box(0.0f, 0.0f, 0.0f, 0.16f, 0.15f, 0.045f, skin2);                // palm
    static const float fx[4] = { -0.055f, -0.018f, 0.019f, 0.056f };
    static const float fl[4] = { 0.09f, 0.115f, 0.105f, 0.08f };
    for (int i = 0; i < 4; i++) add_box(fx[i], 0.15f, 0.0f, 0.032f, fl[i], 0.034f, skin);   // fingers
    add_box(0.105f, 0.03f, 0.0f, 0.05f, 0.09f, 0.034f, skin);              // thumb
    add_box(0.0f, -0.95f, 0.0f, 0.13f, 0.95f, 0.10f, skin2);               // forearm
    add_box(0.0f, -0.20f, 0.0f, 0.16f, 0.12f, 0.12f, cloth);               // cuff
}

static void build_herb(void) {
    cur = &herb_mesh;
    rgb g1 = C(0.28f, 0.66f, 0.24f), g2 = C(0.17f, 0.46f, 0.16f), stem = C(0.36f, 0.52f, 0.20f), fl = C(0.95f, 0.86f, 0.30f);
    add_prism(V(0, -0.22f, 0), V(0, 0.24f, 0), 0.025f, 5, stem);
    add_octahedron( 0.13f, 0.08f,  0.00f, 0.10f, g1, g2);
    add_octahedron(-0.13f, 0.00f,  0.05f, 0.10f, g2, g1);
    add_octahedron( 0.02f, 0.26f,  0.11f, 0.09f, g1, g2);
    add_octahedron(-0.06f, 0.16f, -0.12f, 0.09f, g2, g1);
    add_octahedron( 0.09f, -0.06f, -0.12f, 0.08f, g1, g2);
    add_box(0, 0.30f, 0, 0.08f, 0.06f, 0.08f, fl);
}

static void build_potion(void) {
    cur = &potion_mesh;
    rgb glass = C(0.80f, 0.10f, 0.16f), glass2 = C(0.62f, 0.07f, 0.12f), neck = C(0.72f, 0.80f, 0.86f), cork = C(0.60f, 0.42f, 0.24f);
    add_cylinder(0, -0.24f, 0, 0.14f, 0.28f, 8, glass);
    add_cylinder(0, 0.04f, 0, 0.09f, 0.08f, 8, glass2);
    add_cylinder(0, 0.12f, 0, 0.05f, 0.14f, 6, neck);
    add_box(0, 0.25f, 0, 0.09f, 0.07f, 0.09f, cork);
    add_box(-0.05f, -0.12f, 0.14f, 0.04f, 0.14f, 0.02f, C(1.0f, 0.75f, 0.75f));   // a glint
}

static void build_bomb(void) {
    cur = &bomb_mesh;
    rgb iron = C(0.16f, 0.16f, 0.19f), iron2 = C(0.26f, 0.26f, 0.30f), rope = C(0.55f, 0.42f, 0.24f), spark = C(1.0f, 0.62f, 0.12f);
    add_octahedron(0, 0, 0, 0.19f, iron, iron2);
    add_box(0, 0.22f, 0, 0.10f, 0.06f, 0.10f, iron2);
    add_prism(V(0, 0.24f, 0), V(0.05f, 0.40f, 0.02f), 0.012f, 4, rope);
    add_box(0.05f, 0.42f, 0.02f, 0.05f, 0.05f, 0.05f, spark);
}

// Torch: the handle's grip is at the origin; the flame is drawn separately so it can flicker.
static void build_torch(void) {
    cur = &torch_mesh;
    rgb wood = C(0.40f, 0.26f, 0.14f), char_ = C(0.20f, 0.13f, 0.08f), wrap = C(0.55f, 0.40f, 0.22f);
    add_prism(V(0, -0.34f, 0), V(0, 0.36f, 0), 0.036f, 6, wood);
    add_cylinder(0, 0.30f, 0, 0.075f, 0.16f, 6, char_);
    add_cylinder(0, 0.18f, 0, 0.05f, 0.03f, 6, wrap);
}

static void build_sparks(void) {
    cur = &spark_mesh;
    add_octahedron(0, 0, 0, 1.0f, C(1.0f, 0.97f, 0.70f), C(1.0f, 0.82f, 0.35f));
    cur = &ember_mesh;
    add_octahedron(0, 0, 0, 1.0f, C(1.0f, 0.55f, 0.12f), C(0.92f, 0.28f, 0.06f));
}

// Miner's pick: shaft with a double-pointed head across the top (grip at the origin).
static void build_pick(void) {
    cur = &pick_mesh;
    rgb wood = C(0.45f, 0.30f, 0.16f), iron = C(0.46f, 0.48f, 0.54f), iron2 = C(0.60f, 0.62f, 0.68f);
    add_prism(V(0, -0.22f, 0), V(0, 0.82f, 0), 0.026f, 6, wood);
    add_box(0, -0.26f, 0, 0.06f, 0.05f, 0.06f, iron);
    add_box(0, 0.78f, 0, 0.30f, 0.08f, 0.09f, iron);
    for (int k = 0; k < 2; k++) {
        float sg = k ? 1.0f : -1.0f;
        vec3 a = V(sg * 0.15f, 0.82f, 0.045f), b = V(sg * 0.15f, 0.74f, 0.045f), c = V(sg * 0.15f, 0.82f, -0.045f), d = V(sg * 0.15f, 0.74f, -0.045f);
        vec3 tip = V(sg * 0.58f, 0.69f, 0.0f);
        add_tri(a, b, tip, iron2);
        add_tri(c, d, tip, iron);
        add_tri(a, c, tip, iron2);
        add_tri(b, d, tip, iron);
    }
}

// Zombie: a slumped, greying corpse in a torn shirt (feet at the origin, facing +Z). The arms are a separate
// mesh so both can be raised for the slam.
static void build_zombie(void) {
    cur = &zombie_mesh;
    rgb skin = C(0.46f, 0.56f, 0.42f), skin2 = C(0.38f, 0.48f, 0.36f), shirt = C(0.34f, 0.30f, 0.25f);
    rgb pants = C(0.22f, 0.22f, 0.27f), blood = C(0.45f, 0.08f, 0.07f), flesh = C(0.58f, 0.28f, 0.28f), eye = C(0.88f, 0.88f, 0.62f);
    add_box(-0.14f, 0.0f, 0.0f, 0.16f, 0.82f, 0.18f, pants);
    add_box( 0.14f, 0.0f, 0.02f, 0.16f, 0.82f, 0.18f, pants);
    add_box(-0.14f, 0.0f, 0.07f, 0.16f, 0.07f, 0.28f, skin2);
    add_box( 0.14f, 0.0f, 0.09f, 0.16f, 0.07f, 0.28f, skin2);
    add_box(0.0f, 0.78f, 0.0f, 0.46f, 0.20f, 0.26f, pants);
    add_box(0.0f, 0.88f, 0.02f, 0.52f, 0.58f, 0.28f, shirt);            // torso, hunched forward
    add_box(0.0f, 0.96f, 0.15f, 0.22f, 0.20f, 0.02f, flesh);            // torn open: ribs and flesh
    add_box(-0.06f, 1.0f, 0.165f, 0.03f, 0.14f, 0.01f, C(0.86f, 0.82f, 0.70f));
    add_box( 0.06f, 1.0f, 0.165f, 0.03f, 0.14f, 0.01f, C(0.86f, 0.82f, 0.70f));
    add_box(0.14f, 0.86f, 0.15f, 0.20f, 0.30f, 0.02f, blood);           // stains
    add_box(-0.16f, 1.12f, -0.14f, 0.20f, 0.26f, 0.02f, blood);
    add_box(0.0f, 1.40f, 0.04f, 0.62f, 0.10f, 0.26f, shirt);            // shoulders
    add_box(0.02f, 1.48f, 0.06f, 0.10f, 0.10f, 0.10f, skin2);           // neck
    add_box(0.04f, 1.56f, 0.10f, 0.28f, 0.30f, 0.28f, skin);            // head, tilted forward
    add_box(0.04f, 1.50f, 0.20f, 0.20f, 0.06f, 0.10f, blood);           // gaping mouth
    add_box(-0.04f, 1.64f, 0.245f, 0.06f, 0.06f, 0.02f, eye);           // dead eyes
    add_box( 0.12f, 1.64f, 0.245f, 0.06f, 0.06f, 0.02f, eye);
    add_box(0.04f, 1.84f, 0.06f, 0.26f, 0.06f, 0.24f, C(0.14f, 0.12f, 0.10f));   // matted hair
    cur = &zombiearms_mesh;   // origin between the shoulders; both arms hang along -Y
    for (int k = 0; k < 2; k++) {
        float sg = k ? 1.0f : -1.0f;
        add_box(sg * 0.34f, -0.22f, 0.0f, 0.13f, 0.44f, 0.13f, shirt);
        add_box(sg * 0.34f, -0.64f, 0.0f, 0.11f, 0.42f, 0.11f, skin);
        add_box(sg * 0.34f, -0.90f, 0.02f, 0.12f, 0.10f, 0.13f, skin2);
        add_box(sg * 0.34f, -0.50f, 0.0f, 0.12f, 0.05f, 0.12f, blood);
    }
}

// The dying man in the cave (origin on the floor where he sits, facing +Z): slumped with his legs out in front.
static void build_dying(void) {
    cur = &dying_mesh;
    rgb cloth = C(0.28f, 0.26f, 0.22f), cloth2 = C(0.22f, 0.20f, 0.18f), skin = C(0.74f, 0.58f, 0.46f);
    rgb hood = C(0.34f, 0.28f, 0.20f), dark = C(0.10f, 0.08f, 0.08f), blood = C(0.46f, 0.06f, 0.06f);
    add_box(-0.13f, 0.0f, 0.42f, 0.18f, 0.18f, 0.78f, dark);            // legs out in front
    add_box( 0.13f, 0.0f, 0.40f, 0.18f, 0.18f, 0.78f, dark);
    add_box(0.0f, 0.0f, -0.02f, 0.58f, 0.22f, 0.40f, cloth2);           // hips on the floor
    add_box(0.02f, 0.18f, -0.08f, 0.54f, 0.62f, 0.34f, cloth);          // torso, leaning back on the wall
    add_box(0.0f, 0.36f, 0.10f, 0.34f, 0.32f, 0.02f, blood);            // the wound
    add_box(-0.34f, 0.30f, 0.14f, 0.13f, 0.14f, 0.50f, cloth);          // left arm in his lap
    add_box( 0.36f, 0.04f, 0.04f, 0.13f, 0.44f, 0.13f, cloth);          // right arm hanging
    add_box( 0.36f, 0.00f, 0.08f, 0.11f, 0.10f, 0.12f, skin);
    add_box(0.02f, 0.80f, -0.04f, 0.30f, 0.30f, 0.30f, skin);           // head lolling to one side
    add_box(-0.045f, 0.90f, 0.112f, 0.05f, 0.025f, 0.02f, dark);        // closed-ish eyes
    add_box( 0.085f, 0.90f, 0.112f, 0.05f, 0.025f, 0.02f, dark);
    add_box(0.02f, 1.08f, -0.06f, 0.40f, 0.12f, 0.38f, hood);
    add_box(0.02f, 0.82f, -0.18f, 0.40f, 0.34f, 0.16f, hood);
}

static void build_fire(void) {
    cur = &fire_mesh;
    add_octahedron(0, 0, 0, 0.50f, C(1.0f, 0.50f, 0.08f), C(1.0f, 0.78f, 0.20f));
    add_octahedron(0, 0, 0, 0.30f, C(1.0f, 0.95f, 0.55f), C(1.0f, 0.60f, 0.12f));
}

// Right hand + forearm, fingers wrapped around the grip, arm leaving the
// bottom-right corner of the screen.
static void build_hand(void) {
    cur = &hand_mesh;
    rgb skin = C(0.80f, 0.58f, 0.44f), skin2 = C(0.70f, 0.50f, 0.38f);

    add_box(0.035f, -0.155f, -0.005f, 0.11f, 0.14f, 0.05f, skin2);   // back of hand
    for (int k = 0; k < 4; k++)                                      // fingers
        add_box(0.01f, -0.15f + 0.034f * k, 0.035f, 0.095f, 0.03f, 0.045f, skin);
    add_box(-0.03f, -0.03f, 0.035f, 0.035f, 0.035f, 0.045f, skin);   // thumb
}

// Straw training dummy (origin at its base). Swing at it to test attacks.
static void build_dummy(void) {
    cur = &dummy_mesh;
    rgb wood = C(0.40f, 0.28f, 0.16f), straw = C(0.78f, 0.68f, 0.42f), straw2 = C(0.66f, 0.56f, 0.34f);
    add_cylinder(0, 0.0f, 0, 0.5f, 0.08f, 8, C(0.36f, 0.26f, 0.15f));   // base
    add_cylinder(0, 0.0f, 0, 0.12f, 1.2f, 6, wood);                      // post
    add_box(0, 0.88f, 0, 0.95f, 0.12f, 0.12f, wood);                     // arms
    add_box(0, 0.55f, 0, 0.55f, 0.75f, 0.30f, straw);                    // torso
    add_octahedron(0, 1.55f, 0, 0.22f, straw, straw2);                   // head
    add_collider(DUMMY_X, DUMMY_Z, 0.55f);
}

// Blocky PS1-style rat (origin at its feet, snout toward +Z).
static void build_rat(void) {
    cur = &rat_mesh;
    rgb fur = C(0.46f, 0.38f, 0.32f), fur2 = C(0.38f, 0.31f, 0.26f);
    rgb pink = C(0.80f, 0.55f, 0.55f), eye = C(0.95f, 0.15f, 0.12f), tooth = C(0.92f, 0.90f, 0.80f);

    add_box(0.0f, 0.08f, -0.05f, 0.30f, 0.24f, 0.50f, fur);        // body
    add_box(0.0f, 0.10f, -0.24f, 0.34f, 0.28f, 0.24f, fur2);       // haunches
    add_box(0.0f, 0.12f, 0.28f, 0.20f, 0.18f, 0.22f, fur);         // head
    add_box(0.0f, 0.14f, 0.44f, 0.11f, 0.11f, 0.14f, fur2);        // snout
    add_box(0.0f, 0.17f, 0.52f, 0.05f, 0.05f, 0.04f, pink);        // nose
    add_box(0.0f, 0.08f, 0.46f, 0.05f, 0.05f, 0.03f, tooth);       // buck teeth
    add_box(-0.10f, 0.28f, 0.20f, 0.07f, 0.10f, 0.03f, pink);      // ears
    add_box( 0.10f, 0.28f, 0.20f, 0.07f, 0.10f, 0.03f, pink);
    add_box(-0.075f, 0.22f, 0.385f, 0.035f, 0.035f, 0.03f, eye);   // eyes
    add_box( 0.075f, 0.22f, 0.385f, 0.035f, 0.035f, 0.03f, eye);
    add_box(-0.11f, 0.0f, 0.14f, 0.07f, 0.10f, 0.09f, fur2);       // legs
    add_box( 0.11f, 0.0f, 0.14f, 0.07f, 0.10f, 0.09f, fur2);
    add_box(-0.13f, 0.0f, -0.26f, 0.08f, 0.12f, 0.12f, fur2);
    add_box( 0.13f, 0.0f, -0.26f, 0.08f, 0.12f, 0.12f, fur2);
    add_prism(V(0.0f, 0.16f, -0.36f), V(0.0f, 0.10f, -0.62f), 0.022f, 4, pink);   // tail
    add_prism(V(0.0f, 0.10f, -0.62f), V(0.0f, 0.20f, -0.88f), 0.018f, 4, pink);
}

// Rock crab: a chunky crab made of boulders (origin at its feet, claws toward +Z).
static void build_crab(void) {
    cur = &crab_mesh;
    rgb rock = C(0.46f, 0.44f, 0.41f), rock2 = C(0.34f, 0.33f, 0.33f), rock3 = C(0.56f, 0.53f, 0.48f);
    rgb dark = C(0.22f, 0.21f, 0.22f), moss = C(0.28f, 0.40f, 0.22f), glow = C(1.0f, 0.55f, 0.15f);

    add_box(0.0f, 0.12f, 0.0f, 0.95f, 0.30f, 0.76f, rock2);          // lower body
    add_box(0.0f, 0.40f, -0.02f, 0.78f, 0.22f, 0.62f, rock);         // upper shell
    add_box(0.0f, 0.18f, -0.44f, 0.55f, 0.22f, 0.14f, rock2);        // rear plate
    add_octahedron(0.0f, 0.66f, -0.05f, 0.27f, rock3, rock);         // rocks on its back
    add_octahedron(-0.28f, 0.58f, 0.12f, 0.17f, rock, rock2);
    add_octahedron(0.30f, 0.57f, -0.16f, 0.19f, rock3, rock2);
    add_box(0.04f, 0.60f, 0.22f, 0.24f, 0.04f, 0.16f, moss);         // moss patch

    add_box(-0.14f, 0.50f, 0.32f, 0.06f, 0.16f, 0.06f, rock2);       // eye stalks
    add_box( 0.14f, 0.50f, 0.32f, 0.06f, 0.16f, 0.06f, rock2);
    add_box(-0.14f, 0.64f, 0.34f, 0.09f, 0.09f, 0.09f, glow);        // glowing eyes
    add_box( 0.14f, 0.64f, 0.34f, 0.09f, 0.09f, 0.09f, glow);

    for (int k = 0; k < 2; k++) {
        float sgn = k ? 1.0f : -1.0f;
        add_box(sgn * 0.46f, 0.18f, 0.30f, 0.20f, 0.18f, 0.34f, rock2);   // upper arm
        add_box(sgn * 0.58f, 0.14f, 0.58f, 0.34f, 0.28f, 0.34f, rock);    // claw
        add_box(sgn * 0.49f, 0.14f, 0.84f, 0.13f, 0.20f, 0.30f, rock3);   // pincers
        add_box(sgn * 0.67f, 0.14f, 0.84f, 0.13f, 0.20f, 0.30f, rock3);
        for (int i = 0; i < 3; i++) {                                     // legs
            float z = -0.24f + 0.22f * i;
            add_prism(V(sgn * 0.42f, 0.24f, z), V(sgn * 0.82f, 0.02f, z + 0.05f), 0.045f, 4, dark);
        }
    }
}

// Door slab with its hinge at the origin, extending along -Z.
static void build_door(void) {
    cur = &door_mesh;
    rgb wood = C(0.40f, 0.26f, 0.14f), iron = C(0.30f, 0.30f, 0.34f);
    const float w = 2.0f * DOOR_HALF + 0.05f;
    add_box(0.0f, 0.0f, -w / 2, 0.14f, 2.7f, w, wood);
    add_box(0.0f, 0.5f, -w / 2, 0.18f, 0.12f, w, iron);
    add_box(0.0f, 1.9f, -w / 2, 0.18f, 0.12f, w, iron);
    add_box(0.12f, 1.2f, -w + 0.25f, 0.08f, 0.10f, 0.10f, iron);   // handle
}

// Hooded wanderer (origin at his feet, facing +Z).
static void build_npc(void) {
    cur = &npc_mesh;
    rgb cloth = C(0.30f, 0.27f, 0.24f), cloth2 = C(0.24f, 0.21f, 0.19f), hood = C(0.36f, 0.30f, 0.22f);
    rgb skin = C(0.78f, 0.62f, 0.50f), dark = C(0.10f, 0.08f, 0.08f), belt = C(0.45f, 0.30f, 0.14f);

    add_box(-0.12f, 0.0f, 0.0f, 0.16f, 0.7f, 0.20f, dark);            // legs
    add_box( 0.12f, 0.0f, 0.0f, 0.16f, 0.7f, 0.20f, dark);
    add_box(0.0f, 0.12f, 0.0f, 0.72f, 0.55f, 0.46f, cloth2);          // cloak skirt
    add_box(0.0f, 0.60f, 0.0f, 0.60f, 0.80f, 0.38f, cloth);           // torso
    add_box(0.0f, 0.62f, 0.0f, 0.64f, 0.08f, 0.42f, belt);            // belt
    add_box(-0.38f, 0.72f, 0.04f, 0.14f, 0.60f, 0.18f, cloth);        // arms
    add_box( 0.38f, 0.72f, 0.04f, 0.14f, 0.60f, 0.18f, cloth);
    add_box(-0.38f, 0.64f, 0.06f, 0.11f, 0.11f, 0.11f, skin);         // hands
    add_box( 0.38f, 0.64f, 0.06f, 0.11f, 0.11f, 0.11f, skin);
    add_box(0.0f, 1.20f, 0.0f, 0.30f, 0.30f, 0.30f, skin);            // head
    add_box(-0.07f, 1.32f, 0.152f, 0.05f, 0.05f, 0.02f, dark);        // eyes
    add_box( 0.07f, 1.32f, 0.152f, 0.05f, 0.05f, 0.02f, dark);
    add_box(0.0f, 1.48f, -0.02f, 0.42f, 0.12f, 0.40f, hood);          // hood top
    add_box(0.0f, 1.18f, -0.12f, 0.42f, 0.34f, 0.18f, hood);          // hood back
    add_box(-0.21f, 1.18f, 0.03f, 0.06f, 0.34f, 0.32f, hood);         // hood sides
    add_box( 0.21f, 1.18f, 0.03f, 0.06f, 0.34f, 0.32f, hood);
    add_collider(NPC_X, NPC_Z, 0.5f);
}

// The blacksmith (origin at his feet, facing +Z toward the anvil). The hammer arm is its own mesh, hinged at the shoulder.
static void build_smith(void) {
    cur = &smith_mesh;
    rgb shirt = C(0.46f, 0.30f, 0.22f), apron = C(0.22f, 0.15f, 0.10f), dark = C(0.12f, 0.10f, 0.10f);
    rgb skin = C(0.80f, 0.58f, 0.46f), beard = C(0.30f, 0.18f, 0.10f), iron = C(0.45f, 0.46f, 0.50f);

    add_box(-0.14f, 0.0f, 0.0f, 0.20f, 0.75f, 0.24f, dark);          // legs
    add_box( 0.14f, 0.0f, 0.0f, 0.20f, 0.75f, 0.24f, dark);
    add_box(0.0f, 0.70f, 0.0f, 0.78f, 0.78f, 0.46f, shirt);           // broad torso
    add_box(0.0f, 0.40f, 0.20f, 0.60f, 0.85f, 0.08f, apron);          // leather apron
    add_box(-0.44f, 0.70f, 0.0f, 0.16f, 0.72f, 0.20f, shirt);         // left arm: reaches out holding tongs
    add_box(-0.44f, 1.02f, 0.32f, 0.15f, 0.15f, 0.55f, shirt);
    add_box(-0.44f, 1.02f, 0.66f, 0.12f, 0.12f, 0.12f, skin);
    add_box(-0.44f, 0.98f, 0.82f, 0.04f, 0.04f, 0.40f, iron);         // tongs
    add_box(0.0f, 1.46f, 0.0f, 0.34f, 0.34f, 0.34f, skin);            // head
    add_box(0.0f, 1.36f, 0.12f, 0.30f, 0.20f, 0.12f, beard);          // beard
    add_box(0.0f, 1.64f, 0.0f, 0.36f, 0.08f, 0.36f, dark);            // headband
    add_box(-0.08f, 1.58f, 0.172f, 0.05f, 0.05f, 0.02f, dark);        // eyes
    add_box( 0.08f, 1.58f, 0.172f, 0.05f, 0.05f, 0.02f, dark);
    add_collider(SMITH_X, SMITH_Z, 0.5f);

    cur = &smitharm_mesh;   // origin at the shoulder; the arm hangs along -Y and the hammer continues it
    add_box(0.0f, -0.62f, 0.0f, 0.16f, 0.62f, 0.20f, shirt);
    add_box(0.0f, -0.74f, 0.0f, 0.13f, 0.13f, 0.13f, skin);
    add_prism(V(0, -0.55f, 0), V(0, -1.06f, 0), 0.03f, 5, C(0.45f, 0.30f, 0.15f));   // handle
    add_box(0.0f, -1.22f, 0.0f, 0.30f, 0.16f, 0.15f, iron);                           // head
}

// A tinted copy of a finished mesh (the cave's special weapons and bosses reuse the base models in new colours).
static void clone_tint(Mesh *dst, const Mesh *src, float r, float g, float b) {
    memcpy(dst->v, src->v, (size_t)src->n * 3 * sizeof(float));
    for (int i = 0; i < src->n; i++) {
        dst->c[i * 4 + 0] = fminf(1.0f, src->c[i * 4 + 0] * r);
        dst->c[i * 4 + 1] = fminf(1.0f, src->c[i * 4 + 1] * g);
        dst->c[i * 4 + 2] = fminf(1.0f, src->c[i * 4 + 2] * b);
        dst->c[i * 4 + 3] = src->c[i * 4 + 3];
    }
    dst->n = src->n;
}

// The beacon crystal (spins and bobs above the pedestal).
static void build_gem(void) {
    cur = &gem_mesh;
    add_octahedron(0.0f, 0.0f, 0.0f, 0.6f, C(0.25f, 0.85f, 0.95f), C(0.85f, 0.30f, 0.90f));
}

// ----------------------------------------------------------- inventory ----

typedef enum { ITEM_SWORD = 0, ITEM_MACE = 1, ITEM_SPEAR = 2, ITEM_GLOAM = 3,
               ITEM_CLOTH_HOOD = 4, ITEM_CLOTH_TUNIC = 5, ITEM_CLOTH_GLOVES = 6, ITEM_CLOTH_TROUSERS = 7,
               ITEM_LEATHER_CAP = 8, ITEM_LEATHER_JERKIN = 9, ITEM_LEATHER_BRACERS = 10, ITEM_LEATHER_BOOTS = 11,
               ITEM_PICK = 12, ITEM_BONE_SPEAR = 13, ITEM_BASALT_MACE = 14, ITEM_AXE = 15, ITEM_IRON_HELM = 16, ITEM_COUNT } ItemId;
// Item kinds: 0 = weapon, 1..4 = armor for the head / chest / arms / legs.
enum { KIND_WEAPON = 0, KIND_HEAD, KIND_CHEST, KIND_ARMS, KIND_LEGS };
#define ARMOR_SLOTS 4
static const char *const armor_slot_names[ARMOR_SLOTS] = { "HEAD", "CHEST", "ARMS", "LEGS" };

// Damage tags. Enemies can be weak to or resist each of these.
typedef enum { DMG_SLASH = 0, DMG_BLUNT = 1, DMG_PIERCE = 2, DMG_FIRE = 3, DMG_BLAST = 4, DMG_TYPE_COUNT } DamageType;
static const char *const dmg_type_names[DMG_TYPE_COUNT] = { "SLASHING", "BLUNT", "PIERCING", "FIRE", "BLAST" };
static const char *const dmg_type_short[DMG_TYPE_COUNT] = { "SLASH", "BLUNT", "PIERCE", "FIRE", "BLAST" };

// Weapon pose offsets (added to the resting view model) used by swing animations.
//   dx/dy/dz: hand movement (camera space)   ry: yaw about the vertical axis (+ = toward the left)
//   rz: roll/lean on screen                  rx: pitch (- = tip tilts away from you)
typedef struct { float dx, dy, dz, rz, rx, ry; } Pose;
enum { EASE_SMOOTH = 0, EASE_IN, EASE_OUT, EASE_LINEAR };
#define SWING_MAX_KEYS 8
// Keyframes: t runs 0..1 over the swing; ease[i] shapes the segment from key i to key i+1.
typedef struct { int n; float t[SWING_MAX_KEYS]; unsigned char ease[SWING_MAX_KEYS]; Pose p[SWING_MAX_KEYS]; } Swing;

// Sword: a flat horizontal slice. The blade is held pointing forward-left with the flat of the
// blade parallel to the ground, then whipped across the screen to the right, edge leading.
static const Swing sword_swing = {
    6,
    {0.00f, 0.32f, 0.46f, 0.60f, 0.74f, 1.00f},
    {EASE_SMOOTH, EASE_IN, EASE_OUT, EASE_SMOOTH, EASE_SMOOTH, EASE_SMOOTH},
    {
        { 0.00f,  0.00f,  0.00f,   0.0f,   0.0f,   0.0f},   // rest
        {-0.55f,  0.04f,  0.00f,  40.0f, -60.0f,  74.0f},   // wind-up: blade out flat across the screen to the left, wrist cocked
        {-0.30f,  0.00f, -0.22f,   0.0f, -62.0f,  10.0f},   // mid slice: wrist rolls through as it sweeps the centre
        {-0.05f, -0.04f, -0.10f, -40.0f, -60.0f, -56.0f},   // end of the slice: blade across the screen to the right
        { 0.02f, -0.06f, -0.08f, -44.0f, -56.0f, -62.0f},   // follow-through
        { 0.00f,  0.00f,  0.00f,   0.0f,   0.0f,   0.0f},   // back to rest
    }
};

// Mace: overhead hammer blow, top to bottom.
static const Swing mace_swing = {
    5,
    {0.00f, 0.34f, 0.56f, 0.68f, 1.00f},
    {EASE_SMOOTH, EASE_SMOOTH, EASE_SMOOTH, EASE_SMOOTH, EASE_SMOOTH},
    {
        { 0.00f,  0.00f,  0.00f,   0.0f,   0.0f,  0.0f},   // rest
        {-0.05f,  0.48f,  0.06f,  -2.0f,  24.0f,  0.0f},   // wind-up: hoisted high
        {-0.05f, -0.22f, -0.24f,   0.0f, -92.0f,  0.0f},   // slam: down and forward
        {-0.05f, -0.26f, -0.26f,   0.0f, -100.0f, 0.0f},   // impact
        { 0.00f,  0.00f,  0.00f,   0.0f,   0.0f,  0.0f},   // back to rest
    }
};

// Spear: drawn back along its own shaft, held for a beat, then jabbed straight out (a poke, not a swing).
static const Swing spear_swing = {
    6,
    {0.00f, 0.30f, 0.40f, 0.50f, 0.64f, 1.00f},
    {EASE_SMOOTH, EASE_SMOOTH, EASE_OUT, EASE_SMOOTH, EASE_SMOOTH, EASE_SMOOTH},
    {
        { 0.00f,  0.00f,  0.00f,   0.0f,   0.0f,  0.0f},   // rest
        { 0.10f, -0.10f,  0.20f,   0.0f, -14.0f, -3.0f},   // pull back: hand drawn in toward the body, point levelled
        { 0.10f, -0.10f,  0.24f,   0.0f, -14.0f, -3.0f},   // coil (a short hold so the jab reads)
        {-0.06f,  0.05f, -0.80f,   0.0f, -26.0f,  3.0f},   // jab: the whole spear shoots straight forward
        {-0.06f,  0.05f, -0.74f,   0.0f, -26.0f,  3.0f},   // hold at full reach
        { 0.00f,  0.00f,  0.00f,   0.0f,   0.0f,  0.0f},   // back to rest
    }
};

typedef struct {
    const char *name;
    const char *desc;
    Mesh *mesh;
    DamageType dmg_type;
    float damage;
    float swing_time, stamina_cost, range, arc_deg, hit_start, hit_end;
    const Swing *swing;
    Pose hold;                      // how it is held at rest (added to the default view model)
    float preview_scale, preview_cy;   // size and centre (along the shaft) for the equipment screen
    int kind;                       // KIND_WEAPON or an armor slot
    float defense;                  // armor: fraction of damage taken that it removes (0.02 = 2%)
} ItemDef;

static const ItemDef item_defs[ITEM_COUNT] = {
    [ITEM_SWORD] = { "IRON SWORD", "A PLAIN BLADE. STILL SHARP.", &sword_mesh,
      DMG_SLASH, SWORD_DAMAGE, SWORD_SWING_TIME, SWORD_STAMINA_COST, SWORD_RANGE, SWORD_ARC_DEG,
      SWORD_HIT_START, SWORD_HIT_END, &sword_swing, {0}, 1.15f, 0.31f },
    [ITEM_MACE] = { "STONE MACE", "HEAVY AND BLUNT. SHATTERS WHAT SWORDS CANNOT.", &mace_mesh,
      DMG_BLUNT, MACE_DAMAGE, MACE_SWING_TIME, MACE_STAMINA_COST, MACE_RANGE, MACE_ARC_DEG,
      MACE_HIT_START, MACE_HIT_END, &mace_swing, {0}, 1.5f, 0.22f },
    [ITEM_SPEAR] = { "IRON SPEAR", "A LONG REACH. THRUSTS FORWARD.", &spear_mesh,
      DMG_PIERCE, SPEAR_DAMAGE, SPEAR_SWING_TIME, SPEAR_STAMINA_COST, SPEAR_RANGE, SPEAR_ARC_DEG,
      SPEAR_HIT_START, SPEAR_HIT_END, &spear_swing, { -0.06f, -0.02f, 0.0f, 0.0f, -48.0f, 10.0f }, 0.58f, 0.80f },
    [ITEM_GLOAM] = { "GLOAM BLADE", "FORGED IN MOONLIGHT. THE EDGE SINGS THROUGH STONE.", &gloam_mesh,
      DMG_SLASH, GLOAM_DAMAGE, 0.62f, 22.0f, 2.9f, 85.0f,
      0.36f, 0.60f, &sword_swing, {0}, 0.85f, 0.44f },
    [ITEM_CLOTH_HOOD]     = { .name = "CLOTH HOOD",     .desc = "A PLAIN CLOTH HOOD. BARELY ANY PROTECTION.", .kind = KIND_HEAD,  .defense = 0.02f },
    [ITEM_CLOTH_TUNIC]    = { .name = "CLOTH TUNIC",    .desc = "A ROUGH TUNIC. BETTER THAN BARE SKIN.",       .kind = KIND_CHEST, .defense = 0.04f },
    [ITEM_CLOTH_GLOVES]   = { .name = "CLOTH GLOVES",   .desc = "THIN GLOVES. A LITTLE PADDING.",              .kind = KIND_ARMS,  .defense = 0.01f },
    [ITEM_CLOTH_TROUSERS] = { .name = "CLOTH TROUSERS", .desc = "SIMPLE TROUSERS. HARDLY ARMOR AT ALL.",       .kind = KIND_LEGS,  .defense = 0.03f },
    [ITEM_LEATHER_CAP]     = { .name = "LEATHER CAP",     .desc = "A STIFF CAP OF BOILED LEATHER.",             .kind = KIND_HEAD,  .defense = 0.03f },
    [ITEM_LEATHER_JERKIN]  = { .name = "LEATHER JERKIN",  .desc = "THICK HIDE, STITCHED BY SOMEONE WHO CARED.", .kind = KIND_CHEST, .defense = 0.07f },
    [ITEM_LEATHER_BRACERS] = { .name = "LEATHER BRACERS", .desc = "WRIST GUARDS. THEY TURN SMALL BLOWS.",        .kind = KIND_ARMS,  .defense = 0.03f },
    [ITEM_LEATHER_BOOTS]   = { .name = "LEATHER BOOTS",   .desc = "SOLID BOOTS, WORN BUT SOUND.",               .kind = KIND_LEGS,  .defense = 0.05f },
    [ITEM_PICK] = { "MINER'S PICK", "A CRUDE PICK FROM THE DEEP. PIERCES ROCK AND BONE ALIKE.", &pick_mesh,
      DMG_PIERCE, 30.0f, 0.78f, 26.0f, 2.4f, 38.0f,
      0.48f, 0.70f, &mace_swing, {0}, 1.3f, 0.35f },
    [ITEM_AXE] = { "BATTLE AXE", "HEAVIER THAN A SWORD AND HITS HARDER, BUT SLOWER TO SWING.", &axe_mesh,
      DMG_SLASH, 32.0f, 0.86f, 24.0f, 2.6f, 72.0f, 0.44f, 0.66f, &sword_swing, {0}, 1.15f, 0.28f },
    [ITEM_IRON_HELM] = { .name = "IRON HELM", .desc = "A DENTED HELM. SOLID PROTECTION FOR YOUR HEAD.", .kind = KIND_HEAD, .defense = 0.06f },
    [ITEM_BONE_SPEAR] = { "BONE SPEAR", "PALE AND LIGHT. QUICK, LONG, AND HUNGRY FOR THE UNDEAD.", &bonespear_mesh,
      DMG_PIERCE, 30.0f, 0.42f, 10.0f, 3.7f, 24.0f, 0.32f, 0.60f, &spear_swing,
      { -0.06f, -0.02f, 0.0f, 0.0f, -48.0f, 10.0f }, 0.58f, 0.80f },
    [ITEM_BASALT_MACE] = { "BASALT MACE", "BLACK STONE ON AN IRON HAFT. VERY HEAVY. STUNS.", &basaltmace_mesh,
      DMG_BLUNT, 46.0f, 1.20f, 42.0f, 2.4f, 50.0f, 0.52f, 0.72f, &mace_swing, {0}, 1.5f, 0.22f },
};

// ---- consumables (the three-slot hot bar: D-pad left / right chooses, SQUARE uses) ----
typedef enum { CONS_HERB = 0, CONS_POTION = 1, CONS_BOMB = 2, CONS_COUNT } ConsId;
static const char *const cons_names[CONS_COUNT] = { "HERB", "POTION", "BOMB" };
static const char *const cons_desc[CONS_COUNT] = {
    "A BITTER GREEN HERB. CHEWED, IT CLOSES SMALL WOUNDS.",
    "A RED TONIC IN A GLASS BOTTLE. HEALS A GOOD DEAL.",
    "A ROUND IRON BOMB. THROWN, IT EXPLODES ON IMPACT. BLAST DAMAGE." };
#define HOT_SLOTS 3
static int cons_count[CONS_COUNT];
static int hot[HOT_SLOTS] = { -1, -1, -1 };     // the consumable type in each hot-bar slot (-1 = empty)
static int active_hot = 0;
static float use_t = -1.0f;                      // item-use animation timer, -1 = idle
static int   fade_state = 0, portal_k = -1;      // zone change: 1 = fading out, 2 = fading in
static float fade_t = 0.0f, fade_a = 0.0f;
static void give_cons(int c, int qty) {
    cons_count[c] += qty;
    if (cons_count[c] > CONS_MAX) cons_count[c] = CONS_MAX;
    for (int i = 0; i < HOT_SLOTS; i++) if (hot[i] == c) return;
    for (int i = 0; i < HOT_SLOTS; i++) if (hot[i] < 0) { hot[i] = c; return; }
}
static int   use_cons = -1, use_done = 0;
static const Mesh *cons_mesh(int c) { return c == CONS_HERB ? &herb_mesh : c == CONS_POTION ? &potion_mesh : &bomb_mesh; }

// The left hand: empty, the fireball spell, or the torch (the torch takes the hand, so no spell while it is lit).
enum { LH_NONE = 0, LH_FIRE = 1, LH_TORCH = 2 };
static int left_hand = LH_NONE, has_torch = 0;

#define INV_MAX 16
static int inv[INV_MAX];          // item ids
static int inv_n = 0;
#define QUICK_SLOTS 3
static int quick[QUICK_SLOTS] = { -1, -1, -1 };   // the three equipped weapons (item ids, -1 = empty)
static int active_quick = 0;                       // which of them is in hand
static int armor[ARMOR_SLOTS] = { -1, -1, -1, -1 };   // worn armor (item ids): head, chest, arms, legs
static int has_fire = 0;                           // the fireball spell has been found
typedef struct { float x, y, z, dx, dz, dist; int on; } Proj;
#define MAX_PROJ 6
static Proj projs[MAX_PROJ];
static float cast_t = -1.0f;     // seconds into a cast, -1 = idle
static int   cast_fired = 0;
static float armor_reduction(void) {
    float r = 0.0f;
    for (int i = 0; i < ARMOR_SLOTS; i++) if (armor[i] >= 0) r += item_defs[armor[i]].defense;
    return r > 0.8f ? 0.8f : r;
}
static float swap_t = -1.0f;                       // weapon-swap animation timer, -1 = idle
static int   swap_to = 0, swap_done = 0;
static int equipped_id(void) { return quick[active_quick]; }
typedef enum { MENU_NONE = 0, MENU_INVENTORY, MENU_PAUSE, MENU_BESTIARY, MENU_BEACON, MENU_DIALOGUE, MENU_STATS, MENU_ITEMS } MenuId;
static int menu = MENU_NONE;
static int pause_sel = 0, bestiary_sel = 0, beacon_sel = 0, stats_sel = 0, menu_return = MENU_BEACON;
static int pend[4];   // attribute points chosen in the level-up screen but not yet confirmed
static int inv_sel = 0;           // equipment screen: cursor in the item list (0 = EMPTY)
static int eq_focus = 0, eq_slot = 0;   // equipment screen: 0 = choosing a slot, 1 = choosing an item
static int items_focus = 0, items_slot = 0, items_sel = 0;   // items page: same idea for the hot bar

// ---- player state ----
static float player_max_hp = MAX_HEALTH,  player_hp = MAX_HEALTH;
static float player_max_stam = MAX_STAMINA, player_stam = MAX_STAMINA;
static int sprinting = 0;
static float stam_delay = 0.0f;                       // time until stamina regen resumes
static float dodge_t = -1.0f;                         // seconds into a dodge, -1 = idle
static float dodge_vx = 0.0f, dodge_vz = 0.0f, dodge_side = 0.0f;
static float attack_t = -1.0f;                        // seconds into a swing, -1 = idle
static unsigned long long attack_hit_mask = 0;                  // bit 0: the dummy was hit this swing
static unsigned attack_serial = 0;                              // each swing has its own number; enemies remember the last one that hit them
static int swing_sparked = 0;
static float dummy_wobble = -1.0f;                    // seconds since dummy was hit, -1 = still
static float dummy_hit_amp = 0.0f;
static DamageType dummy_hit_type = DMG_SLASH;
static int   dummy_hits = 0;

static void use_stamina(float cost) {
    player_stam -= cost;
    if (player_stam <= 0.0f) { player_stam = 0.0f; stam_delay = STAMINA_EXHAUST_DELAY; }
    else                     { stam_delay = STAMINA_REGEN_DELAY; }
}

// Put item `id` (or -1 for nothing) into weapon slot `slot`. A weapon can only sit in one slot,
// so equipping one that is already elsewhere swaps the two.
static void equip_item(int slot, int id) {
    if (id >= 0) {
        for (int j = 0; j < QUICK_SLOTS; j++)
            if (j != slot && quick[j] == id) quick[j] = quick[slot];
    }
    quick[slot] = id;
    attack_t = -1.0f;
}

// Equipment screen slots: 0..2 are the weapon slots, then head / chest / arms / legs.
#define EQ_LH (QUICK_SLOTS + ARMOR_SLOTS)     // the left-hand slot: fireball or torch
#define EQ_SLOTS (EQ_LH + 1)
static int eq_slot_kind(int slot) { return slot < QUICK_SLOTS ? KIND_WEAPON : slot - QUICK_SLOTS + 1; }
static int eq_current(int slot) {
    if (slot == EQ_LH) return left_hand ? left_hand : -1;
    return slot < QUICK_SLOTS ? quick[slot] : armor[slot - QUICK_SLOTS];
}
static const char *eq_item_name(int slot, int id) {
    if (slot == EQ_LH) return id == LH_TORCH ? "TORCH" : "FIREBALL";
    return item_defs[id].name;
}
// The owned items that fit a slot, as item ids. Returns how many.
static int eq_build_list(int slot, int *out) {
    int n = 0, kind = eq_slot_kind(slot);
    if (slot == EQ_LH) {
        if (has_fire) out[n++] = LH_FIRE;
        if (has_torch) out[n++] = LH_TORCH;
        return n;
    }
    for (int i = 0; i < inv_n; i++) if (item_defs[inv[i]].kind == kind) out[n++] = inv[i];
    return n;
}
static void eq_equip(int slot, int id) {
    if (slot == EQ_LH) { left_hand = id < 0 ? LH_NONE : id; cast_t = -1.0f; }
    else if (slot < QUICK_SLOTS) equip_item(slot, id);
    else armor[slot - QUICK_SLOTS] = id;
}

// Equipment screen: which item is being looked at (-1 = none). While choosing from the list it is
// the highlighted entry, otherwise whatever sits in the selected slot.
#define EQ_PREVIEW_X  652.0f
#define EQ_PREVIEW_Y   80.0f
#define EQ_PREVIEW_W  280.0f
#define EQ_PREVIEW_H  130.0f
static int eq_shown_item(void) {
    if (eq_focus) {
        int list[INV_MAX];
        int n = eq_build_list(eq_slot, list);
        return inv_sel > 0 && inv_sel <= n ? list[inv_sel - 1] : -1;
    }
    return eq_current(eq_slot);
}

static float smooth01(float u) {
    if (u < 0.0f) u = 0.0f;
    if (u > 1.0f) u = 1.0f;
    return u * u * (3.0f - 2.0f * u);
}

static Pose swing_pose(const Swing *sw, float u) {
    if (u <= 0.0f) return sw->p[0];
    if (u >= 1.0f) return sw->p[sw->n - 1];
    int i = 0;
    while (i < sw->n - 2 && u > sw->t[i + 1]) i++;
    float f = (u - sw->t[i]) / (sw->t[i + 1] - sw->t[i]);
    switch (sw->ease[i]) {
    case EASE_IN:     f = f * f; break;
    case EASE_OUT:    f = 1.0f - (1.0f - f) * (1.0f - f); break;
    case EASE_LINEAR: break;
    default:          f = smooth01(f); break;
    }
    Pose a = sw->p[i], b = sw->p[i + 1], r;
    r.dx = a.dx + (b.dx - a.dx) * f;
    r.dy = a.dy + (b.dy - a.dy) * f;
    r.dz = a.dz + (b.dz - a.dz) * f;
    r.rz = a.rz + (b.rz - a.rz) * f;
    r.rx = a.rx + (b.rx - a.rx) * f;
    r.ry = a.ry + (b.ry - a.ry) * f;
    return r;
}

// kind: 0 = floating item, 1 = chest holding `item`, 2 = chest holding the cloth armor set, 3 = the fire tome (a spell)
// kind: 0 = floating item, 1 = chest holding `item`, 2 = chest holding the cloth armor set, 3 = the fire tome (a spell),
//       4 = floating consumable (item = ConsId, qty), 5 = chest holding consumables, 6 = chest holding the leather armor set
typedef struct { float x, z; int item; int taken; float y; int chest; int qty; } Pickup;   // y = floor height
static Pickup pickups[] = {
    { -2.5f, 2.5f, ITEM_SWORD, 0, 0.0f, 0, 0 },
    {  7.0f, -1.5f, ITEM_MACE, 0, 0.0f, 0, 0 },
    { -5.5f, -2.5f, ITEM_SPEAR, 0, 0.0f, 0, 0 },
    { PZ_CX, PZ_CZ, ITEM_GLOAM, 0, PZ_CHEST_TOP, 1, 0 },   // top of the tower
    { CLOTH_CHEST_X, CLOTH_CHEST_Z, ITEM_CLOTH_TUNIC, 0, 0.0f, 2, 0 },   // hidden behind the pyramid
    { TOME_X, TOME_Z, 0, 0, 0.0f, 3, 0 },                  // the fireball tome, deep in the labyrinth
    // overworld supplies
    { -3.0f, 8.0f,  CONS_HERB,   0, 0.0f, 4, 2 },       // 6
    {  7.5f, 14.0f, CONS_HERB,   0, 0.0f, 4, 1 },       // 7
    { 22.5f, -3.8f, CONS_POTION, 0, 0.0f, 4, 1 },       // 8: in the rat room
    { 29.5f,  3.0f, CONS_BOMB,   0, 0.0f, 4, 2 },       // 9: in the crab room
    // labyrinth dead ends (positions are filled in by place_maze_pickups)
    { 0.0f, 0.0f, CONS_POTION,   0, 0.0f, 5, 2 },       // 10
    { 0.0f, 0.0f, CONS_BOMB,     0, 0.0f, 5, 3 },       // 11
    { 0.0f, 0.0f, CONS_HERB,     0, 0.0f, 4, 2 },       // 12
    // the cave (positions are filled in when the cave is built)
    { 0.0f, 0.0f, 0,             0, 0.0f, 6, 0 },       // 13: leather armor set
    { 0.0f, 0.0f, ITEM_PICK,     0, 0.0f, 1, 0 },       // 14
    { 0.0f, 0.0f, CONS_BOMB,     0, 0.0f, 5, 4 },       // 15
    { 0.0f, 0.0f, CONS_POTION,   0, 0.0f, 5, 3 },       // 16
    { 0.0f, 0.0f, CONS_HERB,     0, 0.0f, 4, 3 },       // 17
    { 0.0f, 0.0f, CONS_HERB,     0, 0.0f, 4, 3 },       // 18
    { 0.0f, 0.0f, CONS_POTION,   0, 0.0f, 4, 1 },       // 19
    { 0.0f, 0.0f, CONS_BOMB,     0, 0.0f, 5, 2 },       // 20
    { 0.0f, 0.0f, ITEM_BASALT_MACE, 0, 0.0f, 1, 0 },    // 21: behind the cave brute
    { 0.0f, 0.0f, ITEM_BONE_SPEAR,  0, 0.0f, 1, 0 },    // 22: behind the bone warden
    { TW_CX, TW_CZ, ITEM_AXE, 0, TW_TOP, 1, 0 },         // 23: the summit of the spiral tower
    { 34.7f, 0.2f, ITEM_IRON_HELM, 0, 0.0f, 1, 0 },     // 24: in the crab room
};
#define PK_MAZE0   10     // first labyrinth slot
#define PK_CAVE0   13     // first cave slot
#define PK_CAVE_N   8
#define NUM_PICKUPS ((int)(sizeof(pickups) / sizeof(pickups[0])))
#define PICKUP_RANGE 2.2f

// ------------------------------------------------------------ enemies ----

typedef enum { ENEMY_RAT = 0, ENEMY_CRAB, ENEMY_WORM, ENEMY_UNDEAD, ENEMY_ZOMBIE, ENEMY_BRUTE, ENEMY_WARDEN, ENEMY_TYPE_COUNT } EnemyType;

typedef struct {
    const char *name;
    const char *desc[2];            // two short lines for the bestiary
    Mesh *mesh;
    float max_hp;
    float resist[DMG_TYPE_COUNT];   // damage multiplier per damage tag: 1 neutral, >1 weak, <1 resistant
    float bar_height;               // world height of the health bar above the ground
    float radius;
    float scale;
    int xp;                         // xp granted when killed
    // behaviour
    int   hops;                     // 1 = moves in hops (rat), 0 = walks
    int   wanders;                  // 1 = strolls around its spawn point while idle
    int   splits;                   // 1 = a slashing hit splits it in two instead of hurting it (worm)
    float aggro_range, move_speed, wander_speed, hop_time;
    float attack_range, windup, lunge_time, lunge_speed, recover, stagger, damage, hit_radius;
    // bestiary preview
    float preview_scale, preview_cy, preview_cz;
    // an animated limb drawn separately (a sword arm, a pair of arms): its mesh, shoulder position, resting angle
    Mesh *limb; float limb_x, limb_y, limb_rest;
} EnemyDef;

static const EnemyDef enemy_defs[ENEMY_TYPE_COUNT] = {
    [ENEMY_RAT] = {
        .name = "GIANT RAT",
        .desc = { "A BLOCKY SEWER PEST THAT HOPS CLOSER.", "WATCH FOR THE CROUCH - THEN THE LUNGE." },
        .mesh = &rat_mesh, .max_hp = RAT_HEALTH,
        .resist = { RAT_RESIST_SLASH, RAT_RESIST_BLUNT, RAT_RESIST_PIERCE, RAT_RESIST_FIRE, RAT_RESIST_BLAST },
        .bar_height = 0.95f, .radius = RAT_RADIUS, .scale = RAT_SCALE, .xp = RAT_XP,
        .hops = 1, .wanders = 0,
        .aggro_range = RAT_AGGRO_RANGE, .move_speed = RAT_HOP_SPEED, .wander_speed = 0.0f, .hop_time = RAT_HOP_TIME,
        .attack_range = RAT_ATTACK_RANGE, .windup = RAT_WINDUP_TIME, .lunge_time = RAT_LUNGE_TIME,
        .lunge_speed = RAT_LUNGE_SPEED, .recover = RAT_RECOVER_TIME, .stagger = RAT_STAGGER_TIME,
        .damage = RAT_DAMAGE, .hit_radius = RAT_HIT_RADIUS,
        .preview_scale = 0.85f, .preview_cy = 0.15f, .preview_cz = -0.12f,
    },
    [ENEMY_CRAB] = {
        .name = "ROCK CRAB",
        .desc = { "A CRAB CARVED FROM LIVING STONE.", "BLADES GLANCE OFF. USE BLUNT FORCE." },
        .mesh = &crab_mesh, .max_hp = CRAB_HEALTH,
        .resist = { CRAB_RESIST_SLASH, CRAB_RESIST_BLUNT, CRAB_RESIST_PIERCE, CRAB_RESIST_FIRE, CRAB_RESIST_BLAST },
        .bar_height = 1.45f, .radius = CRAB_RADIUS, .scale = CRAB_SCALE, .xp = CRAB_XP,
        .hops = 0, .wanders = 1,
        .aggro_range = CRAB_AGGRO_RANGE, .move_speed = CRAB_SPEED, .wander_speed = CRAB_WANDER_SPEED, .hop_time = 0.55f,
        .attack_range = CRAB_ATTACK_RANGE, .windup = CRAB_WINDUP_TIME, .lunge_time = CRAB_LUNGE_TIME,
        .lunge_speed = CRAB_LUNGE_SPEED, .recover = CRAB_RECOVER_TIME, .stagger = CRAB_STAGGER_TIME,
        .damage = CRAB_DAMAGE, .hit_radius = CRAB_HIT_RADIUS,
        .preview_scale = 0.78f, .preview_cy = 0.30f, .preview_cz = 0.15f,
    },
    [ENEMY_WORM] = {
        .name = "CAVE WORM",
        .desc = { "A PALE CRAWLER. SLASHING SPLITS IT IN TWO.", "IT REARS UP BEFORE IT BITES." },
        .mesh = &worm_mesh, .max_hp = WORM_HEALTH,
        .resist = { WORM_RESIST_SLASH, WORM_RESIST_BLUNT, WORM_RESIST_PIERCE, WORM_RESIST_FIRE, WORM_RESIST_BLAST },
        .bar_height = 1.1f, .radius = WORM_RADIUS, .scale = WORM_SCALE, .xp = WORM_XP,
        .hops = 0, .wanders = 1, .splits = 1,
        .aggro_range = WORM_AGGRO_RANGE, .move_speed = WORM_SPEED, .wander_speed = WORM_WANDER_SPEED, .hop_time = 0.45f,
        .attack_range = WORM_ATTACK_RANGE, .windup = WORM_WINDUP_TIME, .lunge_time = WORM_LUNGE_TIME,
        .lunge_speed = WORM_LUNGE_SPEED, .recover = WORM_RECOVER_TIME, .stagger = WORM_STAGGER_TIME,
        .damage = WORM_DAMAGE, .hit_radius = WORM_HIT_RADIUS,
        .preview_scale = 0.62f, .preview_cy = 0.55f, .preview_cz = -0.80f,
    },
    [ENEMY_UNDEAD] = {
        .name = "RISEN SOLDIER",
        .desc = { "A RESTLESS SOLDIER OF BONE AND RUST.", "RAISES ITS SWORD HIGH, THEN CHOPS." },
        .mesh = &undead_mesh, .max_hp = UNDEAD_HEALTH,
        .resist = { UNDEAD_RESIST_SLASH, UNDEAD_RESIST_BLUNT, UNDEAD_RESIST_PIERCE, UNDEAD_RESIST_FIRE, UNDEAD_RESIST_BLAST },
        .bar_height = 2.15f, .radius = UNDEAD_RADIUS, .scale = 1.0f, .xp = UNDEAD_XP,
        .hops = 0, .wanders = 1,
        .aggro_range = UNDEAD_AGGRO_RANGE, .move_speed = UNDEAD_SPEED, .wander_speed = UNDEAD_WANDER_SPEED, .hop_time = 0.8f,
        .attack_range = UNDEAD_ATTACK_RANGE, .windup = UNDEAD_WINDUP_TIME, .lunge_time = UNDEAD_LUNGE_TIME,
        .lunge_speed = UNDEAD_LUNGE_SPEED, .recover = UNDEAD_RECOVER_TIME, .stagger = UNDEAD_STAGGER_TIME,
        .damage = UNDEAD_DAMAGE, .hit_radius = UNDEAD_HIT_RADIUS,
        .preview_scale = 0.62f, .preview_cy = 0.95f, .preview_cz = 0.0f,
        .limb = &undeadarm_mesh, .limb_x = 0.34f, .limb_y = 1.40f, .limb_rest = -50.0f,
    },
    [ENEMY_ZOMBIE] = {
        .name = "ZOMBIE",
        .desc = { "A SHAMBLING CORPSE. SLOW, BUT IT HITS HARD.", "BOTH ARMS GO UP - THEN THE SLAM COMES DOWN." },
        .mesh = &zombie_mesh, .max_hp = ZOMBIE_HEALTH,
        .resist = { ZOMBIE_RESIST_SLASH, ZOMBIE_RESIST_BLUNT, ZOMBIE_RESIST_PIERCE, ZOMBIE_RESIST_FIRE, ZOMBIE_RESIST_BLAST },
        .bar_height = 2.0f, .radius = ZOMBIE_RADIUS, .scale = 1.0f, .xp = ZOMBIE_XP,
        .hops = 0, .wanders = 1,
        .aggro_range = ZOMBIE_AGGRO_RANGE, .move_speed = ZOMBIE_SPEED, .wander_speed = ZOMBIE_WANDER_SPEED, .hop_time = 1.0f,
        .attack_range = ZOMBIE_ATTACK_RANGE, .windup = ZOMBIE_WINDUP_TIME, .lunge_time = ZOMBIE_LUNGE_TIME,
        .lunge_speed = ZOMBIE_LUNGE_SPEED, .recover = ZOMBIE_RECOVER_TIME, .stagger = ZOMBIE_STAGGER_TIME,
        .damage = ZOMBIE_DAMAGE, .hit_radius = ZOMBIE_HIT_RADIUS,
        .preview_scale = 0.62f, .preview_cy = 0.90f, .preview_cz = 0.0f,
        .limb = &zombiearms_mesh, .limb_x = 0.0f, .limb_y = 1.38f, .limb_rest = -80.0f,
    },
    [ENEMY_BRUTE] = {   // a mini boss: a huge zombie guarding the basalt mace. Only weak to piercing.
        .name = "CAVE BRUTE",
        .desc = { "A HULKING CORPSE GUARDING THE DEEP.", "SLOW AND HUGE. PIERCING HURTS IT MOST." },
        .mesh = &brute_mesh, .max_hp = 320.0f,
        .resist = { 0.8f, 1.0f, 1.5f, 1.0f, 1.0f },
        .bar_height = 3.2f, .radius = 0.85f, .scale = 1.5f, .xp = 120,
        .hops = 0, .wanders = 1,
        .aggro_range = 8.5f, .move_speed = 1.5f, .wander_speed = 0.6f, .hop_time = 1.1f,
        .attack_range = 3.0f, .windup = 1.2f, .lunge_time = 0.28f,
        .lunge_speed = 6.0f, .recover = 1.5f, .stagger = 0.15f,
        .damage = 55.0f, .hit_radius = 2.1f,
        .preview_scale = 0.42f, .preview_cy = 0.90f, .preview_cz = 0.0f,
        .limb = &brutearms_mesh, .limb_x = 0.0f, .limb_y = 1.38f, .limb_rest = -80.0f,
    },
    [ENEMY_WARDEN] = {   // a mini boss: a towering skeletal knight guarding the bone spear. Only weak to piercing.
        .name = "BONE WARDEN",
        .desc = { "AN ARMORED KNIGHT OF BONE. QUICK FOR ITS SIZE.", "BLADES SKIP OFF ITS RIBS. PIERCE THEM." },
        .mesh = &warden_mesh, .max_hp = 260.0f,
        .resist = { 0.6f, 1.0f, 1.8f, 1.0f, 1.0f },
        .bar_height = 3.0f, .radius = 0.7f, .scale = 1.4f, .xp = 140,
        .hops = 0, .wanders = 1,
        .aggro_range = 9.0f, .move_speed = 1.9f, .wander_speed = 0.8f, .hop_time = 0.8f,
        .attack_range = 3.0f, .windup = 0.9f, .lunge_time = 0.22f,
        .lunge_speed = 7.5f, .recover = 1.1f, .stagger = 0.15f,
        .damage = 60.0f, .hit_radius = 2.0f,
        .preview_scale = 0.44f, .preview_cy = 0.95f, .preview_cz = 0.0f,
        .limb = &wardenarms_mesh, .limb_x = 0.34f, .limb_y = 1.40f, .limb_rest = -50.0f,
    },
};

typedef enum { E_IDLE = 0, E_CHASE, E_WINDUP, E_LUNGE, E_RECOVER, E_STAGGER, E_DEAD } EnemyState;

typedef struct {
    int type;
    float spawn_x, spawn_z, spawn_yaw;
    float x, z, yaw, hp;
    int state;
    float state_t, hop;
    float lunge_x, lunge_z;
    int lunge_hit;
    float kb_x, kb_z;
    float wx, wz, wait;     // wandering: current target and pause timer
    int walking;            // moved this frame (drives the walk animation)
    int roam;               // 1 = labyrinth creature: roams the maze corridors and chases along them
    int story;              // bit set in story_kills when this one dies (1 = the rat, 2 = the crab)
    int xp;                 // xp override (0 = the type's default)
    float stuck;            // seconds spent walking toward the current roam target
    int gen;                // worms: how many times it has split (0 = full size)
    float maxhp;            // this one's health capacity (smaller for split worms)
    int zone;               // 0 = overworld, 1 = cave (only the zone you are in is simulated, drawn or hit)
    unsigned hit_id;        // the swing that last hit it (a swing hits each enemy once)
} Enemy;

#define MAX_ENEMIES 110
static Enemy enemies[MAX_ENEMIES] = {
    { .type = ENEMY_RAT,  .spawn_x = 22.5f, .spawn_z = 0.0f, .spawn_yaw = -PI_F / 2.0f, .story = 1 },
    { .type = ENEMY_CRAB, .spawn_x = 31.5f, .spawn_z = 1.0f, .spawn_yaw = PI_F, .story = 2 },
};
static int num_enemies = 2;
static int base_enemies = 0;   // enemies that exist at rest; split worms beyond this are discarded on rest

static const float worm_gen_scale[3] = { 1.0f, 0.75f, 0.58f };
static const float worm_gen_hp[3]    = { WORM_HEALTH, 24.0f, 13.0f };
static const int   worm_gen_xp[3]    = { WORM_XP, 4, 2 };
static float enemy_scale_k(const Enemy *e) { return e->type == ENEMY_WORM ? worm_gen_scale[e->gen] : 1.0f; }
static float enemy_radius(const Enemy *e) { return enemy_defs[e->type].radius * enemy_scale_k(e); }
#define NUM_ENEMIES num_enemies

static int bestiary_seen[ENEMY_TYPE_COUNT];

// ---- NPC dialogue (Dark Souls style: a box at the bottom, text typed out in chunks) ----
// The progress lives in these globals only: resting, dying (and, later, loading a save)
// never touch them, so once he's said his piece he only ever repeats the short line.
static const char *const npc_lines[] = {
    "Who me? I don't know what I'm doing here.",
    "What are you doing here? You don't know either?",
    "Well, this is a test room buddy.",
    "There's a rat behind the door.",
    "Go on, kill it.",
};
#define NPC_LINES ((int)(sizeof(npc_lines) / sizeof(npc_lines[0])))
static const char *const npc_repeat = "Go on buddy, get in there.";
static int   npc_line = 0;        // which chunk he's on
static int   npc_done = 0;        // 1 once the whole speech has been heard
static float dlg_chars = 0.0f;    // characters of the current chunk shown so far
static int   dlg_who = 0;         // 0 = the wanderer, 1 = the dying man in the cave
static int   cvn_line = 0, torch_just_given = 0;
static const char *const cvn_lines[] = {
    "...Someone. Please... come closer.",
    "The dark took the others. It is quiet down here... until it isn't.",
    "I won't see the sun again. But you might.",
    "Take my torch. It has a little fire left.",
    "It sits in the left hand. No spells while you hold it. Fire and fire don't share a hand.",
};
#define CVN_LINES ((int)(sizeof(cvn_lines) / sizeof(cvn_lines[0])))
static const char *const cvn_after = "Go on... light the way. Mind the stone things. They do not tire.";
static int   smith_line = 0;
static const char *const smith_lines[] = {
    "Mind the sparks. Hot iron does not care who is standing close.",
    "Steel remembers every blow that shaped it. Be like steel.",
    "I cannot forge for you yet. The fires are still being lit. Come back later.",
};
#define SMITH_LINES ((int)(sizeof(smith_lines) / sizeof(smith_lines[0])))
static float npc_yaw = NPC_REST_YAW;
static float g_time = 0.0f;       // seconds since start (for blinking HUD bits)

// Story progress (saved): bit 1 = the rat is dead, bit 2 = the crab is dead; has_key once he has handed it over.
static int story_kills = 0, has_key = 0, key_just_given = 0, npc_reward_line = 0;
static const char *const npc_reward[] = { "Oh... well okay.", "I guess you can have this." };
#define NPC_REWARD_LINES 2
static const char *const npc_after = "Look man, I didn't know about the crab. Sorry buddy.";
static int npc_story_done(void) { return (story_kills & 3) == 3; }

static const char *npc_text(void) {
    if (dlg_who == 2) return smith_lines[smith_line];
    if (dlg_who == 1) return has_torch ? cvn_after : cvn_lines[cvn_line];
    if (has_key) return npc_after;
    if (npc_story_done()) return npc_reward[npc_reward_line];
    return npc_done ? npc_repeat : npc_lines[npc_line];
}

// Is the chunk on screen the last one (so the prompt shows X instead of >)?
static int npc_last_chunk(void) {
    if (dlg_who == 2) return smith_line + 1 >= SMITH_LINES;
    if (dlg_who == 1) return has_torch || cvn_line + 1 >= CVN_LINES;
    if (has_key) return 1;
    if (npc_story_done()) return npc_reward_line + 1 >= NPC_REWARD_LINES;
    return npc_done || npc_line + 1 >= NPC_LINES;
}

// X pressed during dialogue: finish typing, else go to the next chunk. Returns 1 to close the box.
static int npc_advance(void) {
    int len = (int)strlen(npc_text());
    if (dlg_chars < (float)len) { dlg_chars = (float)len; return 0; }
    if (dlg_who == 2) {
        if (smith_line + 1 < SMITH_LINES) { smith_line++; dlg_chars = 0.0f; return 0; }
        return 1;
    }
    if (dlg_who == 1) {
        if (has_torch) return 1;
        if (cvn_line + 1 < CVN_LINES) { cvn_line++; dlg_chars = 0.0f; return 0; }
        has_torch = 1; left_hand = LH_TORCH; torch_just_given = 1;
        return 1;
    }
    if (has_key) return 1;
    if (npc_story_done()) {
        if (npc_reward_line + 1 < NPC_REWARD_LINES) { npc_reward_line++; dlg_chars = 0.0f; return 0; }
        has_key = 1;
        key_just_given = 1;
        return 1;
    }
    if (npc_done) return 1;
    if (npc_line + 1 < NPC_LINES) { npc_line++; dlg_chars = 0.0f; return 0; }
    npc_done = 1;
    return 1;
}

// ---- player survival state ----
static int   player_dead = 0;
static float death_t = 0.0f;
static float hurt_flash = 0.0f;
static float hot_name_t = 0.0f;   // the hot bar's item name shows for two seconds after you change it

// ---- camera (set each frame; used to project things onto the HUD) ----
static float g_cam_x = 0, g_cam_z = 0, g_cam_eye = 0, g_cam_yaw = 0, g_cam_pitch = 0, g_cam_roll = 0;

// 0 = outside, 1 = the rat room, 2 = the crab room, 3 = the labyrinth (thresholds sit on the wall centres so that
// standing in a doorway is never "outside").
static int room_of(float x, float z) {
    if (x > MZ_X0 && x < MZ_X1 && z > MZ_Z0 && z < MZ_Z1) return 3;   // inside the labyrinth
    if (z > ROOM_Z0 && z < ROOM_Z1) {
        if (x > ROOM2_X1) return 0;
        if (x > ROOM_X1) return 2;
        if (x > ROOM_X0) return 1;
    }
    return 0;
}

// Can something in room a see into room b? Same room, or neighbours with the door between open.
static int can_see(int a, int b) {
    if (a == b) return 1;
    if (a == 3 || b == 3) return 0;
    if (a - b == 1 || b - a == 1) return doors[a < b ? a : b].open_t > 0.5f;
    return 0;
}

static void damage_player(float amount) {
    if (player_dead) return;
    if (dodge_t >= 0.0f && dodge_t < DODGE_TIME * DODGE_IFRAME_FRAC) return;   // dodge i-frames
    amount *= 1.0f - armor_reduction();
    player_hp -= amount;
    hurt_flash = 0.4f;
    if (player_hp <= 0.0f) { player_hp = 0.0f; player_dead = 1; death_t = 0.0f; }
}

// World point -> screen pixels (same maths as the GL view + projection). 0 if behind the camera.
static int project_point(float wx, float wy, float wz, float *sx, float *sy) {
    float x = wx - g_cam_x, y = wy - g_cam_eye, z = wz - g_cam_z;
    float x1 = x * cosf(g_cam_yaw) - z * sinf(g_cam_yaw);
    float z1 = x * sinf(g_cam_yaw) + z * cosf(g_cam_yaw);
    float y2 = y * cosf(g_cam_pitch) + z1 * sinf(g_cam_pitch);
    float z2 = -y * sinf(g_cam_pitch) + z1 * cosf(g_cam_pitch);
    float x3 = x1 * cosf(g_cam_roll) - y2 * sinf(g_cam_roll);
    float y3 = x1 * sinf(g_cam_roll) + y2 * cosf(g_cam_roll);
    if (z2 > -0.2f) return 0;
    const float tv = 0.70020753f;   // tan(35 degrees)
    *sx = (x3 / (-z2 * tv * (960.0f / 544.0f)) + 1.0f) * 0.5f * 960.0f;
    *sy = (1.0f - y3 / (-z2 * tv)) * 0.5f * 544.0f;
    return 1;
}

static void reset_enemies(void) {
    if (base_enemies > 0) num_enemies = base_enemies;
    for (int i = 0; i < NUM_ENEMIES; i++) {
        Enemy *e = &enemies[i];
        e->x = e->spawn_x;
        e->z = e->spawn_z;
        e->yaw = e->spawn_yaw;
        e->hp = e->maxhp = enemy_defs[e->type].max_hp;
        e->gen = 0; e->xp = 0;
        e->state = E_IDLE;
        e->state_t = 0.0f;
        e->hop = 0.0f;
        e->hit_id = 0;
        e->lunge_hit = 0;
        e->kb_x = e->kb_z = 0.0f;
        e->wx = e->spawn_x; e->wz = e->spawn_z; e->wait = 0.5f + 0.7f * (float)i;
        e->walking = 0;
        e->stuck = 0.0f;
    }
}

// ---------------------------------------------------- xp / attributes ----
// Killing things gives XP. XP stays in your pocket until you spend it on a level at a beacon
// (and dying doesn't take it away). Each level you buy raises Health, Stamina or Strength.

static int xp = 0;               // XP you are carrying
static int lv_hp = 0, lv_stam = 0, lv_str = 0, lv_ath = 0;   // points bought in Health / Stamina / Strength / Athletics
static float play_time = 0.0f;   // seconds, shown on the save slots
static float xp_shown = 0.0f;    // the number on the HUD counter (counts up/down smoothly)
static float xp_pop = 0.0f;      // XP just gained, shown as "+N" until it merges into the counter
static float xp_pop_t = 0.0f;    // seconds until the "+N" starts merging

static int player_level(void) { return 1 + lv_hp + lv_stam + lv_str + lv_ath; }

// XP to go from `level` to level + 1: exponential.
static int level_cost(int level) {
    double c = (double)XP_BASE * pow((double)XP_GROWTH, (double)(level - 1));
    if (c > 9999999.0) c = 9999999.0;
    return (int)(c + 0.5);
}
static int levels_cost(int from_level, int n) {
    long long c = 0;
    for (int k = 0; k < n; k++) c += level_cost(from_level + k);
    return c > 2000000000LL ? 2000000000 : (int)c;
}

// Diminishing returns: every attribute point counts fully up to SOFTCAP_START, then each one is worth
// less and less (falling to SOFTCAP_SLOPE of a point by SOFTCAP_END), so stacking one stat to 99 is a poor deal.
static float attr_eff(int lv) {
    if (lv <= SOFTCAP_START) return (float)lv;
    float u = (float)(lv - SOFTCAP_START), span = (float)(SOFTCAP_END - SOFTCAP_START);
    float k = (1.0f - SOFTCAP_SLOPE) / span;
    if (u <= span) return (float)SOFTCAP_START + u - 0.5f * k * u * u;
    return (float)SOFTCAP_START + span - 0.5f * k * span * span + SOFTCAP_SLOPE * (u - span);
}
static float str_mult_for(int lv) { return 1.0f + STR_BONUS * attr_eff(lv); }
static float str_mult(void) { return str_mult_for(lv_str); }
static float weapon_damage(const ItemDef *d) { return d->damage * str_mult(); }
static float jump_height_for(int lv) { return JUMP_BASE + JUMP_PER_LEVEL * attr_eff(lv); }
static float jump_height(void) { return jump_height_for(lv_ath); }
static int attr_level(int i) { return i == 0 ? lv_hp : i == 1 ? lv_stam : i == 2 ? lv_str : lv_ath; }

static void recompute_stats(void) {
    player_max_hp   = MAX_HEALTH  + HP_PER_LEVEL   * attr_eff(lv_hp);
    player_max_stam = MAX_STAMINA + STAM_PER_LEVEL * attr_eff(lv_stam);
}

static void give_xp(int amount) {
    xp += amount;
    if (xp > 999999999) xp = 999999999;
    xp_pop += (float)amount;
    xp_pop_t = XP_POP_DELAY;
}

// Dark Souls style counter: "+N" sits beside the total, then pours into it.
static void update_xp_display(float dt) {
    if (xp_pop > 0.01f) {
        if (xp_pop_t > 0.0f) {
            xp_pop_t -= dt;
        } else {
            float rate = fmaxf(12.0f, xp_pop * 3.0f);
            float step = fminf(xp_pop, rate * dt);
            xp_pop -= step;
            xp_shown += step;
            if (xp_pop <= 0.01f) { xp_pop = 0.0f; xp_shown = (float)xp; }
        }
    } else {
        xp_pop = 0.0f;
        float diff = (float)xp - xp_shown;
        if (fabsf(diff) < 0.5f) xp_shown = (float)xp;
        else xp_shown += diff * fminf(1.0f, 10.0f * dt);
    }
}

// Buys h + s + st + a levels (Health / Stamina / Strength / Athletics) if you can afford them. Returns 1 on success.
static int commit_levels(int h, int s, int st, int a) {
    int n = h + s + st + a;
    if (n <= 0) return 0;
    int cost = levels_cost(player_level(), n);
    if (cost > xp) return 0;
    float oh = player_max_hp, os = player_max_stam;
    xp -= cost;
    lv_hp += h; lv_stam += s; lv_str += st; lv_ath += a;
    recompute_stats();
    player_hp   += player_max_hp   - oh;   // the new capacity arrives full
    player_stam += player_max_stam - os;
    return 1;
}

// Resting at the beacon: heals you, respawns enemies, shuts the door. Items are kept.
static void do_rest(void) {
    player_hp = player_max_hp;
    player_stam = player_max_stam;
    stam_delay = 0.0f;
    dodge_t = -1.0f;
    attack_t = -1.0f;
    dummy_wobble = -1.0f;
    cast_t = -1.0f;
    use_t = -1.0f;
    for (int i = 0; i < MAX_PROJ; i++) projs[i].on = 0;
    reset_enemies();
    for (int i = 0; i < NUM_DOORS; i++) doors[i].target = 0;   // the doors swing shut again
}

// ------------------------------------------------------------ saving ----
typedef enum { SCREEN_TITLE = 0, SCREEN_GAME } ScreenId;
static int screen = SCREEN_TITLE;
static int title_sel = 0, title_confirm = 0, cur_slot = 0;

#define SAVE_MAGIC 0x33574C50u   // "PLW3"
typedef struct {
    unsigned magic;
    int xp, lv_hp, lv_stam, lv_str;
    int inv_n, inv[8], quick[QUICK_SLOTS], active_quick;   // (inventory grew past 8: the rest is inv2, below)
    int pickup_taken[16];
    int npc_done, npc_line;      // the wanderer's dialogue is part of the save
    int bestiary_seen[8];
    float play_time;
    // added later: older saves are shorter, and read back with these as zero
    int lv_ath, has_key, story_kills, has_fire, armor[ARMOR_SLOTS];
    int inv2[8];
    int left_hand, has_torch, cons_count[3], hot_p1[3], active_hot;
    int pickup_taken2[24];
} SaveData;
#define SAVE_OLD_SIZE ((size_t)offsetof(SaveData, lv_ath))
_Static_assert(sizeof(pickups) / sizeof(pickups[0]) <= 40, "save: too many pickups");
_Static_assert(ENEMY_TYPE_COUNT <= 8, "save: too many enemy types");

static SaveData slot_info[NUM_SLOTS];
static int      slot_ok[NUM_SLOTS];

static void save_path(int slot, char *buf, size_t n) { snprintf(buf, n, SAVE_DIR "/save%d.dat", slot + 1); }

static int read_save(int slot, SaveData *out) {
    char path[128];
    save_path(slot, path, sizeof(path));
    FILE *f = fopen(path, "rb");
    if (!f) return 0;
    memset(out, 0, sizeof(*out));
    size_t got = fread(out, 1, sizeof(*out), f);
    int ok = got >= SAVE_OLD_SIZE && out->magic == SAVE_MAGIC;
    fclose(f);
    return ok;
}

static int write_save(int slot) {
    SaveData d;
    memset(&d, 0, sizeof(d));
    d.magic = SAVE_MAGIC;
    d.xp = xp;
    d.lv_hp = lv_hp; d.lv_stam = lv_stam; d.lv_str = lv_str; d.lv_ath = lv_ath;
    d.has_key = has_key; d.story_kills = story_kills;
    d.inv_n = inv_n;
    for (int i = 0; i < INV_MAX; i++) { if (i < 8) d.inv[i] = inv[i]; else d.inv2[i - 8] = inv[i]; }
    d.has_fire = has_fire;
    for (int i = 0; i < ARMOR_SLOTS; i++) d.armor[i] = armor[i];
    for (int i = 0; i < QUICK_SLOTS; i++) d.quick[i] = quick[i];
    d.active_quick = active_quick;
    for (int i = 0; i < NUM_PICKUPS; i++) { if (i < 16) d.pickup_taken[i] = pickups[i].taken; else d.pickup_taken2[i - 16] = pickups[i].taken; }
    d.left_hand = left_hand; d.has_torch = has_torch; d.active_hot = active_hot;
    for (int i = 0; i < 3; i++) { d.cons_count[i] = cons_count[i]; d.hot_p1[i] = hot[i] + 1; }
    d.npc_done = npc_done; d.npc_line = npc_line;
    for (int i = 0; i < ENEMY_TYPE_COUNT; i++) d.bestiary_seen[i] = bestiary_seen[i];
    d.play_time = play_time;

    mkdir(SAVE_DIR, 0777);
    char path[128];
    save_path(slot, path, sizeof(path));
    FILE *f = fopen(path, "wb");
    if (!f) return 0;
    int ok = fwrite(&d, sizeof(d), 1, f) == 1;
    if (fflush(f) != 0) ok = 0;
    if (fclose(f) != 0) ok = 0;   // make sure it is really on the memory card
    if (ok) { slot_info[slot] = d; slot_ok[slot] = 1; }
    return ok;
}

static void delete_save(int slot) {
    char path[128];
    save_path(slot, path, sizeof(path));
    remove(path);
    slot_ok[slot] = 0;
}

static void refresh_slots(void) {
    for (int i = 0; i < NUM_SLOTS; i++) slot_ok[i] = read_save(i, &slot_info[i]);
}

static void new_game_state(void) {
    xp = 0; xp_shown = 0.0f; xp_pop = 0.0f; xp_pop_t = 0.0f;
    lv_hp = lv_stam = lv_str = lv_ath = 0;
    story_kills = 0; has_key = 0; key_just_given = 0; npc_reward_line = 0;
    has_fire = 0; cast_t = -1.0f;
    for (int i = 0; i < ARMOR_SLOTS; i++) armor[i] = -1;
    for (int i = 0; i < MAX_PROJ; i++) projs[i].on = 0;
    play_time = 0.0f;
    inv_n = 0; inv_sel = 0;
    for (int i = 0; i < QUICK_SLOTS; i++) quick[i] = -1;
    active_quick = 0; swap_t = -1.0f;
    for (int i = 0; i < NUM_PICKUPS; i++) pickups[i].taken = 0;
    npc_done = 0; npc_line = 0; dlg_chars = 0.0f;
    for (int i = 0; i < ENEMY_TYPE_COUNT; i++) bestiary_seen[i] = 0;
    dummy_hits = 0;
    left_hand = LH_NONE; has_torch = 0; active_hot = 0; use_t = -1.0f;
    set_zone(0); fade_state = 0; fade_t = fade_a = 0.0f; cvn_line = 0; dlg_who = 0;
    for (int i = 0; i < 3; i++) { cons_count[i] = 0; hot[i] = -1; }
    player_dead = 0; hurt_flash = 0.0f;
    recompute_stats();
    do_rest();
    for (int i = 0; i < NUM_DOORS; i++) doors[i].open_t = 0.0f;
    menu = MENU_NONE;
}

static void apply_save(const SaveData *d) {
    new_game_state();
    xp = d->xp; xp_shown = (float)xp;
    lv_hp = d->lv_hp; lv_stam = d->lv_stam; lv_str = d->lv_str; lv_ath = d->lv_ath;
    has_key = d->has_key ? 1 : 0; story_kills = d->story_kills & 3;
    inv_n = d->inv_n < 0 ? 0 : (d->inv_n > INV_MAX ? INV_MAX : d->inv_n);
    for (int i = 0; i < inv_n; i++) {
        int id = i < 8 ? d->inv[i] : d->inv2[i - 8];
        inv[i] = (id >= 0 && id < ITEM_COUNT) ? id : 0;
    }
    for (int i = 0; i < QUICK_SLOTS; i++) {   // only keep weapons you actually own
        int id = d->quick[i], owned = 0;
        for (int k = 0; k < inv_n; k++) if (inv[k] == id) owned = 1;
        quick[i] = (id >= 0 && id < ITEM_COUNT && owned) ? id : -1;
    }
    has_fire = d->has_fire ? 1 : 0;
    for (int i = 0; i < ARMOR_SLOTS; i++) {   // worn armor must be the right kind and actually owned
        int id = d->armor[i], owned = 0;
        for (int k = 0; k < inv_n; k++) if (inv[k] == id) owned = 1;
        armor[i] = (id >= 0 && id < ITEM_COUNT && owned && item_defs[id].kind == i + 1) ? id : -1;
    }
    active_quick = (d->active_quick >= 0 && d->active_quick < QUICK_SLOTS) ? d->active_quick : 0;
    for (int i = 0; i < NUM_PICKUPS; i++) pickups[i].taken = i < 16 ? d->pickup_taken[i] : d->pickup_taken2[i - 16];
    has_torch = d->has_torch ? 1 : 0;
    left_hand = (d->left_hand == LH_TORCH && has_torch) ? LH_TORCH : (d->left_hand == LH_FIRE && has_fire ? LH_FIRE : LH_NONE);
    for (int i = 0; i < 3; i++) {
        cons_count[i] = d->cons_count[i] < 0 ? 0 : (d->cons_count[i] > CONS_MAX ? CONS_MAX : d->cons_count[i]);
        hot[i] = (d->hot_p1[i] >= 1 && d->hot_p1[i] <= 3) ? d->hot_p1[i] - 1 : -1;
    }
    active_hot = (d->active_hot >= 0 && d->active_hot < 3) ? d->active_hot : 0;
    npc_done = d->npc_done ? 1 : 0;
    npc_line = (d->npc_line >= 0 && d->npc_line < NPC_LINES) ? d->npc_line : 0;
    for (int i = 0; i < ENEMY_TYPE_COUNT; i++) bestiary_seen[i] = d->bestiary_seen[i];
    play_time = d->play_time;
    recompute_stats();
    do_rest();   // full health, enemies back, doors shut
    for (int i = 0; i < NUM_DOORS; i++) doors[i].open_t = 0.0f;
}

// A slashing hit on a worm splits it: it shrinks and a second one appears beside it.
static void split_worm(Enemy *e, float kx, float kz) {
    if (e->gen >= WORM_MAX_SPLITS || num_enemies >= MAX_ENEMIES) return;
    e->gen++;
    e->maxhp = worm_gen_hp[e->gen];
    e->hp = e->maxhp;
    e->xp = worm_gen_xp[e->gen];
    Enemy *n = &enemies[num_enemies++];
    *n = *e;
    float sx = -kz, sz = kx;   // sideways of the blow
    e->x += sx * 0.55f; e->z += sz * 0.55f;
    n->x -= sx * 0.55f; n->z -= sz * 0.55f;
    n->kb_x = -sx; n->kb_z = -sz;
    e->kb_x = sx; e->kb_z = sz;
    n->state = E_STAGGER; n->state_t = 0.0f;
}

// Deal damage of a given type to an enemy (the type decides weak / resistant / immune). Handles knock-back,
// the worm's splitting and the XP reward. Returns the damage dealt.
static float damage_enemy(Enemy *e, DamageType t, float raw, float fromx, float fromz, int stun) {
    const EnemyDef *d = &enemy_defs[e->type];
    float dmg = raw * d->resist[t];
    e->hp -= dmg;
    bestiary_seen[e->type] = 1;
    float dx = e->x - fromx, dz = e->z - fromz, l = sqrtf(dx * dx + dz * dz);
    float kx = 0.0f, kz = 1.0f;
    if (l > 1e-4f) { kx = dx / l; kz = dz / l; e->kb_x = kx; e->kb_z = kz; }
    if (e->hp <= 0.0f || stun) e->state_t = 0.0f;
    if (e->hp <= 0.0f) {
        e->hp = 0.0f;
        e->state = E_DEAD;
        give_xp(e->xp ? e->xp : d->xp);
        story_kills |= e->story;
    } else {
        if (stun) e->state = E_STAGGER;   // only heavy blows (mace, bombs) interrupt what it was doing
        if (d->splits && t == DMG_SLASH) split_worm(e, kx, kz);
    }
    return dmg;
}

// Weapon matchups: a mace is poor against things that only fear piercing; a spear is poor against anything that does not.
static float hit_enemy(Enemy *e, const ItemDef *wd, float px, float pz) {
    const EnemyDef *d = &enemy_defs[e->type];
    float m = 1.0f;
    if (wd->dmg_type == DMG_BLUNT && d->resist[DMG_PIERCE] > 1.05f && d->resist[DMG_BLUNT] <= 1.05f) m = 0.7f;
    if (wd->swing == &spear_swing && d->resist[DMG_PIERCE] <= 1.0f) m = 0.75f;
    return damage_enemy(e, wd->dmg_type, weapon_damage(wd) * m, px, pz, wd->dmg_type == DMG_BLUNT);
}

// Does the weapon's blade / head touch a circle (tx, tz, tr) at swing progress u?  Slashes sweep an arc, a mace smashes
// forward and a spear thrusts: each is a fat line segment from the player, so you must be in the right place at the right time.
static int weapon_touches(const ItemDef *wd, float ox, float oz, float fx, float fz, float sx, float sz,
                          float u, float tx, float tz, float tr) {
    float w = (u - wd->hit_start) / (wd->hit_end - wd->hit_start);
    if (w < 0.0f) w = 0.0f;
    if (w > 1.0f) w = 1.0f;
    float ang = 0.0f, len, width;
    if (wd->swing == &spear_swing)      { len = wd->range * (0.5f + 0.5f * w); width = 0.16f; }
    else if (wd->swing == &mace_swing)  { len = wd->range * (0.55f + 0.45f * w); width = 0.42f; }
    else {
        float A = wd->arc_deg < 55.0f ? wd->arc_deg : 55.0f;
        ang = (-A + 2.0f * A * w) * PI_F / 180.0f;
        len = wd->range; width = 0.30f;
    }
    float dx = fx * cosf(ang) + sx * sinf(ang), dz = fz * cosf(ang) + sz * sinf(ang);
    float t0 = 0.25f;
    float ax = ox + dx * t0, az = oz + dz * t0;
    float bx = dx * (len - t0), bz = dz * (len - t0);
    float cx = tx - ax, cz = tz - az;
    float bl = bx * bx + bz * bz;
    float t = bl > 1e-6f ? (cx * bx + cz * bz) / bl : 0.0f;
    if (t < 0.0f) t = 0.0f;
    if (t > 1.0f) t = 1.0f;
    float qx = cx - bx * t, qz = cz - bz * t;
    float rr = tr + width;
    return qx * qx + qz * qz <= rr * rr;
}

// ---- effects: sparks, embers and explosions ----
typedef struct { float x, y, z, vx, vy, vz, life, max, size; int kind; int on; } Particle;   // kind 0 = spark, 1 = ember
#define MAX_PART 220
static Particle parts[MAX_PART];
static int part_next = 0;
typedef struct { float x, y, z, t, dur, size; int on; } Boom;
#define MAX_BOOM 8
static Boom booms[MAX_BOOM];
static unsigned fx_state = 0x1234ABCDu;
static float fx_rnd(void) {
    fx_state ^= fx_state << 13; fx_state ^= fx_state >> 17; fx_state ^= fx_state << 5;
    return (float)(fx_state & 0xFFFFFF) / 16777216.0f;
}

static void spawn_part(float x, float y, float z, float vx, float vy, float vz, float life, float size, int kind) {
    Particle *q = &parts[part_next];
    part_next = (part_next + 1) % MAX_PART;
    *q = (Particle){ x, y, z, vx, vy, vz, life, life, size, kind, 1 };
}

// Sparks fly out of a hit wall, back along its surface normal (nx, nz).
static void spawn_sparks(float x, float y, float z, float nx, float nz, int n) {
    for (int i = 0; i < n; i++) {
        float sp = 1.0f + fx_rnd() * 2.6f;
        spawn_part(x, y + (fx_rnd() - 0.5f) * 0.1f, z, nx * sp + (fx_rnd() - 0.5f) * 2.0f, 0.4f + fx_rnd() * 2.0f,
                   nz * sp + (fx_rnd() - 0.5f) * 2.0f, 0.2f + fx_rnd() * 0.22f, 0.016f + fx_rnd() * 0.016f, 0);
    }
}

// A ball of fire that swells, then shrinks away, throwing embers.
static void spawn_explosion(float x, float y, float z, float size, int embers) {
    for (int i = 0; i < MAX_BOOM; i++) {
        if (booms[i].on) continue;
        booms[i] = (Boom){ x, y, z, 0.0f, 0.32f + 0.10f * size, size, 1 };
        break;
    }
    for (int i = 0; i < embers; i++) {
        float a = fx_rnd() * 2.0f * PI_F, sp = (1.5f + fx_rnd() * 4.5f) * (0.6f + 0.4f * size);
        spawn_part(x, y, z, cosf(a) * sp, 1.0f + fx_rnd() * 4.5f * (0.6f + 0.4f * size), sinf(a) * sp,
                   0.35f + fx_rnd() * 0.55f, (0.07f + fx_rnd() * 0.08f) * (0.7f + 0.3f * size), (fx_rnd() < 0.7f) ? 1 : 0);
    }
}

static void update_fx(float dt) {
    for (int i = 0; i < MAX_PART; i++) {
        Particle *q = &parts[i];
        if (!q->on) continue;
        q->life -= dt;
        if (q->life <= 0.0f) { q->on = 0; continue; }
        q->vy -= 9.0f * dt;
        q->x += q->vx * dt; q->y += q->vy * dt; q->z += q->vz * dt;
        if (q->y < 0.03f) { q->y = 0.03f; q->vy = -q->vy * 0.3f; q->vx *= 0.6f; q->vz *= 0.6f; }
    }
    for (int i = 0; i < MAX_BOOM; i++) {
        if (!booms[i].on) continue;
        booms[i].t += dt;
        if (booms[i].t >= booms[i].dur) booms[i].on = 0;
    }
}

static void dummy_hit(DamageType t, float amp) {
    dummy_hits++;
    dummy_wobble = 0.0f;
    dummy_hit_type = t;
    dummy_hit_amp = amp;
    give_xp(DUMMY_XP);   // testing aid
}

// ---- bombs: thrown with SQUARE, they burst on whatever they hit ----
typedef struct { float x, y, z, vx, vy, vz, spin, life; int on; } Bomb;
#define MAX_BOMB 4
static Bomb bombs[MAX_BOMB];

static void throw_bomb(float x, float y, float z, float dx, float dz) {
    for (int i = 0; i < MAX_BOMB; i++) {
        if (bombs[i].on) continue;
        bombs[i] = (Bomb){ x, y, z, dx * BOMB_SPEED, BOMB_LOFT, dz * BOMB_SPEED, 0.0f, 0.0f, 1 };
        return;
    }
}

// Blast damage in a radius (falling off toward the edge) plus the fireball of the explosion itself.
static void explode(float x, float y, float z) {
    spawn_explosion(x, y, z, 2.6f, 46);
    int n0 = NUM_ENEMIES;
    for (int i = 0; i < n0; i++) {
        Enemy *e = &enemies[i];
        if (e->state == E_DEAD || e->zone != zone) continue;
        float dx = e->x - x, dz = e->z - z, d = sqrtf(dx * dx + dz * dz) - enemy_radius(e);
        if (d < BOMB_RADIUS && y < 3.0f) {
            if (d < 0.0f) d = 0.0f;
            damage_enemy(e, DMG_BLAST, BOMB_DAMAGE * (1.0f - 0.5f * d / BOMB_RADIUS), x, z, 1);
        }
    }
    if (zone == 0) {
        float dx = DUMMY_X - x, dz = DUMMY_Z - z;
        if (sqrtf(dx * dx + dz * dz) < BOMB_RADIUS + 0.4f) dummy_hit(DMG_BLAST, 55.0f);
    }
}

static void update_bombs(float dt) {
    for (int i = 0; i < MAX_BOMB; i++) {
        Bomb *b = &bombs[i];
        if (!b->on) continue;
        b->life += dt;
        b->spin += dt * 540.0f;
        const int steps = 3;
        for (int st = 0; st < steps && b->on; st++) {
            float h = dt / (float)steps;
            float ox = b->x, oy = b->y, oz = b->z;
            b->vy -= BOMB_GRAVITY * h;
            b->x += b->vx * h; b->y += b->vy * h; b->z += b->vz * h;
            int hit = 0;
            if (b->life > 3.5f) hit = 1;
            if (b->y <= floor_at(b->x, b->z, b->y) + 0.12f && b->vy < 0.0f) hit = 1;
            for (int k = zw0; k < zw1 && !hit; k++) {
                const wall_t *w = &walls[k];
                if (w->on && b->x > w->x0 - 0.1f && b->x < w->x1 + 0.1f && b->z > w->z0 - 0.1f && b->z < w->z1 + 0.1f &&
                    b->y < (zone ? CV_CEIL : 3.6f)) hit = 1;
            }
            for (int k = zc0; k < zc1 && !hit; k++) {
                float cx = b->x - colliders[k].x, cz = b->z - colliders[k].z, rr = colliders[k].r + 0.15f;
                if (cx * cx + cz * cz < rr * rr && b->y < 2.6f) hit = 1;
            }
            for (int k = 0; k < NUM_ENEMIES && !hit; k++) {
                const Enemy *e = &enemies[k];
                if (e->state == E_DEAD || e->zone != zone) continue;
                float cx = b->x - e->x, cz = b->z - e->z, rr = enemy_radius(e) + 0.3f;
                if (cx * cx + cz * cz < rr * rr && b->y < 2.3f) hit = 1;
            }
            if (hit) {
                b->on = 0;
                explode(ox, fmaxf(oy, 0.3f), oz);
            }
        }
    }
}

// ---- fireballs ----

static void spawn_fireball(float x, float y, float z, float dx, float dz) {
    for (int i = 0; i < MAX_PROJ; i++) {
        if (projs[i].on) continue;
        projs[i] = (Proj){ x, y, z, dx, dz, 0.0f, 1 };
        return;
    }
}

static void update_projectiles(float dt) {
    for (int i = 0; i < MAX_PROJ; i++) {
        Proj *p = &projs[i];
        if (!p->on) continue;
        float step = FIRE_SPEED * dt;
        p->x += p->dx * step; p->z += p->dz * step; p->dist += step;
        int hit = 0;
        if (p->dist > FIRE_RANGE) { p->on = 0; spawn_explosion(p->x, p->y, p->z, 0.6f, 6); continue; }
        for (int k = zw0; k < zw1 && !hit; k++) {
            const wall_t *w = &walls[k];
            if (w->on && p->x > w->x0 - 0.1f && p->x < w->x1 + 0.1f && p->z > w->z0 - 0.1f && p->z < w->z1 + 0.1f) hit = 1;
        }
        for (int k = zc0; k < zc1 && !hit; k++) {
            float cx = p->x - colliders[k].x, cz = p->z - colliders[k].z;
            if (cx * cx + cz * cz < (colliders[k].r + 0.1f) * (colliders[k].r + 0.1f)) {
                hit = 1;
                if (zone == 0) {
                    float dx = p->x - DUMMY_X, dz = p->z - DUMMY_Z;
                    if (dx * dx + dz * dz < 0.9f * 0.9f) dummy_hit(DMG_FIRE, 30.0f);
                }
            }
        }
        int n0 = NUM_ENEMIES;
        for (int k = 0; k < n0 && !hit; k++) {
            Enemy *e = &enemies[k];
            if (e->state == E_DEAD || e->zone != zone) continue;
            float cx = p->x - e->x, cz = p->z - e->z, rr = enemy_radius(e) + 0.35f;
            if (cx * cx + cz * cz < rr * rr) {
                damage_enemy(e, DMG_FIRE, FIRE_DAMAGE, p->x - p->dx, p->z - p->dz, 0);
                hit = 1;
            }
        }
        if (hit) {   // burst in a fireball, slightly in front of the wall
            p->on = 0;
            spawn_explosion(p->x - p->dx * 0.2f, p->y, p->z - p->dz * 0.2f, 1.1f, 20);
        }
    }
}

static unsigned rng_state = 2463534242u;
static float rnd01(void) {   // tiny xorshift, 0..1
    rng_state ^= rng_state << 13; rng_state ^= rng_state >> 17; rng_state ^= rng_state << 5;
    return (float)(rng_state & 0xFFFFFF) / 16777216.0f;
}

// Turn `yaw` toward `target` by at most `rate * dt` radians.
static void turn_toward(float *yaw, float target, float maxstep) {
    float diff = target - *yaw;
    while (diff >  PI_F) diff -= 2.0f * PI_F;
    while (diff < -PI_F) diff += 2.0f * PI_F;
    if (diff >  maxstep) diff =  maxstep;
    if (diff < -maxstep) diff = -maxstep;
    *yaw += diff;
}

// ---- labyrinth navigation: creatures move cell centre to cell centre along the open passages ----
static int maze_cell(float x, float z, int *c, int *r) {
    float fx = (x - MZ_X0) / MZ_CELL, fz = (z - MZ_Z0) / MZ_CELL;
    if (fx < 0.0f || fz < 0.0f || fx >= (float)MZ_COLS || fz >= (float)MZ_ROWS) return 0;
    *c = (int)fx; *r = (int)fz;
    return 1;
}
static void maze_center(int c, int r, float *x, float *z) {
    *x = MZ_X0 + ((float)c + 0.5f) * MZ_CELL;
    *z = MZ_Z0 + ((float)r + 0.5f) * MZ_CELL;
}
// Distance (in cells) from every cell to (tc, tr).
static void maze_dist(int tc, int tr, int dist[MZ_ROWS][MZ_COLS]) {
    int qc[MZ_ROWS * MZ_COLS], qr[MZ_ROWS * MZ_COLS], h = 0, t = 0;
    for (int r = 0; r < MZ_ROWS; r++) for (int c = 0; c < MZ_COLS; c++) dist[r][c] = -1;
    dist[tr][tc] = 0; qc[t] = tc; qr[t] = tr; t++;
    while (h < t) {
        int c = qc[h], r = qr[h]; h++;
        for (int k = 0; k < 4; k++) {
            if (!(maze_open[r][c] & (1 << k))) continue;
            int nc = c + mz_dc[k], nr = r + mz_dr[k];
            if (nc < 0 || nc >= MZ_COLS || nr < 0 || nr >= MZ_ROWS || dist[nr][nc] >= 0) continue;
            dist[nr][nc] = dist[r][c] + 1;
            qc[t] = nc; qr[t] = nr; t++;
        }
    }
}
// Next cell on the shortest path from (ec, er) to (tc, tr). Returns the path length in cells.
static int maze_step(int ec, int er, int tc, int tr, int *nc, int *nr) {
    int dist[MZ_ROWS][MZ_COLS];
    maze_dist(tc, tr, dist);
    int d = dist[er][ec];
    *nc = ec; *nr = er;
    if (d <= 0) return 0;
    for (int k = 0; k < 4; k++) {
        if (!(maze_open[er][ec] & (1 << k))) continue;
        int cc = ec + mz_dc[k], rr = er + mz_dr[k];
        if (cc >= 0 && cc < MZ_COLS && rr >= 0 && rr < MZ_ROWS && dist[rr][cc] == d - 1) { *nc = cc; *nr = rr; break; }
    }
    return d;
}
static void roam_pick(Enemy *e) {
    int c, r;
    e->stuck = 0.0f;
    if (!maze_cell(e->x, e->z, &c, &r)) { e->wx = e->spawn_x; e->wz = e->spawn_z; return; }
    int opts[4], n = 0;
    for (int k = 0; k < 4; k++) if (maze_open[r][c] & (1 << k)) opts[n++] = k;
    if (n == 0) { maze_center(c, r, &e->wx, &e->wz); return; }
    int k = opts[(int)(rnd01() * (float)n) % n];
    maze_center(c + mz_dc[k], r + mz_dr[k], &e->wx, &e->wz);
}
// Walk (or hop) toward a point.
static void enemy_step(Enemy *e, const EnemyDef *d, float tx, float tz, float speed, float dt) {
    float wx = tx - e->x, wz = tz - e->z, wd = sqrtf(wx * wx + wz * wz);
    if (wd < 1e-4f) return;
    if (d->hops) {
        e->yaw = atan2f(wx, wz);
        e->hop += dt / d->hop_time;
        float f = e->hop - floorf(e->hop);
        if (f < 0.65f && wd > 0.1f) { e->x += wx / wd * speed * dt; e->z += wz / wd * speed * dt; e->walking = 1; }
    } else {
        turn_toward(&e->yaw, atan2f(wx, wz), 5.0f * dt);
        e->x += wx / wd * speed * dt;
        e->z += wz / wd * speed * dt;
        e->walking = 1;
        e->hop += dt / d->hop_time;
    }
}

static void add_maze_enemy(int type, int c, int r, float ox, float oz, int xpv) {
    if (num_enemies >= MAX_ENEMIES) return;
    Enemy *e = &enemies[num_enemies];
    memset(e, 0, sizeof(*e));
    float x, z;
    maze_center(c, r, &x, &z);
    e->type = type; e->spawn_x = x + ox; e->spawn_z = z + oz;
    e->spawn_yaw = (float)(num_enemies * 2);
    e->roam = 1; e->xp = xpv;
    num_enemies++;
}

// A mix of everything: singles, pairs and mixed groups spread through the maze. They all give their normal XP.
static void spawn_maze_enemies(void) {
    add_maze_enemy(ENEMY_RAT,    2, 1, -0.6f,  0.4f, 0);
    add_maze_enemy(ENEMY_RAT,    2, 1,  0.6f, -0.4f, 0);
    add_maze_enemy(ENEMY_CRAB,   5, 0,  0.0f,  0.0f, 0);
    add_maze_enemy(ENEMY_RAT,    4, 2, -0.6f,  0.5f, 0);
    add_maze_enemy(ENEMY_WORM,   4, 2,  0.5f, -0.4f, 0);
    add_maze_enemy(ENEMY_UNDEAD, 3, 3,  0.0f,  0.0f, 0);
    add_maze_enemy(ENEMY_UNDEAD, 2, 4,  0.0f,  0.0f, 0);
    add_maze_enemy(ENEMY_WORM,   6, 3,  0.0f,  0.0f, 0);
    add_maze_enemy(ENEMY_CRAB,   1, 6,  0.0f,  0.0f, 0);
    add_maze_enemy(ENEMY_WORM,   4, 5, -0.6f,  0.4f, 0);
    add_maze_enemy(ENEMY_WORM,   4, 5,  0.6f, -0.4f, 0);
    add_maze_enemy(ENEMY_CRAB,   6, 6, -0.5f,  0.0f, 0);
    add_maze_enemy(ENEMY_UNDEAD, 6, 6,  0.5f,  0.0f, 0);
    add_maze_enemy(ENEMY_RAT,    3, 7, -0.6f,  0.4f, 0);
    add_maze_enemy(ENEMY_WORM,   3, 7,  0.6f, -0.4f, 0);
    add_maze_enemy(ENEMY_WORM,   1, 8,  0.0f,  0.0f, 0);
    add_maze_enemy(ENEMY_UNDEAD, 5, 8, -0.5f,  0.0f, 0);   // these two guard the fire tome in the far corner
    add_maze_enemy(ENEMY_UNDEAD, 5, 8,  0.5f,  0.0f, 0);
    base_enemies = num_enemies;
}

// The labyrinth's three supply chests go in its dead ends, farthest from the entrance first (not the tome's corner).
static void place_maze_pickups(void) {
    int dist[MZ_ROWS][MZ_COLS];
    int er = (int)((MZ_DOOR_Z - MZ_Z0) / MZ_CELL);
    if (er < 0) er = 0;
    if (er >= MZ_ROWS) er = MZ_ROWS - 1;
    maze_dist(0, er, dist);
    int used = 0;
    for (int slot = 0; slot < 3; slot++) {
        int bc = -1, br = -1, bd = -1;
        for (int r = 0; r < MZ_ROWS; r++) for (int c = 0; c < MZ_COLS; c++) {
            int bits = maze_open[r][c] & 15, n = (bits & 1) + ((bits >> 1) & 1) + ((bits >> 2) & 1) + ((bits >> 3) & 1);
            if (n != 1 || dist[r][c] < 0) continue;
            if (c == MZ_COLS - 1 && r == MZ_ROWS - 1) continue;          // the tome
            if (r == MZ_PORTAL_ROW && c == MZ_COLS - 1) continue;        // the cave door
            if (used & (1 << (r * MZ_COLS + c) % 30) && 0) continue;
            int taken = 0;
            for (int k = 0; k < slot; k++) {
                float x, z;
                maze_center(c, r, &x, &z);
                if (fabsf(pickups[PK_MAZE0 + k].x - x) < 0.1f && fabsf(pickups[PK_MAZE0 + k].z - z) < 0.1f) taken = 1;
            }
            if (taken) continue;
            if (dist[r][c] > bd) { bd = dist[r][c]; bc = c; br = r; }
        }
        if (bc < 0) { bc = 1 + slot; br = 0; }
        maze_center(bc, br, &pickups[PK_MAZE0 + slot].x, &pickups[PK_MAZE0 + slot].z);
    }
    (void)used;
}

// ------------------------------------------------------------------ the cave ----
// A second zone, built far from the overworld. A 40x40 grid of 2.4-unit cells: chambers joined by winding tunnels,
// extra loops (so the way is a little confusing), dead-end spurs (where the chests hide), stalagmites and stalactites.
static unsigned char cv_open[CV_H][CV_W];
static int cv_dist[CV_H][CV_W];      // path length (in cells) to the player's cell, refreshed each frame
static int cv_edist[CV_H][CV_W];     // path length to the entrance, used for placing things
static unsigned cv_rng = 0xA5C3E1F7u;
static unsigned cv_rand(void) { cv_rng ^= cv_rng << 13; cv_rng ^= cv_rng >> 17; cv_rng ^= cv_rng << 5; return cv_rng; }
static int cv_rn(int n) { return (int)(cv_rand() % (unsigned)n); }
typedef struct { int x0, y0, w, h; } CvRoom;
#define CV_MAX_ROOMS 16
static CvRoom cv_rooms[CV_MAX_ROOMS];
static int cv_nrooms = 0;
#define CV_MAX_DEAD 64
static int cv_dead[CV_MAX_DEAD][2];
static int cv_ndead = 0;
static const int cv_dc[4] = { 1, -1, 0, 0 };
static const int cv_dr[4] = { 0, 0, 1, -1 };

static int cv_in(int c, int r) { return c >= 1 && c < CV_W - 1 && r >= 1 && r < CV_H - 1; }
static void cv_carve(int c, int r) { if (cv_in(c, r)) cv_open[r][c] = 1; }
static int cv_neighbors(int c, int r) {
    int n = 0;
    for (int k = 0; k < 4; k++) { int cc = c + cv_dc[k], rr = r + cv_dr[k]; if (cc >= 0 && cc < CV_W && rr >= 0 && rr < CV_H && cv_open[rr][cc]) n++; }
    return n;
}

// A winding tunnel from one cell to another: it steps along a random axis and now and then jogs sideways.
static void cv_tunnel(int c0, int r0, int c1, int r1, int wide) {
    int c = c0, r = r0, guard = 0;
    while ((c != c1 || r != r1) && guard++ < 600) {
        int dc = c1 - c, dr = r1 - r, horiz;
        if (dc == 0) horiz = 0; else if (dr == 0) horiz = 1;
        else horiz = cv_rn(abs(dc) + abs(dr)) < abs(dc);
        if (cv_rn(100) < 12) {   // a jog to the side
            int jog = cv_rn(2) ? 1 : -1;
            if (horiz) r += jog; else c += jog;
            if (r < 2) r = 2;
            if (r > CV_H - 3) r = CV_H - 3;
            if (c < 2) c = 2;
            if (c > CV_W - 3) c = CV_W - 3;
        } else if (horiz) c += dc > 0 ? 1 : -1;
        else r += dr > 0 ? 1 : -1;
        cv_carve(c, r);
        if (wide) { if (horiz) cv_carve(c, r + 1); else cv_carve(c + 1, r); }
    }
}

static void cave_generate(void) {
    memset(cv_open, 0, sizeof(cv_open));
    cv_nrooms = 0; cv_ndead = 0;
    cv_rooms[cv_nrooms++] = (CvRoom){ 1, CV_ENT_ROW - 2, 5, 5 };      // the entrance chamber, behind the door
    int tries = 0;
    while (cv_nrooms < 16 && tries++ < 1500) {
        CvRoom q;
        q.w = 3 + cv_rn(5); q.h = 3 + cv_rn(5);
        q.x0 = 3 + cv_rn(CV_W - q.w - 6); q.y0 = 3 + cv_rn(CV_H - q.h - 6);
        int ok = 1;
        for (int i = 0; i < cv_nrooms && ok; i++) {
            const CvRoom *o = &cv_rooms[i];
            if (q.x0 < o->x0 + o->w + 3 && q.x0 + q.w + 3 > o->x0 && q.y0 < o->y0 + o->h + 3 && q.y0 + q.h + 3 > o->y0) ok = 0;
        }
        if (ok) cv_rooms[cv_nrooms++] = q;
    }
    for (int i = 0; i < cv_nrooms; i++) {   // chambers, with their corners knocked off so they look less like boxes
        const CvRoom *q = &cv_rooms[i];
        for (int r = q->y0; r < q->y0 + q->h; r++) for (int c = q->x0; c < q->x0 + q->w; c++) cv_carve(c, r);
        if (i > 0 && q->w > 3 && q->h > 3) {
            int cx[4] = { q->x0, q->x0 + q->w - 1, q->x0, q->x0 + q->w - 1 }, cy[4] = { q->y0, q->y0, q->y0 + q->h - 1, q->y0 + q->h - 1 };
            for (int k = 0; k < 4; k++) if (cv_rn(100) < 70) cv_open[cy[k]][cx[k]] = 0;
        }
    }
    for (int i = 1; i < cv_nrooms; i++) {   // join each chamber to the nearest one before it
        int best = 0, bd = 1 << 30;
        int ci = cv_rooms[i].x0 + cv_rooms[i].w / 2, ri = cv_rooms[i].y0 + cv_rooms[i].h / 2;
        for (int j = 0; j < i; j++) {
            int d = abs(ci - (cv_rooms[j].x0 + cv_rooms[j].w / 2)) + abs(ri - (cv_rooms[j].y0 + cv_rooms[j].h / 2));
            if (d < bd) { bd = d; best = j; }
        }
        cv_tunnel(ci, ri, cv_rooms[best].x0 + cv_rooms[best].w / 2, cv_rooms[best].y0 + cv_rooms[best].h / 2, cv_rn(3) == 0);
    }
    for (int i = 0; i < 10; i++) {   // extra links: loops make it confusing
        int a = 1 + cv_rn(cv_nrooms - 1), b = cv_rn(cv_nrooms);
        if (a == b) continue;
        cv_tunnel(cv_rooms[a].x0 + cv_rooms[a].w / 2, cv_rooms[a].y0 + cv_rooms[a].h / 2,
                  cv_rooms[b].x0 + cv_rooms[b].w / 2, cv_rooms[b].y0 + cv_rooms[b].h / 2, 0);
    }
    for (int i = 0; i < 90; i++) {   // rough edges: little bulges off the open space
        int c = 2 + cv_rn(CV_W - 4), r = 2 + cv_rn(CV_H - 4);
        if (!cv_open[r][c] || (c < 7 && r > CV_ENT_ROW - 4 && r < CV_ENT_ROW + 4)) continue;
        int k = cv_rn(4), cc = c + cv_dc[k], rr = r + cv_dr[k];
        if (cc < 7 && rr > CV_ENT_ROW - 4 && rr < CV_ENT_ROW + 4) continue;
        cv_carve(cc, rr);
        if (cv_rn(2)) cv_carve(cc + cv_dc[cv_rn(4)], rr + cv_dr[cv_rn(4)]);
    }
    for (int att = 0; att < 900 && cv_ndead < 40; att++) {   // dead-end spurs
        int c = 2 + cv_rn(CV_W - 4), r = 2 + cv_rn(CV_H - 4);
        if (!cv_open[r][c] || c < 8) continue;
        int k = cv_rn(4), len = 3 + cv_rn(5), ok = 1;
        for (int st = 1; st <= len && ok; st++) {
            int cc = c + cv_dc[k] * st, rr = r + cv_dr[k] * st;
            if (!cv_in(cc, rr) || cc < 3 || cc > CV_W - 4 || rr < 3 || rr > CV_H - 4 || cv_open[rr][cc]) { ok = 0; break; }
            for (int q = 0; q < 4; q++) {
                int c2 = cc + cv_dc[q], r2 = rr + cv_dr[q];
                if (c2 == cc - cv_dc[k] && r2 == rr - cv_dr[k]) continue;   // the cell we came from
                if (cv_open[r2][c2]) ok = 0;
            }
            int c3 = cc + cv_dc[k], r3 = rr + cv_dr[k];
            if (cv_open[r3][c3]) ok = 0;
        }
        if (!ok) continue;
        for (int st = 1; st <= len; st++) cv_carve(c + cv_dc[k] * st, r + cv_dr[k] * st);
        cv_dead[cv_ndead][0] = c + cv_dc[k] * len; cv_dead[cv_ndead][1] = r + cv_dr[k] * len; cv_ndead++;
    }

    // Everything must be reachable from the entrance: flood it, and seal off anything that is not.
    int qc[CV_W * CV_H], qr[CV_W * CV_H], h = 0, t = 0;
    for (int r = 0; r < CV_H; r++) for (int c = 0; c < CV_W; c++) cv_edist[r][c] = -1;
    cv_edist[CV_ENT_ROW][2] = 0; qc[t] = 2; qr[t] = CV_ENT_ROW; t++;
    while (h < t) {
        int c = qc[h], r = qr[h]; h++;
        for (int k = 0; k < 4; k++) {
            int cc = c + cv_dc[k], rr = r + cv_dr[k];
            if (cc < 0 || cc >= CV_W || rr < 0 || rr >= CV_H || !cv_open[rr][cc] || cv_edist[rr][cc] >= 0) continue;
            cv_edist[rr][cc] = cv_edist[r][c] + 1;
            qc[t] = cc; qr[t] = rr; t++;
        }
    }
    for (int r = 0; r < CV_H; r++) for (int c = 0; c < CV_W; c++) if (cv_open[r][c] && cv_edist[r][c] < 0) cv_open[r][c] = 0;
    // collect every dead end (a cell with a single open neighbour), spurs and natural ones alike
    cv_ndead = 0;
    for (int r = 2; r < CV_H - 2; r++) for (int c = 8; c < CV_W - 2; c++)
        if (cv_open[r][c] && cv_neighbors(c, r) == 1 && cv_ndead < CV_MAX_DEAD) { cv_dead[cv_ndead][0] = c; cv_dead[cv_ndead][1] = r; cv_ndead++; }
    for (int i = 0; i < cv_ndead; i++)   // farthest from the entrance first
        for (int j = i + 1; j < cv_ndead; j++)
            if (cv_edist[cv_dead[j][1]][cv_dead[j][0]] > cv_edist[cv_dead[i][1]][cv_dead[i][0]]) {
                int a = cv_dead[i][0], b = cv_dead[i][1];
                cv_dead[i][0] = cv_dead[j][0]; cv_dead[i][1] = cv_dead[j][1]; cv_dead[j][0] = a; cv_dead[j][1] = b;
            }
}

static int cave_cell(float x, float z, int *c, int *r) {
    float fx = (x - CV_X0) / CV_CELL, fz = (z - CV_Z0) / CV_CELL;
    if (fx < 0.0f || fz < 0.0f || fx >= (float)CV_W || fz >= (float)CV_H) return 0;
    *c = (int)fx; *r = (int)fz;
    return cv_open[*r][*c];
}
static void cave_center(int c, int r, float *x, float *z) {
    *x = CV_X0 + ((float)c + 0.5f) * CV_CELL;
    *z = CV_Z0 + ((float)r + 0.5f) * CV_CELL;
}
// Path length (cells) from every open cell to (tc, tr).
static void cave_dist_from(int tc, int tr) {
    static int qc[CV_W * CV_H], qr[CV_W * CV_H];
    int h = 0, t = 0;
    for (int r = 0; r < CV_H; r++) for (int c = 0; c < CV_W; c++) cv_dist[r][c] = -1;
    cv_dist[tr][tc] = 0; qc[t] = tc; qr[t] = tr; t++;
    while (h < t) {
        int c = qc[h], r = qr[h]; h++;
        for (int k = 0; k < 4; k++) {
            int cc = c + cv_dc[k], rr = r + cv_dr[k];
            if (cc < 0 || cc >= CV_W || rr < 0 || rr >= CV_H || !cv_open[rr][cc] || cv_dist[rr][cc] >= 0) continue;
            cv_dist[rr][cc] = cv_dist[r][c] + 1;
            qc[t] = cc; qr[t] = rr; t++;
        }
    }
}

static void add_cone_down(float cx, float ytop, float cz, float r, float len, int sides, rgb col) {
    vec3 apex = V(cx, ytop - len, cz);
    for (int i = 0; i < sides; i++) {
        float a0 = 2 * PI_F * i / sides, a1 = 2 * PI_F * (i + 1) / sides;
        add_tri(V(cx + cosf(a0) * r, ytop, cz + sinf(a0) * r), V(cx + cosf(a1) * r, ytop, cz + sinf(a1) * r), apex, col);
    }
}

// Nudge a point out of any cave collider (stalagmites, boulders, columns).
static void cv_push_out(float *x, float *z, float margin) {
    for (int pass = 0; pass < 3; pass++)
        for (int i = nc_over; i < ncolliders; i++) {
            float dx = *x - colliders[i].x, dz = *z - colliders[i].z, d = sqrtf(dx * dx + dz * dz), m = colliders[i].r + margin;
            if (d < m) {
                if (d < 1e-4f) { dx = 1.0f; dz = 0.0f; d = 1.0f; }
                *x = colliders[i].x + dx / d * m; *z = colliders[i].z + dz / d * m;
            }
        }
}
static int cv_cell_clear(int c, int r, float margin) {
    float x, z;
    cave_center(c, r, &x, &z);
    for (int i = nc_over; i < ncolliders; i++) {
        float dx = x - colliders[i].x, dz = z - colliders[i].z, m = colliders[i].r + margin;
        if (dx * dx + dz * dz < m * m) return 0;
    }
    return 1;
}

static void add_cave_enemy(int type, int c, int r, float ox, float oz) {
    if (num_enemies >= MAX_ENEMIES) return;
    Enemy *e = &enemies[num_enemies];
    memset(e, 0, sizeof(*e));
    float x, z;
    cave_center(c, r, &x, &z);
    x += ox; z += oz;
    cv_push_out(&x, &z, enemy_defs[type].radius + 0.1f);
    e->type = type; e->spawn_x = x; e->spawn_z = z;
    e->spawn_yaw = (float)(num_enemies * 2);
    e->roam = 2; e->zone = 1;
    num_enemies++;
}

#define MAX_CV_LIGHTS 8
static float cv_lights[MAX_CV_LIGHTS][2];   // torch stands in the boss rooms (flames drawn each frame)
static int cv_nlights = 0;

static void build_cave(void) {
    cave_generate();
    cur = &cave_mesh;
    cave_mesh.n = 0;
    rgb rock = C(0.40f, 0.37f, 0.35f), rock2 = C(0.33f, 0.31f, 0.31f), rock3 = C(0.46f, 0.43f, 0.40f);

    // floor and ceiling
    for (int r = 0; r < CV_H; r++) for (int c = 0; c < CV_W; c++) {
        if (!cv_open[r][c]) continue;
        float x0 = CV_X0 + c * CV_CELL, z0 = CV_Z0 + r * CV_CELL, x1 = x0 + CV_CELL, z1 = z0 + CV_CELL;
        float v = ((c * 7 + r * 13) % 4) * 0.018f;
        rgb f = ((c + r) & 1) ? C(0.23f + v, 0.21f + v, 0.20f + v) : C(0.19f + v, 0.18f + v, 0.17f + v);
        add_quad(V(x0, 0.0f, z0), V(x0, 0.0f, z1), V(x1, 0.0f, z1), V(x1, 0.0f, z0), f);
        add_quad(V(x0, CV_CEIL, z0), V(x1, CV_CEIL, z0), V(x1, CV_CEIL, z1), V(x0, CV_CEIL, z1), C(0.17f, 0.16f, 0.17f));
    }

    // rock walls: every solid cell that touches open space, merged into runs along each row
    for (int r = 0; r < CV_H; r++) {
        int c = 0;
        while (c < CV_W) {
            int shell = 0;
            if (!cv_open[r][c]) {
                for (int dr = -1; dr <= 1 && !shell; dr++) for (int dc = -1; dc <= 1; dc++) {
                    int cc = c + dc, rr = r + dr;
                    if (cc >= 0 && cc < CV_W && rr >= 0 && rr < CV_H && cv_open[rr][cc]) { shell = 1; break; }
                }
            }
            if (!shell) { c++; continue; }
            int c2 = c;
            while (c2 + 1 < CV_W && !cv_open[r][c2 + 1]) {
                int sh = 0;
                for (int dr = -1; dr <= 1 && !sh; dr++) for (int dc = -1; dc <= 1; dc++) {
                    int cc = c2 + 1 + dc, rr = r + dr;
                    if (cc >= 0 && cc < CV_W && rr >= 0 && rr < CV_H && cv_open[rr][cc]) { sh = 1; break; }
                }
                if (!sh) break;
                c2++;
            }
            float x0 = CV_X0 + c * CV_CELL, x1 = CV_X0 + (c2 + 1) * CV_CELL, z0 = CV_Z0 + r * CV_CELL, z1 = z0 + CV_CELL;
            add_box((x0 + x1) / 2, 0.0f, (z0 + z1) / 2, x1 - x0, CV_CEIL, z1 - z0, ((c + r) % 3 == 0) ? rock3 : (((c + r) & 1) ? rock : rock2));
            add_wall_collider(x0, z0, x1, z1);
            c = c2 + 1;
        }
    }

    // the door back up (set into the west wall) with a timber frame
    {
        rgb wood = C(0.30f, 0.20f, 0.12f);
        add_box(CV_DOOR_X - 0.1f, 0.0f, CV_DOOR_Z - DOOR_HALF - 0.16f, 0.34f, 3.0f, 0.30f, wood);
        add_box(CV_DOOR_X - 0.1f, 0.0f, CV_DOOR_Z + DOOR_HALF + 0.16f, 0.34f, 3.0f, 0.30f, wood);
        add_box(CV_DOOR_X - 0.1f, 2.85f, CV_DOOR_Z, 0.34f, 0.25f, 2 * DOOR_HALF + 0.62f, wood);
    }

    // which cells are chest / enemy spots (kept clear of scenery)
    static unsigned char reserved[CV_H][CV_W];
    memset(reserved, 0, sizeof(reserved));
    for (int i = 0; i < cv_ndead; i++) reserved[cv_dead[i][1]][cv_dead[i][0]] = 1;
    for (int r = 0; r < CV_H; r++) for (int c = 0; c < 8; c++) if (cv_open[r][c] && r > CV_ENT_ROW - 5 && r < CV_ENT_ROW + 5) reserved[r][c] = 1;   // the entrance
    // the two mini-boss rooms: the largest chambers farthest from the entrance, well apart from each other
    int boss_room[2] = { -1, -1 };
    cv_nlights = 0;
    for (int pass = 0; pass < 2; pass++) {
        for (int minsz = 5; minsz >= 3 && boss_room[pass] < 0; minsz--) {
            int best = -1;
            for (int i = 1; i < cv_nrooms; i++) {
                const CvRoom *q = &cv_rooms[i];
                if (q->w < minsz || q->h < minsz || i == boss_room[0]) continue;
                int cc = q->x0 + q->w / 2, rr = q->y0 + q->h / 2;
                if (!cv_open[rr][cc] || cv_edist[rr][cc] < 0) continue;
                if (pass == 1) {
                    const CvRoom *o = &cv_rooms[boss_room[0]];
                    if (abs(cc - (o->x0 + o->w / 2)) + abs(rr - (o->y0 + o->h / 2)) < 12) continue;
                }
                if (cv_edist[rr][cc] > best) { best = cv_edist[rr][cc]; boss_room[pass] = i; }
            }
        }
        if (boss_room[pass] >= 0) {
            const CvRoom *q = &cv_rooms[boss_room[pass]];
            for (int r = q->y0; r < q->y0 + q->h; r++) for (int c = q->x0; c < q->x0 + q->w; c++) reserved[r][c] = 1;
        }
    }
    static unsigned char in_room[CV_H][CV_W];
    memset(in_room, 0, sizeof(in_room));
    for (int i = 1; i < cv_nrooms; i++)
        for (int r = cv_rooms[i].y0; r < cv_rooms[i].y0 + cv_rooms[i].h; r++) for (int c = cv_rooms[i].x0; c < cv_rooms[i].x0 + cv_rooms[i].w; c++) in_room[r][c] = 1;

    // stalagmites (rising) and stalactites (hanging), columns, boulders
    for (int r = 0; r < CV_H; r++) for (int c = 0; c < CV_W; c++) {
        if (!cv_open[r][c]) continue;
        float cx, cz;
        cave_center(c, r, &cx, &cz);
        int solid_k = -1;
        for (int k = 0; k < 4; k++) if (!cv_open[r + cv_dr[k]][c + cv_dc[k]]) { solid_k = k; break; }
        if (!reserved[r][c] && cv_rn(100) < (solid_k >= 0 ? 17 : 7)) {   // stalagmite, tucked toward a wall where there is one
            float rr = 0.28f + cv_rn(30) * 0.01f, hh = 0.9f + cv_rn(160) * 0.01f;
            float ox = (solid_k >= 0 ? cv_dc[solid_k] * 0.85f : 0.0f) + (cv_rn(100) - 50) * 0.008f;
            float oz = (solid_k >= 0 ? cv_dr[solid_k] * 0.85f : 0.0f) + (cv_rn(100) - 50) * 0.008f;
            add_cone(cx + ox, 0.0f, cz + oz, rr, hh, 6, (cv_rn(2)) ? rock3 : rock);
            add_collider(cx + ox, cz + oz, rr * 0.75f);
        }
        if (cv_rn(100) < 24) {   // stalactite
            float rr = 0.22f + cv_rn(40) * 0.01f, len = 1.6f + cv_rn(300) * 0.01f;
            add_cone_down(cx + (cv_rn(100) - 50) * 0.016f, CV_CEIL, cz + (cv_rn(100) - 50) * 0.016f, rr, len, 6, (cv_rn(2)) ? rock2 : rock);
        }
        if (in_room[r][c] && !reserved[r][c] && cv_rn(100) < 6) {   // boulder in a chamber
            float rr = 0.45f + cv_rn(25) * 0.01f, bx = cx + (cv_rn(100) - 50) * 0.01f;
            add_octahedron(bx, rr * 0.7f, cz, rr, rock3, rock2);
            add_collider(bx, cz, rr * 0.85f);
        }
    }
    for (int i = 1; i < cv_nrooms; i++) {   // a few full columns where a stalactite met a stalagmite
        if (cv_rooms[i].w < 5 || cv_rooms[i].h < 5 || cv_rn(100) > 55 || i == boss_room[0] || i == boss_room[1]) continue;
        float x, z;
        cave_center(cv_rooms[i].x0 + 1, cv_rooms[i].y0 + 1, &x, &z);
        add_cylinder(x, 0.0f, z, 0.45f, CV_CEIL, 7, rock);
        add_collider(x, z, 0.6f);
    }

    // the dying man sits in the entrance chamber, against the west wall
    add_collider(CVN_X, CVN_Z, 0.6f);

    // ---- chests and finds: the farthest dead ends hold the best things ----
    {
        static unsigned char used[CV_H][CV_W];
        memset(used, 0, sizeof(used));
        int di = 0;
        for (int i = 0; i < PK_CAVE_N; i++) {
            int c = -1, r = -1;
            while (di < cv_ndead && c < 0) {
                int cc = cv_dead[di][0], rr = cv_dead[di][1];
                di++;
                if (!used[rr][cc] && cv_cell_clear(cc, rr, 0.5f)) { c = cc; r = rr; }
            }
            if (c < 0) {   // too few dead ends: take far open cells, well apart from the other finds
                int best = -1;
                for (int rr = 2; rr < CV_H - 2; rr++) for (int cc = 8; cc < CV_W - 2; cc++) {
                    if (!cv_open[rr][cc] || used[rr][cc] || in_room[rr][cc] || !cv_cell_clear(cc, rr, 0.5f)) continue;
                    int near = 0;
                    for (int q = 0; q < i; q++) {
                        int qc, qr;
                        if (cave_cell(pickups[PK_CAVE0 + q].x, pickups[PK_CAVE0 + q].z, &qc, &qr) && abs(qc - cc) + abs(qr - rr) < 7) near = 1;
                    }
                    if (!near && cv_edist[rr][cc] > best) { best = cv_edist[rr][cc]; c = cc; r = rr; }
                }
            }
            if (c < 0) { c = 3; r = CV_ENT_ROW; }
            used[r][c] = 1;
            float x, z;
            cave_center(c, r, &x, &z);
            pickups[PK_CAVE0 + i].x = x; pickups[PK_CAVE0 + i].z = z; pickups[PK_CAVE0 + i].y = 0.0f;
        }
    }

    // ---- the boss rooms: torch stands in the corners, a chest against the north wall holding the prize ----
    for (int b = 0; b < 2; b++) {
        if (boss_room[b] < 0) {   // (no suitable chamber: leave the prize in the farthest open cell)
            int bc = 3, br = CV_ENT_ROW, bd = -1;
            for (int r = 2; r < CV_H - 2; r++) for (int c = 8; c < CV_W - 2; c++)
                if (cv_open[r][c] && cv_edist[r][c] > bd && cv_cell_clear(c, r, 0.5f)) { bd = cv_edist[r][c]; bc = c; br = r; }
            float x, z;
            cave_center(bc, br, &x, &z);
            pickups[PK_CAVE0 + 8 + b].x = x; pickups[PK_CAVE0 + 8 + b].z = z;
            continue;
        }
        const CvRoom *q = &cv_rooms[boss_room[b]];
        rgb wood = C(0.30f, 0.20f, 0.12f), iron = C(0.26f, 0.26f, 0.30f), coal = C(0.95f, 0.45f, 0.10f);
        int pc0 = -1, pr0 = -1, pbest = 1 << 30;   // the prize chest: the open cell on the north side nearest the middle
        for (int rr2 = q->y0; rr2 < q->y0 + q->h; rr2++) for (int cc2 = q->x0; cc2 < q->x0 + q->w; cc2++) {
            int sc = (rr2 - q->y0) * 100 + abs(cc2 - (q->x0 + q->w / 2));
            if (cv_open[rr2][cc2] && sc < pbest) { pbest = sc; pc0 = cc2; pr0 = rr2; }
        }
        for (int k = 0; k < 4 && cv_nlights < MAX_CV_LIGHTS; k++) {
            int tc = (k & 1) ? q->x0 + q->w - 1 : q->x0, tr = (k & 2) ? q->y0 + q->h - 1 : q->y0;
            int c = -1, r = -1, bd = 1 << 30;   // the open cell of the chamber nearest this corner
            for (int rr2 = q->y0; rr2 < q->y0 + q->h; rr2++) for (int cc2 = q->x0; cc2 < q->x0 + q->w; cc2++) {
                int dd = (cc2 - tc) * (cc2 - tc) + (rr2 - tr) * (rr2 - tr);
                if (cv_open[rr2][cc2] && dd < bd && (abs(cc2 - pc0) > 1 || abs(rr2 - pr0) > 1)) { bd = dd; c = cc2; r = rr2; }
            }
            if (c < 0) continue;
            float x, z;
            cave_center(c, r, &x, &z);
            {   // tuck it toward the corner, but only as far as open floor goes
                float tx = x + ((k & 1) ? 0.6f : -0.6f), tz = z + ((k & 2) ? 0.6f : -0.6f);
                int qc, qr;
                if (cave_cell(tx, tz, &qc, &qr) && qc == c && qr == r) { x = tx; z = tz; }
            }
            add_prism(V(x, 0.0f, z), V(x, 1.55f, z), 0.06f, 6, wood);
            add_cylinder(x, 1.45f, z, 0.24f, 0.18f, 8, iron);
            add_box(x, 1.60f, z, 0.30f, 0.05f, 0.30f, coal);
            add_collider(x, z, 0.3f);
            cv_lights[cv_nlights][0] = x; cv_lights[cv_nlights][1] = z; cv_nlights++;
        }
        float x, z;
        cave_center(pc0, pr0, &x, &z);
        pickups[PK_CAVE0 + 8 + b].x = x;
        pickups[PK_CAVE0 + 8 + b].z = z;
        pickups[PK_CAVE0 + 8 + b].y = 0.0f;
    }

    // ---- who lives here ----
    // chamber 1..: a mix of zombies, worms, the dead and a little of everything
    static const struct { int type; int dx, dz; } mix[][4] = {
        { { ENEMY_RAT, -1, 0 }, { ENEMY_RAT, 1, 0 }, { -1, 0, 0 }, { -1, 0, 0 } },
        { { ENEMY_ZOMBIE, 0, 0 }, { -1, 0, 0 }, { -1, 0, 0 }, { -1, 0, 0 } },
        { { ENEMY_WORM, -1, 0 }, { ENEMY_WORM, 1, 0 }, { -1, 0, 0 }, { -1, 0, 0 } },
        { { ENEMY_ZOMBIE, -1, 0 }, { ENEMY_ZOMBIE, 1, 0 }, { -1, 0, 0 }, { -1, 0, 0 } },
        { { ENEMY_UNDEAD, 0, 0 }, { -1, 0, 0 }, { -1, 0, 0 }, { -1, 0, 0 } },
        { { ENEMY_CRAB, 0, 0 }, { ENEMY_RAT, 1, 1 }, { -1, 0, 0 }, { -1, 0, 0 } },
        { { ENEMY_ZOMBIE, -1, -1 }, { ENEMY_ZOMBIE, 1, 0 }, { ENEMY_ZOMBIE, 0, 1 }, { -1, 0, 0 } },
        { { ENEMY_UNDEAD, -1, 0 }, { ENEMY_ZOMBIE, 1, 0 }, { -1, 0, 0 }, { -1, 0, 0 } },
        { { ENEMY_WORM, -1, 0 }, { ENEMY_WORM, 0, 1 }, { ENEMY_WORM, 1, 0 }, { -1, 0, 0 } },
        { { ENEMY_CRAB, -1, 0 }, { ENEMY_CRAB, 1, 0 }, { -1, 0, 0 }, { -1, 0, 0 } },
        { { ENEMY_UNDEAD, -1, 0 }, { ENEMY_UNDEAD, 1, 0 }, { ENEMY_ZOMBIE, 0, 1 }, { -1, 0, 0 } },
        { { ENEMY_ZOMBIE, 0, 0 }, { ENEMY_WORM, 1, 0 }, { -1, 0, 0 }, { -1, 0, 0 } },
    };
    for (int i = 13; i < cv_nrooms; i++) {   // the rest of the chambers: zombies and worms
        if (i == boss_room[0] || i == boss_room[1]) continue;
        int cc = cv_rooms[i].x0 + cv_rooms[i].w / 2, rr = cv_rooms[i].y0 + cv_rooms[i].h / 2;
        add_cave_enemy((i & 1) ? ENEMY_ZOMBIE : ENEMY_WORM, cc, rr, -0.5f, 0.0f);
        add_cave_enemy((i & 1) ? ENEMY_UNDEAD : ENEMY_ZOMBIE, cc, rr, 0.5f, 0.3f);
    }
    for (int i = 1; i < cv_nrooms && i <= 12; i++) {
        if (i == boss_room[0] || i == boss_room[1]) continue;
        int cc = cv_rooms[i].x0 + cv_rooms[i].w / 2, rr = cv_rooms[i].y0 + cv_rooms[i].h / 2;
        for (int k = 0; k < 4; k++) {
            if (mix[i - 1][k].type < 0) continue;
            int c2 = cc + mix[i - 1][k].dx, r2 = rr + mix[i - 1][k].dz;
            if (!cv_open[r2][c2]) { c2 = cc; r2 = rr; }
            add_cave_enemy(mix[i - 1][k].type, c2, r2, 0.0f, 0.0f);
        }
    }
    for (int b = 0; b < 2; b++) {   // the guardians, with company
        if (boss_room[b] < 0) continue;
        const CvRoom *q = &cv_rooms[boss_room[b]];
        int cc = q->x0 + q->w / 2, rr = q->y0 + q->h / 2;
        add_cave_enemy(b == 0 ? ENEMY_BRUTE : ENEMY_WARDEN, cc, rr, 0.0f, 0.4f);
        add_cave_enemy(b == 0 ? ENEMY_ZOMBIE : ENEMY_UNDEAD, cc - 1, rr + 1, 0.0f, 0.0f);
        if (b == 1) add_cave_enemy(ENEMY_UNDEAD, cc + 1, rr + 1, 0.0f, 0.0f);
    }
    // loners in the tunnels: one wandering zombie, one worm
    for (int i = 0, n = 0; i < 400 && n < 6; i++) {
        int c = 8 + cv_rn(CV_W - 10), r = 2 + cv_rn(CV_H - 4);
        if (!cv_open[r][c] || in_room[r][c] || reserved[r][c] || cv_edist[r][c] < 14) continue;
        add_cave_enemy((n & 1) ? ENEMY_WORM : ENEMY_ZOMBIE, c, r, 0.0f, 0.0f);
        n++;
    }
}

static void update_enemy(Enemy *e, float dt, float px, float pz) {
    const EnemyDef *d = &enemy_defs[e->type];
    float dx = px - e->x, dz = pz - e->z;
    float dist = sqrtf(dx * dx + dz * dz);
    int er = room_of(e->x, e->z), pr = room_of(px, pz);
    int same = (er == pr);
    e->state_t += dt;
    e->walking = 0;

    switch (e->state) {
    case E_IDLE:
        if (e->roam == 2) {
            // Cave creature: sees you down a passage or when you are a couple of cells away; otherwise wanders cell to cell.
            int ec, er2, pc, pr2;
            int ein = cave_cell(e->x, e->z, &ec, &er2), pin = cave_cell(px, pz, &pc, &pr2);
            int steps = (ein && pin && cv_dist[er2][ec] >= 0) ? cv_dist[er2][ec] : 99;
            if (!player_dead && pin && dist < d->aggro_range && (steps <= 2 || los_clear(e->x, e->z, px, pz))) {
                e->state = E_CHASE; e->state_t = 0.0f; e->hop = 0.0f;
                bestiary_seen[e->type] = 1;
            } else if (e->wait > 0.0f) {
                e->wait -= dt;
            } else {
                float wx = e->wx - e->x, wz = e->wz - e->z, wd = sqrtf(wx * wx + wz * wz);
                e->stuck += dt;
                if (wd < 0.4f || e->stuck > 7.0f) {
                    e->wait = 0.8f + rnd01() * 2.2f;
                    e->stuck = 0.0f;
                    int c, r;
                    if (!cave_cell(e->x, e->z, &c, &r)) { e->wx = e->spawn_x; e->wz = e->spawn_z; }
                    else {
                        int opts[4], n = 0;
                        for (int k = 0; k < 4; k++) if (cv_open[r + cv_dr[k]][c + cv_dc[k]]) opts[n++] = k;
                        if (n == 0) cave_center(c, r, &e->wx, &e->wz);
                        else { int k = opts[(int)(rnd01() * (float)n) % n]; cave_center(c + cv_dc[k], r + cv_dr[k], &e->wx, &e->wz); }
                    }
                } else {
                    enemy_step(e, d, e->wx, e->wz, d->wanders ? d->wander_speed : d->move_speed * 0.55f, dt);
                }
            }
            break;
        }
        if (e->roam == 1) {
            // Labyrinth creature: notices you by sight down a corridor, or when you are one cell away; otherwise roams.
            int ec, erow, pc, prow, nc, nr, steps = 99;
            int in = maze_cell(e->x, e->z, &ec, &erow), pin = maze_cell(px, pz, &pc, &prow);
            if (in && pin) steps = maze_step(ec, erow, pc, prow, &nc, &nr);
            if (!player_dead && pin && dist < d->aggro_range && (steps <= 1 || los_clear(e->x, e->z, px, pz))) {
                e->state = E_CHASE; e->state_t = 0.0f; e->hop = 0.0f;
                bestiary_seen[e->type] = 1;
            } else if (e->wait > 0.0f) {
                e->wait -= dt;
            } else {
                float wx = e->wx - e->x, wz = e->wz - e->z, wd = sqrtf(wx * wx + wz * wz);
                e->stuck += dt;
                if (wd < 0.4f || e->stuck > 6.0f) {
                    e->wait = 0.8f + rnd01() * 1.8f;
                    roam_pick(e);
                } else {
                    enemy_step(e, d, e->wx, e->wz, d->wanders ? d->wander_speed : d->move_speed * 0.55f, dt);
                }
            }
            break;
        }
        // Wakes up when you're close and it can see you (same room, or the door between is open).
        if (!player_dead && dist < d->aggro_range && can_see(er, pr)) {
            e->state = E_CHASE;
            e->state_t = 0.0f;
            e->hop = 0.0f;
            bestiary_seen[e->type] = 1;
        } else if (d->wanders) {
            // Stroll to a random spot near home, pause, repeat.
            if (e->wait > 0.0f) {
                e->wait -= dt;
            } else {
                float wx = e->wx - e->x, wz = e->wz - e->z, wd = sqrtf(wx * wx + wz * wz);
                if (wd < 0.35f) {
                    e->wait = 1.0f + rnd01() * 2.0f;
                    e->wx = e->spawn_x + (rnd01() * 2.0f - 1.0f) * 3.2f;
                    e->wz = e->spawn_z + (rnd01() * 2.0f - 1.0f) * 2.8f;
                } else {
                    turn_toward(&e->yaw, atan2f(wx, wz), 3.0f * dt);
                    e->x += wx / wd * d->wander_speed * dt;
                    e->z += wz / wd * d->wander_speed * dt;
                    e->walking = 1;
                    e->hop += dt / d->hop_time;
                    if (e->state_t > 12.0f) { e->wx = e->x; e->wz = e->z; }   // stuck on something: give up this target
                }
            }
        }
        break;

    case E_CHASE: {
        if (e->roam == 2) {   // follow the passages toward you
            int ec, er2, pc, pr2;
            float tx = px, tz = pz;
            int ein = cave_cell(e->x, e->z, &ec, &er2), pin = cave_cell(px, pz, &pc, &pr2);
            if (ein && pin && cv_dist[er2][ec] > 0 && !los_clear(e->x, e->z, px, pz)) {
                int best = cv_dist[er2][ec];
                for (int k = 0; k < 4; k++) {
                    int cc = ec + cv_dc[k], rr = er2 + cv_dr[k];
                    if (cv_open[rr][cc] && cv_dist[rr][cc] >= 0 && cv_dist[rr][cc] < best) { best = cv_dist[rr][cc]; cave_center(cc, rr, &tx, &tz); }
                }
            }
            enemy_step(e, d, tx, tz, d->move_speed, dt);
            if (dist < d->attack_range && los_clear(e->x, e->z, px, pz)) {
                e->state = E_WINDUP; e->state_t = 0.0f;
            } else if (!pin || player_dead || dist > 26.0f) {
                e->state = E_IDLE; e->state_t = 0.0f; e->wx = e->x; e->wz = e->z; e->wait = 1.0f;
            }
            break;
        }
        if (e->roam == 1) {   // follow the corridors toward you
            int ec, erow, pc, prow, nc, nr;
            float tx = px, tz = pz;
            int pin = maze_cell(px, pz, &pc, &prow);
            if (pin && maze_cell(e->x, e->z, &ec, &erow) && !(ec == pc && erow == prow)) {
                maze_step(ec, erow, pc, prow, &nc, &nr);
                maze_center(nc, nr, &tx, &tz);
            }
            enemy_step(e, d, tx, tz, d->move_speed, dt);
            if (dist < d->attack_range && los_clear(e->x, e->z, px, pz)) {
                e->state = E_WINDUP; e->state_t = 0.0f;
            } else if (!pin || player_dead || dist > 22.0f) {
                e->state = E_IDLE; e->state_t = 0.0f; e->wx = e->x; e->wz = e->z; e->wait = 1.0f;
            }
            break;
        }
        // If you're in another room it heads for the doorway between you first.
        float tx = px, tz = pz;
        if (!same) {
            if (er < pr) { tx = doors[er].x + 0.6f;     tz = 0.0f; }
            else         { tx = doors[er - 1].x - 0.6f; tz = 0.0f; }
        }
        float wx = tx - e->x, wz = tz - e->z, wd = sqrtf(wx * wx + wz * wz);
        if (wd > 1e-4f) {
            if (d->hops) e->yaw = atan2f(wx, wz);
            else         turn_toward(&e->yaw, atan2f(wx, wz), 5.0f * dt);
        }
        if (d->hops) {
            e->hop += dt / d->hop_time;
            float f = e->hop - floorf(e->hop);
            if (f < 0.65f && wd > 0.6f) {   // moves only while airborne: hop, hop, hop
                e->x += wx / wd * d->move_speed * dt;
                e->z += wz / wd * d->move_speed * dt;
                e->walking = 1;
            }
        } else if (wd > 0.6f) {
            e->x += wx / wd * d->move_speed * dt;
            e->z += wz / wd * d->move_speed * dt;
            e->walking = 1;
            e->hop += dt / d->hop_time;
        }
        if (same && dist < d->attack_range) {
            e->state = E_WINDUP;
            e->state_t = 0.0f;
        } else if (dist > 16.0f || player_dead) {
            e->state = E_IDLE;
            e->state_t = 0.0f;
        }
        break;
    }

    case E_WINDUP:   // telegraphs, tracks you, then commits to a direction
        if (e->state_t < d->windup * 0.6f && dist > 1e-4f) e->yaw = atan2f(dx, dz);
        if (e->state_t >= d->windup) {
            e->lunge_x = sinf(e->yaw);
            e->lunge_z = cosf(e->yaw);
            e->lunge_hit = 0;
            e->state = E_LUNGE;
            e->state_t = 0.0f;
        }
        break;

    case E_LUNGE:    // straight-line dash: side-step it with a dodge
        e->x += e->lunge_x * d->lunge_speed * dt;
        e->z += e->lunge_z * d->lunge_speed * dt;
        if (!e->lunge_hit && dist < d->hit_radius) {
            e->lunge_hit = 1;
            damage_player(d->damage);
        }
        if (e->state_t >= d->lunge_time) { e->state = E_RECOVER; e->state_t = 0.0f; }
        break;

    case E_RECOVER:  // open for a counter-attack
        if (e->state_t >= d->recover) { e->state = E_CHASE; e->state_t = 0.0f; e->hop = 0.0f; }
        break;

    case E_STAGGER: {
        float k = 3.5f * (1.0f - e->state_t / d->stagger);
        if (k < 0.0f) k = 0.0f;
        e->x += e->kb_x * k * dt;
        e->z += e->kb_z * k * dt;
        if (e->state_t >= d->stagger) { e->state = E_CHASE; e->state_t = 0.0f; e->hop = 0.0f; }
        break;
    }

    case E_DEAD:
        break;
    }

    if (e->state != E_DEAD) {
        clamp_world(&e->x, &e->z);
        resolve_collisions(&e->x, &e->z, enemy_radius(e));
    }
}

// ----------------------------------------------------------- HUD / font ----
// Tiny built-in 5x7 bitmap font (uppercase, digits, a few symbols).

#define FONT_CHARS " ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-.:>[]/!?,'+%"

static const unsigned char font[][7] = {
    {0, 0, 0, 0, 0, 0, 0},                                                           // space
    {0b01110, 0b10001, 0b10001, 0b11111, 0b10001, 0b10001, 0b10001},                 // A
    {0b11110, 0b10001, 0b10001, 0b11110, 0b10001, 0b10001, 0b11110},                 // B
    {0b01110, 0b10001, 0b10000, 0b10000, 0b10000, 0b10001, 0b01110},                 // C
    {0b11110, 0b10001, 0b10001, 0b10001, 0b10001, 0b10001, 0b11110},                 // D
    {0b11111, 0b10000, 0b10000, 0b11110, 0b10000, 0b10000, 0b11111},                 // E
    {0b11111, 0b10000, 0b10000, 0b11110, 0b10000, 0b10000, 0b10000},                 // F
    {0b01110, 0b10001, 0b10000, 0b10111, 0b10001, 0b10001, 0b01111},                 // G
    {0b10001, 0b10001, 0b10001, 0b11111, 0b10001, 0b10001, 0b10001},                 // H
    {0b01110, 0b00100, 0b00100, 0b00100, 0b00100, 0b00100, 0b01110},                 // I
    {0b00111, 0b00010, 0b00010, 0b00010, 0b00010, 0b10010, 0b01100},                 // J
    {0b10001, 0b10010, 0b10100, 0b11000, 0b10100, 0b10010, 0b10001},                 // K
    {0b10000, 0b10000, 0b10000, 0b10000, 0b10000, 0b10000, 0b11111},                 // L
    {0b10001, 0b11011, 0b10101, 0b10101, 0b10001, 0b10001, 0b10001},                 // M
    {0b10001, 0b11001, 0b10101, 0b10011, 0b10001, 0b10001, 0b10001},                 // N
    {0b01110, 0b10001, 0b10001, 0b10001, 0b10001, 0b10001, 0b01110},                 // O
    {0b11110, 0b10001, 0b10001, 0b11110, 0b10000, 0b10000, 0b10000},                 // P
    {0b01110, 0b10001, 0b10001, 0b10001, 0b10101, 0b10010, 0b01101},                 // Q
    {0b11110, 0b10001, 0b10001, 0b11110, 0b10100, 0b10010, 0b10001},                 // R
    {0b01111, 0b10000, 0b10000, 0b01110, 0b00001, 0b00001, 0b11110},                 // S
    {0b11111, 0b00100, 0b00100, 0b00100, 0b00100, 0b00100, 0b00100},                 // T
    {0b10001, 0b10001, 0b10001, 0b10001, 0b10001, 0b10001, 0b01110},                 // U
    {0b10001, 0b10001, 0b10001, 0b10001, 0b10001, 0b01010, 0b00100},                 // V
    {0b10001, 0b10001, 0b10001, 0b10101, 0b10101, 0b11011, 0b10001},                 // W
    {0b10001, 0b10001, 0b01010, 0b00100, 0b01010, 0b10001, 0b10001},                 // X
    {0b10001, 0b10001, 0b01010, 0b00100, 0b00100, 0b00100, 0b00100},                 // Y
    {0b11111, 0b00001, 0b00010, 0b00100, 0b01000, 0b10000, 0b11111},                 // Z
    {0b01110, 0b10001, 0b10011, 0b10101, 0b11001, 0b10001, 0b01110},                 // 0
    {0b00100, 0b01100, 0b00100, 0b00100, 0b00100, 0b00100, 0b01110},                 // 1
    {0b01110, 0b10001, 0b00001, 0b00010, 0b00100, 0b01000, 0b11111},                 // 2
    {0b11110, 0b00001, 0b00001, 0b01110, 0b00001, 0b00001, 0b11110},                 // 3
    {0b00010, 0b00110, 0b01010, 0b10010, 0b11111, 0b00010, 0b00010},                 // 4
    {0b11111, 0b10000, 0b11110, 0b00001, 0b00001, 0b10001, 0b01110},                 // 5
    {0b00110, 0b01000, 0b10000, 0b11110, 0b10001, 0b10001, 0b01110},                 // 6
    {0b11111, 0b00001, 0b00010, 0b00100, 0b01000, 0b01000, 0b01000},                 // 7
    {0b01110, 0b10001, 0b10001, 0b01110, 0b10001, 0b10001, 0b01110},                 // 8
    {0b01110, 0b10001, 0b10001, 0b01111, 0b00001, 0b00010, 0b01100},                 // 9
    {0, 0, 0, 0b11111, 0, 0, 0},                                                     // -
    {0, 0, 0, 0, 0, 0b01100, 0b01100},                                               // .
    {0, 0b01100, 0b01100, 0, 0b01100, 0b01100, 0},                                   // :
    {0b01000, 0b00100, 0b00010, 0b00001, 0b00010, 0b00100, 0b01000},                 // >
    {0b01110, 0b01000, 0b01000, 0b01000, 0b01000, 0b01000, 0b01110},                 // [
    {0b01110, 0b00010, 0b00010, 0b00010, 0b00010, 0b00010, 0b01110},                 // ]
    {0b00001, 0b00010, 0b00010, 0b00100, 0b01000, 0b01000, 0b10000},                 // /
    {0b00100, 0b00100, 0b00100, 0b00100, 0b00100, 0, 0b00100},                       // !
    {0b01110, 0b10001, 0b00001, 0b00010, 0b00100, 0, 0b00100},                       // ?
    {0, 0, 0, 0, 0b01100, 0b00100, 0b01000},                                         // ,
    {0b00100, 0b00100, 0b01000, 0, 0, 0, 0},                                         // '
    {0, 0b00100, 0b00100, 0b11111, 0b00100, 0b00100, 0},                             // +
    {0b11001, 0b11010, 0b00010, 0b00100, 0b01000, 0b01011, 0b10011},                 // %
};

_Static_assert(sizeof(font) / sizeof(font[0]) == sizeof(FONT_CHARS) - 1, "font table size");

#define HUD_MAX 100000
static float hud_v[HUD_MAX * 2];
static float hud_c[HUD_MAX * 4];
static int   hud_n = 0;

static void hud_rect(float x, float y, float w, float h, float r, float g, float b, float a) {
    if (hud_n + 6 > HUD_MAX) return;
    float xs[6] = {x, x + w, x + w, x, x + w, x};
    float ys[6] = {y, y, y + h, y, y + h, y + h};
    for (int i = 0; i < 6; i++) {
        hud_v[hud_n * 2 + 0] = xs[i];
        hud_v[hud_n * 2 + 1] = ys[i];
        hud_c[hud_n * 4 + 0] = r;
        hud_c[hud_n * 4 + 1] = g;
        hud_c[hud_n * 4 + 2] = b;
        hud_c[hud_n * 4 + 3] = a;
        hud_n++;
    }
}

static float hud_text_width(const char *s, float scale) { return (float)strlen(s) * 6.0f * scale; }

static void hud_text_raw(float x, float y, float scale, const char *s,
                         float r, float g, float b, float a) {
    for (; *s; s++, x += 6.0f * scale) {
        const char *p = strchr(FONT_CHARS, toupper((unsigned char)*s));
        if (!p || !*p) continue;
        const unsigned char *rows = font[p - FONT_CHARS];
        for (int row = 0; row < 7; row++) {
            int col = 0;
            while (col < 5) {
                if (rows[row] & (1 << (4 - col))) {
                    int start = col;
                    while (col < 5 && (rows[row] & (1 << (4 - col)))) col++;
                    hud_rect(x + start * scale, y + row * scale, (col - start) * scale, scale, r, g, b, a);
                } else {
                    col++;
                }
            }
        }
    }
}

static void hud_text(float x, float y, float scale, const char *s, float r, float g, float b) {
    hud_text_raw(x + scale, y + scale, scale, s, 0, 0, 0, 0.8f);   // drop shadow
    hud_text_raw(x, y, scale, s, r, g, b, 1.0f);
}

static void hud_text_centered(float y, float scale, const char *s, float r, float g, float b) {
    hud_text((960.0f - hud_text_width(s, scale)) / 2.0f, y, scale, s, r, g, b);
}

static void hud_bar(float x, float y, float w, float h, float frac,
                    float r, float g, float b) {
    if (frac < 0.0f) frac = 0.0f;
    if (frac > 1.0f) frac = 1.0f;
    hud_rect(x - 3, y - 3, w + 6, h + 6, 0.02f, 0.02f, 0.03f, 0.85f);   // frame
    hud_rect(x, y, w, h, 0.14f, 0.12f, 0.12f, 0.9f);                    // empty part
    hud_rect(x, y, w * frac, h, r, g, b, 1.0f);                         // fill
    hud_rect(x, y, w * frac, h * 0.35f, fminf(r + 0.2f, 1.0f), fminf(g + 0.2f, 1.0f),
             fminf(b + 0.2f, 1.0f), 0.55f);                              // highlight
}

static void hud_bars(void) {
    float hw = HEALTH_BAR_W * (player_max_hp / 100.0f);
    float sw = STAMINA_BAR_W * (player_max_stam / 100.0f);
    hud_bar(BAR_X, BAR_Y, hw, HEALTH_BAR_H, player_hp / player_max_hp, HEALTH_COLOR);
    hud_bar(BAR_X, BAR_Y + HEALTH_BAR_H + BAR_GAP, sw, STAMINA_BAR_H,
            player_stam / player_max_stam, STAMINA_COLOR);
}

#define PREVIEW_X  370.0f
#define PREVIEW_Y  110.0f
#define PREVIEW_W  250.0f
#define PREVIEW_H  230.0f

// Health bar + name floating above each living enemy's head.
static void hud_enemy_bars(void) {
    for (int i = 0; i < NUM_ENEMIES; i++) {
        const Enemy *e = &enemies[i];
        const EnemyDef *d = &enemy_defs[e->type];
        if (e->state == E_DEAD || e->zone != zone) continue;
        // Hidden while it is behind a closed door.
        if (!los_clear(e->x, e->z, g_cam_x, g_cam_z)) continue;
        float dx = e->x - g_cam_x, dz = e->z - g_cam_z;
        float dist = sqrtf(dx * dx + dz * dz);
        if (dist > 18.0f) continue;
        float sx, sy;
        float head = d->bar_height + (e->state == E_LUNGE ? 0.2f : 0.0f);
        if (!project_point(e->x, head, e->z, &sx, &sy)) continue;
        float w = fminf(96.0f, fmaxf(44.0f, 230.0f / (dist + 0.5f)));
        hud_bar(sx - w / 2, sy, w, 7.0f, e->hp / (e->maxhp > 0.0f ? e->maxhp : d->max_hp), 0.85f, 0.18f, 0.14f);
        if (dist < 10.0f)
            hud_text(sx - hud_text_width(d->name, 2) / 2, sy - 20.0f, 2, d->name, 0.95f, 0.9f, 0.8f);
        if (e->state == E_WINDUP)   // attack warning
            hud_text(sx - 12.0f, sy - 62.0f, 4, "!", 1.0f, 0.25f, 0.15f);
    }
}

static void hud_panel(float x, float y, float w, float h) {
    hud_rect(0, 0, 960, 544, 0, 0, 0, 0.45f);
    hud_rect(x, y, w, h, 0.05f, 0.05f, 0.08f, 0.88f);
    hud_rect(x, y, w, 4, 0.7f, 0.6f, 0.3f, 1.0f);
    hud_rect(x, y + h - 4, w, 4, 0.7f, 0.6f, 0.3f, 1.0f);
}

static void hud_menu_list(float x, float y, float row, float w, const char *const *labels, int n, int sel) {
    for (int i = 0; i < n; i++) {
        float yy = y + i * row;
        if (i == sel) hud_rect(x - 18, yy - 6, w, 32, 0.25f, 0.22f, 0.12f, 0.9f);
        hud_text(x - 6, yy, 3, i == sel ? ">" : " ", 1.0f, 0.9f, 0.4f);
        hud_text(x + 28, yy, 3, labels[i], 0.9f, 0.9f, 0.9f);
    }
}

static void hud_text_wrapped(float x, float y, float scale, const char *s, int maxc, int shown,
                             float r, float g, float b);

static void hud_pause(void) {
    static const char *const labels[3] = { "BESTIARY", "MAIN MENU", "QUIT GAME" };
    hud_panel(330, 120, 300, 300);
    hud_text(360, 142, 4, "ACTIONS", 0.95f, 0.85f, 0.5f);
    hud_menu_list(372, 210, 44, 250, labels, 3, pause_sel);
    hud_text(360, 366, 2, "THE WORLD KEEPS MOVING", 0.7f, 0.7f, 0.75f);
    hud_text(360, 388, 2, "START: CLOSE", 0.8f, 0.8f, 0.8f);
}

static void hud_beacon(void) {
    static const char *const labels[4] = { "SAVE", "REST", "LEVEL UP", "TELEPORT" };
    hud_panel(330, 100, 300, 320);
    hud_text(360, 122, 4, "BEACON", 0.6f, 0.9f, 1.0f);
    hud_menu_list(372, 195, 44, 250, labels, 4, beacon_sel);
    hud_text(360, 384, 2, "O: CLOSE", 0.8f, 0.8f, 0.8f);
}

static void hud_bestiary(void) {
    hud_panel(60, 40, 840, 464);
    hud_text(90, 62, 4, "BESTIARY", 0.95f, 0.85f, 0.5f);
    for (int i = 0; i < ENEMY_TYPE_COUNT; i++) {
        float y = 130 + i * 34;
        if (i == bestiary_sel) hud_rect(78, y - 6, 270, 32, 0.25f, 0.22f, 0.12f, 0.9f);
        hud_text(90, y, 3, i == bestiary_sel ? ">" : " ", 1.0f, 0.9f, 0.4f);
        hud_text(126, y, 3, bestiary_seen[i] ? enemy_defs[i].name : "UNKNOWN", 0.9f, 0.9f, 0.9f);
    }

    // Frame for the spinning 3D model (the model itself is drawn after the HUD).
    hud_rect(PREVIEW_X - 3, PREVIEW_Y - 3, PREVIEW_W + 6, PREVIEW_H + 6, 0.7f, 0.6f, 0.3f, 1.0f);
    hud_rect(PREVIEW_X, PREVIEW_Y, PREVIEW_W, PREVIEW_H, 0.10f, 0.10f, 0.14f, 1.0f);

    if (!bestiary_seen[bestiary_sel]) {
        hud_text(PREVIEW_X + 62, PREVIEW_Y + 100, 3, "UNKNOWN", 0.6f, 0.6f, 0.65f);
        hud_text(PREVIEW_X, PREVIEW_Y + PREVIEW_H + 20, 2, "ENCOUNTER IT TO RECORD IT.", 0.7f, 0.7f, 0.75f);
    } else {
        const EnemyDef *d = &enemy_defs[bestiary_sel];
        char b[64];
        hud_text(90, 412, 2, d->desc[0], 0.75f, 0.75f, 0.8f);
        hud_text(90, 436, 2, d->desc[1], 0.75f, 0.75f, 0.8f);

        snprintf(b, sizeof(b), "HEALTH: %d", (int)d->max_hp);
        hud_text(640, 120, 3, b, 0.9f, 0.85f, 0.55f);

        char wk[64];
        int any = 0;
        snprintf(wk, sizeof(wk), "WEAK TO:");
        for (int k = 0; k < DMG_TYPE_COUNT; k++) {
            if (d->resist[k] > 1.05f) {
                size_t l = strlen(wk);
                snprintf(wk + l, sizeof(wk) - l, " %s", dmg_type_short[k]);
                any = 1;
            }
        }
        if (!any) {
            size_t l = strlen(wk);
            snprintf(wk + l, sizeof(wk) - l, " NONE");
        }
        snprintf(b, sizeof(b), "XP REWARD: %d", d->xp);
        hud_text(640, 144, 2, b, 0.7f, 0.9f, 0.7f);
        snprintf(b, sizeof(b), "ATTACK DAMAGE: %d", (int)d->damage);
        hud_text(640, 166, 2, b, 0.95f, 0.6f, 0.5f);
        hud_text_wrapped(640, 190, 2, wk, 21, 999, 0.9f, 0.9f, 0.9f);

        hud_text(640, 236, 2, "DAMAGE TAKEN:", 0.7f, 0.7f, 0.75f);
        for (int k = 0; k < DMG_TYPE_COUNT; k++) {
            float m = d->resist[k];
            snprintf(b, sizeof(b), "%s: %s X%.1f", dmg_type_short[k],
                     m < 0.05f ? "IMMUNE" : (m > 1.05f ? "WEAK" : (m < 0.95f ? "RESISTANT" : "NEUTRAL")), m);
            float cr = m > 1.05f ? 1.0f : (m < 0.95f ? 0.6f : 0.85f), cg = m > 1.05f ? 0.85f : (m < 0.95f ? 0.7f : 0.85f), cb = m > 1.05f ? 0.45f : (m < 0.95f ? 0.9f : 0.85f);
            hud_text(640, 262 + k * 26, 2, b, cr, cg, cb);
        }
    }
    hud_text(90, 470, 2, "O: BACK", 0.8f, 0.8f, 0.8f);
}

// Draws s word-wrapped at maxc characters per line, revealing only the first `shown` characters.
static void hud_text_wrapped(float x, float y, float scale, const char *s, int maxc, int shown,
                             float r, float g, float b) {
    int len = (int)strlen(s), pos = 0, line = 0;
    while (pos < len) {
        int end = pos + maxc;
        if (end >= len) end = len;
        else { int k = end; while (k > pos && s[k] != ' ') k--; if (k > pos) end = k; }
        int n = end - pos, vis = shown - pos;
        if (vis <= 0) break;
        if (vis < n) n = vis;
        char buf[96];
        if (n > 95) n = 95;
        memcpy(buf, s + pos, n);
        buf[n] = 0;
        hud_text(x, y + line * scale * 10.0f, scale, buf, r, g, b);
        pos = end;
        while (pos < len && s[pos] == ' ') pos++;
        line++;
    }
}

static void hud_dialogue(void) {
    const float x = 60, y = 366, w = 840, h = 136;
    hud_rect(x, y, w, h, 0.03f, 0.03f, 0.05f, 0.88f);
    hud_rect(x, y, w, 3, 0.7f, 0.6f, 0.3f, 1.0f);
    hud_rect(x, y + h - 3, w, 3, 0.7f, 0.6f, 0.3f, 1.0f);
    hud_text(x + 30, y + 16, 2, dlg_who == 2 ? "BLACKSMITH" : dlg_who ? "DYING MAN" : "WANDERER", 0.85f, 0.75f, 0.45f);
    const char *txt = npc_text();
    int shown = (int)dlg_chars;
    hud_text_wrapped(x + 30, y + 48, 3, txt, 42, shown, 0.92f, 0.9f, 0.85f);
    if (shown >= (int)strlen(txt) && ((int)(g_time * 2.0f) & 1))
        hud_text(x + w - 50, y + h - 34, 2, npc_last_chunk() ? "X" : ">", 0.9f, 0.8f, 0.4f);
}

static int pend_total(void) { return pend[0] + pend[1] + pend[2] + pend[3]; }

static void hud_box(float x, float y, float w, float h) {
    hud_rect(x, y, w, h, 0.06f, 0.055f, 0.05f, 0.94f);
    hud_rect(x, y, w, 2, 0.40f, 0.33f, 0.20f, 1.0f);
    hud_rect(x, y + h - 2, w, 2, 0.40f, 0.33f, 0.20f, 1.0f);
    hud_rect(x, y, 2, h, 0.40f, 0.33f, 0.20f, 1.0f);
    hud_rect(x + w - 2, y, 2, h, 0.40f, 0.33f, 0.20f, 1.0f);
    hud_rect(x + 4, y + 4, w - 8, 1, 0.20f, 0.17f, 0.12f, 1.0f);
}

static void hud_section(float x, float y, float w, const char *title) {
    hud_text(x, y, 2, title, 0.88f, 0.80f, 0.55f);
    hud_rect(x, y + 19, w, 1, 0.45f, 0.38f, 0.25f, 1.0f);
}

// Full-screen menu backdrop + title band shared by the level-up and equipment screens.
static void hud_header(const char *title) {
    hud_rect(0, 0, 960, 544, 0, 0, 0, 0.80f);
    hud_rect(0, 0, 960, 52, 0.03f, 0.03f, 0.04f, 0.97f);
    hud_rect(0, 52, 960, 2, 0.45f, 0.38f, 0.25f, 1.0f);
    hud_rect(16, 10, 32, 32, 0.70f, 0.60f, 0.30f, 1.0f);
    hud_rect(20, 14, 24, 24, 0.10f, 0.10f, 0.12f, 1.0f);
    hud_rect(27, 21, 10, 10, 0.92f, 0.80f, 0.40f, 1.0f);
    hud_text(64, 14, 3, title, 0.92f, 0.88f, 0.78f);
}

static void hud_footer(const char *l1, const char *l2) {
    hud_rect(0, 478, 960, 66, 0.03f, 0.03f, 0.04f, 0.97f);
    hud_rect(0, 478, 960, 2, 0.45f, 0.38f, 0.25f, 1.0f);
    hud_text(16, 490, 2, l1, 0.85f, 0.85f, 0.85f);
    hud_text(16, 514, 2, l2, 0.85f, 0.85f, 0.85f);
}

// "LABEL      cur > next" with the new value coloured when it changes.
static void hud_val_row(float x, float y, float w, const char *label, const char *cur, const char *next,
                        int changed, float nr, float ng, float nb) {
    hud_text(x, y, 2, label, 0.88f, 0.88f, 0.86f);
    hud_text(x + w - 80 - hud_text_width(cur, 2), y, 2, cur, 0.85f, 0.85f, 0.85f);
    hud_text(x + w - 70, y, 2, ">", 0.6f, 0.55f, 0.4f);
    if (changed) hud_text(x + w - hud_text_width(next, 2), y, 2, next, nr, ng, nb);
    else         hud_text(x + w - hud_text_width(next, 2), y, 2, next, 0.85f, 0.85f, 0.85f);
}

static void hud_val_int(float x, float y, float w, const char *label, int cur, int next, int up) {
    char a[24], b[24];
    snprintf(a, sizeof(a), "%d", cur);
    snprintf(b, sizeof(b), "%d", next);
    if (up) hud_val_row(x, y, w, label, a, b, cur != next, 0.45f, 0.65f, 1.0f);
    else    hud_val_row(x, y, w, label, a, b, cur != next, 1.0f, 0.55f, 0.35f);
}

// "LABEL   value" (right aligned).
static void hud_stat_row(float x, float y, float w, const char *label, const char *val) {
    hud_text(x, y, 2, label, 0.88f, 0.88f, 0.86f);
    hud_text(x + w - hud_text_width(val, 2), y, 2, val, 0.85f, 0.85f, 0.85f);
}

// Level-up screen (opened from the beacon). Loosely modelled on the Dark Souls one:
// you carry XP, pick attribute levels to buy, and see what they change before confirming.
static void hud_stats(void) {
    static const char *const names[4] = { "HEALTH", "STAMINA", "STRENGTH", "ATHLETICS" };
    const int pt = pend_total();
    const int lvl = player_level();
    const int cost = levels_cost(lvl, pt);
    const int lv[4] = { lv_hp, lv_stam, lv_str, lv_ath };
    const float hp_new   = MAX_HEALTH  + HP_PER_LEVEL   * attr_eff(lv_hp + pend[0]);
    const float st_new   = MAX_STAMINA + STAM_PER_LEVEL * attr_eff(lv_stam + pend[1]);
    const float mult_new = str_mult_for(lv_str + pend[2]);
    const float jump_new = jump_height_for(lv_ath + pend[3]);
    char a[48], b[48];

    hud_header("LEVEL UP");

    // ---------------- left: level, xp, attributes ----------------
    const float lx = 14, ly = 66, lw = 330, lh = 400, ix = lx + 14, iw = lw - 28;
    hud_box(lx, ly, lw, lh);
    hud_val_int(ix, ly + 18, iw, "LEVEL", lvl, lvl + pt, 1);
    hud_val_int(ix, ly + 46, iw, "XP", xp, xp - cost, 0);
    {   // what the levels picked so far cost, and what the next one would cost on top of that
        snprintf(a, sizeof(a), "%d", cost);
        hud_text(ix, ly + 74, 2, "TOTAL COST", 0.88f, 0.88f, 0.86f);
        hud_text(ix + iw - hud_text_width(a, 2), ly + 74, 2, a, 0.9f, 0.9f, 0.9f);
        int nxt = level_cost(lvl + pt);
        snprintf(a, sizeof(a), "%d", nxt);
        hud_text(ix, ly + 100, 2, "NEXT LEVEL", 0.88f, 0.88f, 0.86f);
        if (xp - cost >= nxt) hud_text(ix + iw - hud_text_width(a, 2), ly + 100, 2, a, 0.9f, 0.9f, 0.9f);
        else                  hud_text(ix + iw - hud_text_width(a, 2), ly + 100, 2, a, 1.0f, 0.35f, 0.3f);
    }

    hud_section(ix, ly + 134, iw, "ATTRIBUTES");
    for (int i = 0; i < 4; i++) {
        float y = ly + 164 + i * 38;
        if (i == stats_sel) {
            hud_rect(ix - 6, y - 9, iw + 12, 32, 0.50f, 0.30f, 0.10f, 0.50f);
            hud_rect(ix - 6, y - 9, iw + 12, 2, 0.85f, 0.65f, 0.30f, 0.9f);
            hud_rect(ix - 6, y + 21, iw + 12, 2, 0.85f, 0.65f, 0.30f, 0.9f);
        }
        hud_text(ix, y, 2, names[i], i == stats_sel ? 1.0f : 0.88f, i == stats_sel ? 0.92f : 0.88f, i == stats_sel ? 0.75f : 0.86f);
        snprintf(a, sizeof(a), "%d", lv[i] + 1);
        snprintf(b, sizeof(b), "%d", lv[i] + 1 + pend[i]);
        hud_text(ix + iw - 80 - hud_text_width(a, 2), y, 2, a, 0.85f, 0.85f, 0.85f);
        hud_text(ix + iw - 70, y, 2, ">", 0.6f, 0.55f, 0.4f);
        if (pend[i] > 0) hud_text(ix + iw - hud_text_width(b, 2), y, 2, b, 0.45f, 0.65f, 1.0f);
        else             hud_text(ix + iw - hud_text_width(b, 2), y, 2, b, 0.85f, 0.85f, 0.85f);
        if (i == stats_sel) hud_text(ix + iw - hud_text_width(b, 2) - 18, y, 2, "<", 0.95f, 0.8f, 0.4f);
    }

    // Confirm button
    {
        float bx = ix + 40, by = ly + lh - 62, bw = iw - 80, bh = 36;
        int sel = (stats_sel == 4);
        hud_rect(bx, by, bw, bh, sel ? 0.30f : 0.10f, sel ? 0.20f : 0.09f, sel ? 0.08f : 0.08f, 0.95f);
        hud_rect(bx, by, bw, 2, 0.75f, 0.62f, 0.32f, 1.0f);
        hud_rect(bx, by + bh - 2, bw, 2, 0.75f, 0.62f, 0.32f, 1.0f);
        hud_rect(bx, by, 2, bh, 0.75f, 0.62f, 0.32f, 1.0f);
        hud_rect(bx + bw - 2, by, 2, bh, 0.75f, 0.62f, 0.32f, 1.0f);
        float c = (pt > 0 || sel) ? 1.0f : 0.6f;
        hud_text(bx + (bw - hud_text_width("CONFIRM", 2)) / 2, by + 11, 2, "CONFIRM", c, c * 0.92f, c * 0.75f);
    }

    // ---------------- middle: base power + attack power ----------------
    const float mx = 356, mw = 290, mix = mx + 14, miw = mw - 28;
    hud_box(mx, ly, mw, lh);
    hud_section(mix, ly + 16, miw, "BASE POWER");
    hud_val_int(mix, ly + 46, miw, "HEALTH", (int)player_max_hp, (int)hp_new, 1);
    hud_val_int(mix, ly + 72, miw, "STAMINA", (int)player_max_stam, (int)st_new, 1);
    snprintf(a, sizeof(a), "X%.1f", str_mult());
    snprintf(b, sizeof(b), "X%.1f", mult_new);
    hud_val_row(mix, ly + 98, miw, "DAMAGE", a, b, lv_str + pend[2] != lv_str, 0.45f, 0.65f, 1.0f);
    snprintf(a, sizeof(a), "%.2f", jump_height());
    snprintf(b, sizeof(b), "%.2f", jump_new);
    hud_val_row(mix, ly + 124, miw, "JUMP", a, b, lv_ath + pend[3] != lv_ath, 0.45f, 0.65f, 1.0f);

    hud_section(mix, ly + 166, miw, "ATTACK POWER");
    { int nw = 0; for (int i = 0; i < inv_n; i++) if (item_defs[inv[i]].kind == KIND_WEAPON) nw++; if (nw == 0) hud_text(mix, ly + 196, 2, "NO WEAPONS", 0.55f, 0.55f, 0.55f); }
    int wr = 0;
    for (int i = 0; i < inv_n && wr < 6; i++) {
        const ItemDef *d = &item_defs[inv[i]];
        if (d->kind != KIND_WEAPON) continue;
        float wy = ly + 196 + wr * 26;
        wr++;
        int slot = -1;
        for (int k = 0; k < QUICK_SLOTS; k++) if (quick[k] == inv[i]) slot = k;
        if (slot >= 0) hud_rect(mix, wy + 4, 6, 6, slot == active_quick ? 0.92f : 0.55f, slot == active_quick ? 0.80f : 0.48f, 0.40f, 1.0f);
        hud_val_int(mix + 14, wy, miw - 14, d->name, (int)(d->damage * str_mult() + 0.001f),
                    (int)(d->damage * mult_new + 0.001f), 1);
    }

    // ---------------- right: description + cost of upcoming levels ----------------
    const float rx = 658, rw = 288, rix = rx + 14, riw = rw - 28;
    hud_box(rx, ly, rw, lh);
    hud_section(rix, ly + 16, riw, "ABOUT");
    {
        char desc[140];
        if (stats_sel == 0)      snprintf(desc, sizeof(desc), "RAISES MAX HEALTH BY %d PER POINT. GAINS FADE PAST %d POINTS. MAX %d.", (int)HP_PER_LEVEL, SOFTCAP_START, ATTR_CAP);
        else if (stats_sel == 1) snprintf(desc, sizeof(desc), "RAISES MAX STAMINA BY %d PER POINT. GAINS FADE PAST %d POINTS. MAX %d.", (int)STAM_PER_LEVEL, SOFTCAP_START, ATTR_CAP);
        else if (stats_sel == 2) snprintf(desc, sizeof(desc), "RAISES WEAPON DAMAGE BY %d%% PER POINT. GAINS FADE PAST %d POINTS. MAX %d.", (int)(STR_BONUS * 100.0f + 0.5f), SOFTCAP_START, ATTR_CAP);
        else if (stats_sel == 3) snprintf(desc, sizeof(desc), "RAISES YOUR JUMP. SOME LEDGES NEED HIGH ATHLETICS. GAINS FADE PAST %d POINTS. MAX %d.", SOFTCAP_START, ATTR_CAP);
        else                     snprintf(desc, sizeof(desc), "SPEND XP ON THE CHOSEN ATTRIBUTES AND LEVEL UP.");
        hud_text_wrapped(rix, ly + 46, 2, desc, 22, 999, 0.82f, 0.82f, 0.8f);
    }
    hud_section(rix, ly + 170, riw, "XP COST");
    for (int k = 0; k < 6; k++) {
        float y = ly + 200 + k * 26;
        snprintf(a, sizeof(a), "TO LEVEL %d", lvl + pt + k + 1);
        snprintf(b, sizeof(b), "%d", level_cost(lvl + pt + k));
        hud_text(rix, y, 2, a, k == 0 ? 0.95f : 0.65f, k == 0 ? 0.9f : 0.65f, k == 0 ? 0.75f : 0.65f);
        hud_text(rix + riw - hud_text_width(b, 2), y, 2, b, k == 0 ? 0.95f : 0.65f, k == 0 ? 0.9f : 0.65f, k == 0 ? 0.75f : 0.65f);
    }

    hud_footer("UP/DOWN: SELECT    LEFT/RIGHT: ADJUST    X: ADD / CONFIRM", "O: BACK");
}

// "LABEL  cur > next" for comparing the highlighted weapon with the one in the slot.
static void hud_cmp_val(float x, float y, float w, const char *label, float cur, float next,
                        int cmp, int higher_better, const char *fmt) {
    char a[24], b[24];
    snprintf(a, sizeof(a), fmt, cur);
    snprintf(b, sizeof(b), fmt, next);
    if (!cmp) { hud_stat_row(x, y, w, label, b); return; }
    int up = next > cur + 1e-4f, down = next < cur - 1e-4f;
    int good = higher_better ? up : down, bad = higher_better ? down : up;
    if (good)      hud_val_row(x, y, w, label, a, b, 1, 0.45f, 0.65f, 1.0f);
    else if (bad)  hud_val_row(x, y, w, label, a, b, 1, 1.0f, 0.55f, 0.35f);
    else           hud_val_row(x, y, w, label, a, b, 0, 0, 0, 0);
}

// Equipment screen: three weapon slots on the left, your items in the middle, details on the right.
static void hud_slot_row(float x, float y, float w, float h, int sel, int tgt) {
    hud_rect(x - 6, y - 4, w + 12, h, sel ? 0.50f : 0.12f, sel ? 0.30f : 0.10f, sel ? 0.10f : 0.08f, sel ? 0.5f : 0.6f);
    if (sel || tgt) {
        hud_rect(x - 6, y - 4, w + 12, 2, 0.85f, 0.65f, 0.30f, sel ? 0.9f : 0.5f);
        hud_rect(x - 6, y - 4 + h - 2, w + 12, 2, 0.85f, 0.65f, 0.30f, sel ? 0.9f : 0.5f);
    }
}

static void hud_equipment(void) {
    const int shown = eq_shown_item();
    const int cur_id = eq_current(eq_slot);
    int list[INV_MAX];
    const int ln = eq_build_list(eq_slot, list);
    char a[48];

    hud_header("EQUIPMENT");

    // ---------------- left: weapon slots, armor slots, spell ----------------
    const float lx = 14, ly = 66, lw = 300, lh = 400, ix = lx + 14, iw = lw - 28;
    hud_box(lx, ly, lw, lh);
    hud_section(ix, ly + 12, iw, "WEAPONS");
    for (int i = 0; i < QUICK_SLOTS; i++) {
        float y = ly + 40 + i * 44;
        int sel = (!eq_focus && i == eq_slot), tgt = (eq_focus && i == eq_slot);
        hud_slot_row(ix, y, iw, 40, sel, tgt);
        hud_rect(ix, y + 2, 32, 32, 0.40f, 0.33f, 0.20f, 1.0f);
        hud_rect(ix + 2, y + 4, 28, 28, 0.10f, 0.09f, 0.08f, 1.0f);
        char dn[2] = { (char)('1' + i), 0 };
        hud_text(ix + 9, y + 11, 2, dn, 0.9f, 0.8f, 0.5f);
        int id = quick[i];
        if (id >= 0) {
            hud_text(ix + 42, y + 2, 2, item_defs[id].name, 0.95f, 0.95f, 0.92f);
            if (i == active_quick) hud_text(ix + 42, y + 19, 2, "IN HAND", 0.92f, 0.80f, 0.40f);
            else                   hud_text(ix + 42, y + 19, 2, dmg_type_names[item_defs[id].dmg_type], 0.6f, 0.6f, 0.62f);
        } else {
            hud_text(ix + 42, y + 11, 2, "EMPTY", 0.5f, 0.5f, 0.52f);
        }
    }
    hud_section(ix, ly + 176, iw, "ARMOR");
    for (int i = 0; i < ARMOR_SLOTS; i++) {
        float y = ly + 204 + i * 32;
        int slot = QUICK_SLOTS + i;
        int sel = (!eq_focus && slot == eq_slot), tgt = (eq_focus && slot == eq_slot);
        hud_slot_row(ix, y, iw, 28, sel, tgt);
        hud_text(ix, y + 5, 2, armor_slot_names[i], 0.70f, 0.62f, 0.40f);
        if (armor[i] >= 0) hud_text(ix + 66, y + 5, 2, item_defs[armor[i]].name, 0.95f, 0.95f, 0.92f);
        else               hud_text(ix + 66, y + 5, 2, "EMPTY", 0.5f, 0.5f, 0.52f);
    }
    {
        float y = ly + 340;
        int sel = (!eq_focus && eq_slot == EQ_LH), tgt = (eq_focus && eq_slot == EQ_LH);
        hud_slot_row(ix, y, iw, 28, sel, tgt);
        hud_text(ix, y + 5, 2, "L HAND", 0.70f, 0.62f, 0.40f);
        hud_text(ix + 90, y + 5, 2, left_hand == LH_FIRE ? "FIREBALL" : (left_hand == LH_TORCH ? "TORCH" : "EMPTY"),
                 left_hand ? 0.95f : 0.5f, left_hand ? 0.95f : 0.5f, left_hand ? 0.92f : 0.52f);
    }
    snprintf(a, sizeof(a), "-%d%%", (int)(armor_reduction() * 100.0f + 0.5f));
    hud_stat_row(ix, ly + 372, iw, "DAMAGE TAKEN", a);

    // ---------------- middle: items that fit the selected slot ----------------
    const float mx = 326, mw = 300, mix = mx + 14, miw = mw - 28;
    hud_box(mx, ly, mw, lh);
    {
        char t[24];
        if (eq_slot == EQ_LH) snprintf(t, sizeof(t), "LEFT HAND");
        else if (eq_slot < QUICK_SLOTS) snprintf(t, sizeof(t), "WEAPONS");
        else snprintf(t, sizeof(t), "%s ARMOR", armor_slot_names[eq_slot - QUICK_SLOTS]);
        hud_section(mix, ly + 16, miw, t);
    }
    for (int i = 0; i <= ln; i++) {
        float y = ly + 46 + i * 30;
        int hl = (eq_focus && i == inv_sel);
        if (hl) {
            hud_rect(mix - 6, y - 6, miw + 12, 28, 0.50f, 0.30f, 0.10f, 0.50f);
            hud_rect(mix - 6, y - 6, miw + 12, 2, 0.85f, 0.65f, 0.30f, 0.9f);
            hud_rect(mix - 6, y + 20, miw + 12, 2, 0.85f, 0.65f, 0.30f, 0.9f);
        }
        float c = eq_focus ? 0.92f : 0.62f;
        if (i == 0 && !eq_focus) c = 0.5f;
        hud_text(mix, y, 2, i == 0 ? "- EMPTY -" : eq_item_name(eq_slot, list[i - 1]), c, c, c * 0.95f);
        if (i > 0) {   // which slots hold it
            float tx = mix + miw - 20;
            if (eq_slot < QUICK_SLOTS) {
                for (int k = QUICK_SLOTS - 1; k >= 0; k--) {
                    if (quick[k] != list[i - 1]) continue;
                    char dn[2] = { (char)('1' + k), 0 };
                    hud_rect(tx, y - 3, 20, 20, 0.40f, 0.33f, 0.20f, 1.0f);
                    hud_rect(tx + 2, y - 1, 16, 16, 0.10f, 0.09f, 0.08f, 1.0f);
                    hud_text(tx + 4, y - 1, 2, dn, 0.92f, 0.8f, 0.45f);
                    tx -= 24;
                }
            } else if (eq_slot == EQ_LH ? (left_hand == list[i - 1]) : (armor[eq_slot - QUICK_SLOTS] == list[i - 1])) {
                hud_rect(tx, y - 3, 20, 20, 0.40f, 0.33f, 0.20f, 1.0f);
                hud_rect(tx + 2, y - 1, 16, 16, 0.10f, 0.09f, 0.08f, 1.0f);
                hud_text(tx + 4, y - 1, 2, "E", 0.92f, 0.8f, 0.45f);
            }
        }
    }
    if (ln == 0) hud_text_wrapped(mix, ly + 84, 2, eq_slot == EQ_LH ? "NOTHING TO HOLD YET." : (eq_slot < QUICK_SLOTS ? "NO WEAPONS YET." : "NOTHING TO WEAR HERE YET."), 22, 99, 0.55f, 0.55f, 0.55f);

    // ---------------- right: item details ----------------
    const float rx = 638, rw = 308, rix = rx + 14, riw = rw - 28;
    hud_box(rx, ly, rw, lh);
    hud_rect(EQ_PREVIEW_X - 2, EQ_PREVIEW_Y - 2, EQ_PREVIEW_W + 4, EQ_PREVIEW_H + 4, 0.45f, 0.38f, 0.25f, 1.0f);
    hud_rect(EQ_PREVIEW_X, EQ_PREVIEW_Y, EQ_PREVIEW_W, EQ_PREVIEW_H, 0.08f, 0.08f, 0.11f, 1.0f);
    if (eq_slot == EQ_LH) {
        const int lh = shown;
        hud_text(rix, ly + 160, 3, lh == LH_TORCH ? "TORCH" : (lh == LH_FIRE ? "FIREBALL" : "EMPTY"), 0.95f, 0.95f, 0.9f);
        hud_text(rix, ly + 190, 2, lh == LH_FIRE ? "SPELL - FIRE" : (lh == LH_TORCH ? "LIGHT" : "NOTHING"), 0.92f, 0.80f, 0.40f);
        hud_text_wrapped(rix, ly + 226, 2, lh == LH_FIRE ? "HURL A BALL OF FLAME WITH L. IT BURSTS ON IMPACT." :
                         (lh == LH_TORCH ? "LIGHTS A SMALL AREA IN THE DARK. THE HAND IS FULL, SO NO SPELLS WHILE IT BURNS." : "AN OPEN HAND. L DOES NOTHING."),
                         23, 999, 0.72f, 0.72f, 0.76f);
    } else if (shown < 0) {
        hud_text(rix, ly + 160, 3, eq_slot < QUICK_SLOTS ? "UNARMED" : "NOTHING", 0.7f, 0.7f, 0.72f);
        hud_text_wrapped(rix, ly + 196, 2, eq_slot < QUICK_SLOTS ? "BARE HANDS DEAL NO DAMAGE." : "NOTHING WORN HERE.", 23, 99, 0.6f, 0.6f, 0.62f);
    } else if (item_defs[shown].kind == KIND_WEAPON) {
        const ItemDef *it = &item_defs[shown];
        const int cmp = eq_focus && cur_id >= 0 && cur_id != shown;
        const ItemDef *cu = cmp ? &item_defs[cur_id] : it;
        hud_text(rix, ly + 160, 3, it->name, 0.95f, 0.95f, 0.9f);
        hud_text(rix, ly + 190, 2, dmg_type_names[it->dmg_type], 0.92f, 0.80f, 0.40f);
        hud_cmp_val(rix, ly + 218, riw, "ATTACK",  weapon_damage(cu) + 0.001f, weapon_damage(it) + 0.001f, cmp, 1, "%.0f");
        hud_cmp_val(rix, ly + 242, riw, "STAMINA", cu->stamina_cost, it->stamina_cost, cmp, 0, "%.0f");
        hud_cmp_val(rix, ly + 266, riw, "RANGE",   cu->range, it->range, cmp, 1, "%.1f");
        hud_cmp_val(rix, ly + 290, riw, "SPEED",   cu->swing_time, it->swing_time, cmp, 0, "%.2f");
        hud_text_wrapped(rix, ly + 326, 2, it->desc, 23, 999, 0.72f, 0.72f, 0.76f);
    } else {
        const ItemDef *it = &item_defs[shown];
        const int cmp = eq_focus && cur_id != shown;
        float cur_def = cur_id >= 0 ? item_defs[cur_id].defense : 0.0f;
        float tot_now = armor_reduction() * 100.0f;
        float tot_new = tot_now - cur_def * 100.0f + it->defense * 100.0f;
        hud_text(EQ_PREVIEW_X + (EQ_PREVIEW_W - hud_text_width(armor_slot_names[it->kind - 1], 4)) / 2.0f, EQ_PREVIEW_Y + 46, 4, armor_slot_names[it->kind - 1], 0.55f, 0.50f, 0.38f);
        hud_text(rix, ly + 160, 2, it->name, 0.95f, 0.95f, 0.9f);
        hud_text(rix, ly + 190, 2, "ARMOR", 0.92f, 0.80f, 0.40f);
        hud_cmp_val(rix, ly + 218, riw, "DEFENSE", cmp ? cur_def * 100.0f : it->defense * 100.0f, it->defense * 100.0f, cmp, 1, "%.0f%%");
        hud_cmp_val(rix, ly + 242, riw, "TOTAL", tot_now, cmp ? tot_new : tot_now, cmp, 1, "%.0f%%");
        hud_text_wrapped(rix, ly + 286, 2, it->desc, 23, 999, 0.72f, 0.72f, 0.76f);
    }

    if (!eq_focus) hud_footer("UP/DOWN: SLOT    X: CHOOSE    LEFT/RIGHT: ITEMS PAGE    O: BACK", "IN GAME: D-PAD UP/DOWN SWAPS WEAPONS, LEFT/RIGHT CHANGES ITEM");
    else           hud_footer("UP/DOWN: SELECT    X: EQUIP    O: BACK", eq_slot == EQ_LH ? "THE TORCH TAKES THE HAND, SO NO SPELLS WHILE HELD" : (eq_slot < QUICK_SLOTS ? "EQUIPPING A WEAPON THAT IS IN ANOTHER SLOT SWAPS THEM" : "ARMOR REDUCES ALL DAMAGE YOU TAKE"));
}

static void hud_cons_icon(int c, float x, float y, float sz, float al) {
    if (c == CONS_HERB) {
        hud_rect(x + sz * 0.46f, y + sz * 0.40f, sz * 0.08f, sz * 0.50f, 0.36f, 0.52f, 0.20f, al);
        hud_rect(x + sz * 0.18f, y + sz * 0.30f, sz * 0.30f, sz * 0.22f, 0.28f, 0.66f, 0.24f, al);
        hud_rect(x + sz * 0.52f, y + sz * 0.16f, sz * 0.30f, sz * 0.22f, 0.20f, 0.52f, 0.18f, al);
        hud_rect(x + sz * 0.40f, y + sz * 0.08f, sz * 0.20f, sz * 0.14f, 0.95f, 0.86f, 0.30f, al);
    } else if (c == CONS_POTION) {
        hud_rect(x + sz * 0.40f, y + sz * 0.10f, sz * 0.20f, sz * 0.12f, 0.60f, 0.42f, 0.24f, al);
        hud_rect(x + sz * 0.42f, y + sz * 0.22f, sz * 0.16f, sz * 0.18f, 0.72f, 0.80f, 0.86f, al);
        hud_rect(x + sz * 0.26f, y + sz * 0.40f, sz * 0.48f, sz * 0.46f, 0.80f, 0.10f, 0.16f, al);
        hud_rect(x + sz * 0.32f, y + sz * 0.46f, sz * 0.08f, sz * 0.26f, 1.0f, 0.75f, 0.75f, al);
    } else if (c == CONS_BOMB) {
        hud_rect(x + sz * 0.24f, y + sz * 0.38f, sz * 0.52f, sz * 0.48f, 0.20f, 0.20f, 0.24f, al);
        hud_rect(x + sz * 0.32f, y + sz * 0.30f, sz * 0.36f, sz * 0.64f, 0.26f, 0.26f, 0.30f, al);
        hud_rect(x + sz * 0.46f, y + sz * 0.18f, sz * 0.10f, sz * 0.14f, 0.55f, 0.42f, 0.24f, al);
        hud_rect(x + sz * 0.54f, y + sz * 0.08f, sz * 0.12f, sz * 0.12f, 1.0f, 0.62f, 0.12f, al);
    }
}

// Bottom-centre: the three-slot hot bar for consumables.
static void hud_hotbar(void) {
    const float bw = 40, gap = 8, x0 = 480.0f - (3 * bw + 2 * gap) / 2.0f, y = 468;
    int ac = hot[active_hot];
    if (ac >= 0 && hot_name_t > 0.0f) {
        const char *nm = cons_names[ac];
        hud_text(480.0f - hud_text_width(nm, 2) / 2.0f, y - 20, 2, nm, 0.92f, 0.88f, 0.75f);
    }
    for (int i = 0; i < HOT_SLOTS; i++) {
        float x = x0 + i * (bw + gap);
        int act = (i == active_hot), c = hot[i];
        hud_rect(x, y, bw, bw, 0.0f, 0.0f, 0.0f, act ? 0.70f : 0.42f);
        float br = act ? 0.92f : 0.40f, bg = act ? 0.80f : 0.34f, bb = act ? 0.40f : 0.24f;
        hud_rect(x, y, bw, 2, br, bg, bb, 1.0f); hud_rect(x, y + bw - 2, bw, 2, br, bg, bb, 1.0f);
        hud_rect(x, y, 2, bw, br, bg, bb, 1.0f); hud_rect(x + bw - 2, y, 2, bw, br, bg, bb, 1.0f);
        if (c >= 0) {
            hud_cons_icon(c, x + 2, y + 2, bw - 4, cons_count[c] > 0 ? 1.0f : 0.25f);
            char n[8];
            snprintf(n, sizeof(n), "%d", cons_count[c]);
            hud_text(x + bw - 4 - hud_text_width(n, 2), y + bw - 16, 2, n, 1.0f, 1.0f, 1.0f);
        }
    }
}

static void hud_items(void) {
    int il[CONS_COUNT], iln = 0;
    for (int c = 0; c < CONS_COUNT; c++) if (cons_count[c] > 0) il[iln++] = c;
    hud_header("ITEMS");
    const float lx = 14, ly = 66, lw = 300, lh = 400, ix = lx + 14, iw = lw - 28;
    hud_box(lx, ly, lw, lh);
    hud_section(ix, ly + 12, iw, "HOT BAR");
    for (int i = 0; i < HOT_SLOTS; i++) {
        float y = ly + 40 + i * 54;
        int sel = (!items_focus && i == items_slot), tgt = (items_focus && i == items_slot);
        hud_slot_row(ix, y, iw, 48, sel, tgt);
        hud_rect(ix + 4, y + 4, 40, 40, 0.40f, 0.33f, 0.20f, 1.0f);
        hud_rect(ix + 6, y + 6, 36, 36, 0.10f, 0.09f, 0.08f, 1.0f);
        int c = hot[i];
        if (c >= 0) {
            hud_cons_icon(c, ix + 6, y + 6, 36, cons_count[c] > 0 ? 1.0f : 0.3f);
            hud_text(ix + 54, y + 8, 2, cons_names[c], 0.95f, 0.95f, 0.92f);
            char n[16];
            snprintf(n, sizeof(n), "HELD: %d", cons_count[c]);
            hud_text(ix + 54, y + 26, 2, n, i == active_hot ? 0.92f : 0.6f, i == active_hot ? 0.80f : 0.6f, i == active_hot ? 0.40f : 0.62f);
        } else {
            hud_text(ix + 54, y + 17, 2, "EMPTY", 0.5f, 0.5f, 0.52f);
        }
    }
    hud_text_wrapped(ix, ly + 214, 2, "THE HOT BAR HOLDS THREE ITEMS. D-PAD LEFT/RIGHT PICKS ONE IN GAME, SQUARE USES IT.", 24, 999, 0.6f, 0.6f, 0.64f);

    const float mx = 326, mw = 300, mix = mx + 14, miw = mw - 28;
    hud_box(mx, ly, mw, lh);
    hud_section(mix, ly + 16, miw, "CARRIED");
    for (int i = 0; i <= iln; i++) {
        float y = ly + 46 + i * 30;
        int hl = (items_focus && i == items_sel);
        if (hl) {
            hud_rect(mix - 6, y - 6, miw + 12, 28, 0.50f, 0.30f, 0.10f, 0.50f);
            hud_rect(mix - 6, y - 6, miw + 12, 2, 0.85f, 0.65f, 0.30f, 0.9f);
            hud_rect(mix - 6, y + 20, miw + 12, 2, 0.85f, 0.65f, 0.30f, 0.9f);
        }
        float cc = items_focus ? 0.92f : 0.62f;
        if (i == 0) { hud_text(mix, y, 2, "- EMPTY -", cc * 0.8f, cc * 0.8f, cc * 0.8f); continue; }
        char n[40];
        snprintf(n, sizeof(n), "%s  X%d", cons_names[il[i - 1]], cons_count[il[i - 1]]);
        hud_text(mix, y, 2, n, cc, cc, cc * 0.95f);
    }
    if (iln == 0) hud_text_wrapped(mix, ly + 84, 2, "YOU CARRY NOTHING USEFUL YET.", 22, 99, 0.55f, 0.55f, 0.55f);

    const float rx = 638, rw = 308, rix = rx + 14;
    hud_box(rx, ly, rw, lh);
    hud_rect(EQ_PREVIEW_X - 2, EQ_PREVIEW_Y - 2, EQ_PREVIEW_W + 4, EQ_PREVIEW_H + 4, 0.45f, 0.38f, 0.25f, 1.0f);
    hud_rect(EQ_PREVIEW_X, EQ_PREVIEW_Y, EQ_PREVIEW_W, EQ_PREVIEW_H, 0.08f, 0.08f, 0.11f, 1.0f);
    int shown = -1;
    if (items_focus) shown = (items_sel > 0 && items_sel <= iln) ? il[items_sel - 1] : -1;
    else shown = hot[items_slot];
    if (shown >= 0) {
        hud_text(rix, ly + 160, 3, cons_names[shown], 0.95f, 0.95f, 0.9f);
        char n[48];
        if (shown == CONS_HERB)        snprintf(n, sizeof(n), "HEALS %d", (int)HERB_HEAL);
        else if (shown == CONS_POTION) snprintf(n, sizeof(n), "HEALS %d", (int)POTION_HEAL);
        else                           snprintf(n, sizeof(n), "BLAST - %d DAMAGE", (int)BOMB_DAMAGE);
        hud_text(rix, ly + 190, 2, n, 0.92f, 0.80f, 0.40f);
        hud_text_wrapped(rix, ly + 226, 2, cons_desc[shown], 23, 999, 0.72f, 0.72f, 0.76f);
    } else {
        hud_text(rix, ly + 160, 3, "NOTHING", 0.7f, 0.7f, 0.72f);
    }
    if (!items_focus) hud_footer("UP/DOWN: SLOT    X: CHOOSE    LEFT/RIGHT: EQUIPMENT PAGE    O: BACK", "SELECT: CLOSE");
    else              hud_footer("UP/DOWN: SELECT    X: ASSIGN    O: BACK", "AN ITEM ALREADY ON THE BAR SWAPS PLACES");
}

// Bottom-right XP counter with the Dark Souls style "+N" that pours into the total.
static void hud_xp_counter(void) {
    const float w = 210, h = 40, x = 960 - w - 20, y = 464;
    hud_rect(x, y, w, h, 0.03f, 0.03f, 0.05f, 0.80f);
    hud_rect(x, y, w, 2, 0.55f, 0.47f, 0.28f, 1.0f);
    hud_rect(x, y + h - 2, w, 2, 0.55f, 0.47f, 0.28f, 1.0f);
    hud_rect(x, y, 2, h, 0.55f, 0.47f, 0.28f, 1.0f);
    hud_rect(x + w - 2, y, 2, h, 0.55f, 0.47f, 0.28f, 1.0f);
    hud_text(x + 12, y + 13, 2, "XP", 0.80f, 0.75f, 0.50f);
    char b[24];
    snprintf(b, sizeof(b), "%d", (int)(xp_shown + 0.5f));
    hud_text(x + w - 12 - hud_text_width(b, 3), y + 8, 3, b, 0.95f, 0.92f, 0.85f);
    if (xp_pop >= 0.5f) {
        snprintf(b, sizeof(b), "+%d", (int)(xp_pop + 0.5f));
        hud_text(x + w - 12 - hud_text_width(b, 3), y - 30, 3, b, 1.0f, 0.85f, 0.35f);
    }
}

// Bottom-left: the three weapon slots, with the one in hand highlighted.
static void hud_quick_slots(void) {
    for (int i = 0; i < QUICK_SLOTS; i++) {
        float y = 446 + i * 22;
        int act = (i == active_quick), id = quick[i];
        hud_rect(12, y - 3, 196, 20, 0, 0, 0, act ? 0.55f : 0.28f);
        if (act) hud_rect(12, y - 3, 3, 20, 0.92f, 0.80f, 0.40f, 1.0f);
        char dn[2] = { (char)('1' + i), 0 };
        hud_text(22, y, 2, dn, act ? 0.92f : 0.55f, act ? 0.80f : 0.5f, act ? 0.40f : 0.35f);
        hud_text(40, y, 2, id >= 0 ? item_defs[id].name : "-", act ? 0.95f : 0.6f, act ? 0.95f : 0.6f, act ? 0.92f : 0.6f);
    }
}

static void hud_title(const char *toast) {
    hud_rect(0, 0, 960, 544, 0.04f, 0.04f, 0.07f, 1.0f);
    hud_text_centered(50, 9, "CLAUDE FIELD", 0.9f, 0.8f, 0.5f);
    hud_text_centered(150, 2, "SELECT A SAVE FILE", 0.7f, 0.7f, 0.75f);
    for (int i = 0; i < NUM_SLOTS + 1; i++) {
        float y = 200 + i * 60;
        if (i == title_sel) hud_rect(130, y - 8, 700, 48, 0.25f, 0.22f, 0.12f, 0.9f);
        hud_text(150, y, 3, i == title_sel ? ">" : " ", 1.0f, 0.9f, 0.4f);
        char b[96];
        if (i == NUM_SLOTS) {
            snprintf(b, sizeof(b), "QUIT GAME");
        } else if (slot_ok[i]) {
            const SaveData *d = &slot_info[i];
            int mins = (int)(d->play_time / 60.0f);
            snprintf(b, sizeof(b), "SLOT %d  LEVEL %d  PLAYED %d:%02d", i + 1,
                     1 + d->lv_hp + d->lv_stam + d->lv_str + d->lv_ath, mins / 60, mins % 60);
        } else {
            snprintf(b, sizeof(b), "SLOT %d  EMPTY - NEW GAME", i + 1);
        }
        float c = (i < NUM_SLOTS && !slot_ok[i]) ? 0.6f : 0.92f;
        hud_text(190, y, 3, b, c, c, c);
    }
    hud_text(130, 500, 2, "X: SELECT    SQUARE: DELETE SLOT", 0.7f, 0.7f, 0.75f);
    if (toast) hud_text_centered(455, 3, toast, 0.7f, 1.0f, 0.7f);
    if (title_confirm) {
        hud_rect(0, 0, 960, 544, 0, 0, 0, 0.6f);
        hud_rect(210, 190, 540, 150, 0.05f, 0.05f, 0.08f, 1.0f);
        hud_rect(210, 190, 540, 4, 0.7f, 0.6f, 0.3f, 1.0f);
        hud_rect(210, 336, 540, 4, 0.7f, 0.6f, 0.3f, 1.0f);
        char b[48];
        snprintf(b, sizeof(b), "DELETE SLOT %d?", title_sel + 1);
        hud_text_centered(225, 4, b, 0.95f, 0.85f, 0.5f);
        hud_text_centered(290, 3, "X: YES    O: NO", 0.9f, 0.9f, 0.9f);
    }
}

static void build_hud(const char *prompt, const char *toast) {
    hud_n = 0;
    if (screen == SCREEN_TITLE) { hud_title(toast); return; }
    if (menu != MENU_STATS && menu != MENU_INVENTORY && menu != MENU_ITEMS) hud_bars();

    if (menu == MENU_NONE && !player_dead) {
        hud_enemy_bars();
        hud_xp_counter();
        hud_quick_slots();
        hud_hotbar();
        hud_text(12, 520, 2, "TRI JUMP  SQ ITEM  O DODGE  L SPELL  R ATTACK  SEL GEAR  START MENU", 0.9f, 0.9f, 0.9f);
        if (prompt) hud_text_centered(392, 3, prompt, 1.0f, 0.95f, 0.6f);
    }

    if (hurt_flash > 0.0f) hud_rect(0, 0, 960, 544, 0.7f, 0.0f, 0.0f, fminf(hurt_flash * 0.9f, 0.35f));
    if (fade_a > 0.0f) hud_rect(0, 0, 960, 544, 0, 0, 0, fade_a);

    if (menu == MENU_INVENTORY) hud_equipment();
    else if (menu == MENU_ITEMS) hud_items();
    else if (menu == MENU_PAUSE) hud_pause();
    else if (menu == MENU_BESTIARY) hud_bestiary();
    else if (menu == MENU_BEACON) hud_beacon();
    else if (menu == MENU_DIALOGUE) hud_dialogue();
    else if (menu == MENU_STATS) hud_stats();

    if (toast && menu != MENU_DIALOGUE) hud_text_centered(menu == MENU_BEACON ? 450 : (menu == MENU_STATS ? 440 : 425), 3, toast, 0.7f, 1.0f, 0.7f);

    if (player_dead) {
        float a = fminf(death_t * 0.8f, 0.8f);
        hud_rect(0, 0, 960, 544, 0, 0, 0, a);
        hud_text_centered(230, 8, "YOU DIED", 0.8f, 0.1f, 0.1f);
    }
}

// --------------------------------------------------------------- input ----

// Transform a point from weapon-local space to camera space, exactly like the GL calls
// glTranslatef(tx,ty,tz); glRotatef(ry,0,1,0); glRotatef(rz,0,0,1); glRotatef(rx,1,0,0).
static vec3 vm_point(vec3 p, float tx, float ty, float tz, float rz_deg, float rx_deg, float ry_deg) {
    float rz = rz_deg * PI_F / 180.0f, rx = rx_deg * PI_F / 180.0f, ry = ry_deg * PI_F / 180.0f;
    float y1 = p.y * cosf(rx) - p.z * sinf(rx);
    float z1 = p.y * sinf(rx) + p.z * cosf(rx);
    float x2 = p.x * cosf(rz) - y1 * sinf(rz);
    float y2 = p.x * sinf(rz) + y1 * cosf(rz);
    float x3 = x2 * cosf(ry) + z1 * sinf(ry);
    float z3 = -x2 * sinf(ry) + z1 * cosf(ry);
    return V(x3 + tx, y2 + ty, z3 + tz);
}

// Rebuild the forearm each frame in camera space: anchored at the shoulder
// (off-screen, bottom right) and stretching out to the wrist.
static void build_arm(vec3 shoulder, vec3 wrist) {
    rgb skin = C(0.80f, 0.58f, 0.44f), brace = C(0.38f, 0.30f, 0.24f);
    cur = &arm_mesh;
    arm_mesh.n = 0;
    add_prism(shoulder, wrist, 0.065f, 6, skin);
    vec3 b0 = V(wrist.x + (shoulder.x - wrist.x) * 0.25f, wrist.y + (shoulder.y - wrist.y) * 0.25f,
                wrist.z + (shoulder.z - wrist.z) * 0.25f);
    vec3 b1 = V(wrist.x + (shoulder.x - wrist.x) * 0.55f, wrist.y + (shoulder.y - wrist.y) * 0.55f,
                wrist.z + (shoulder.z - wrist.z) * 0.55f);
    add_prism(b0, b1, 0.085f, 6, brace);
}

static float axis(unsigned char raw) {
    float f = ((int)raw - 128) / 128.0f;
    float a = fabsf(f);
    if (a < DEADZONE) return 0.0f;
    a = (a - DEADZONE) / (1.0f - DEADZONE);
    return f < 0 ? -a : a;
}

static float mesh_alpha = 1.0f;   // < 1 fades the mesh out (dying enemies)
static float fade_c[4 * 8192];
static void draw_mesh(const Mesh *m) {
    if (m->n == 0) return;
    glVertexPointer(3, GL_FLOAT, 0, m->use_vs ? m->vs : m->v);
    if (mesh_alpha < 0.999f && m->n <= 8192) {
        for (int i = 0; i < m->n; i++) {
            fade_c[i * 4 + 0] = m->c[i * 4 + 0]; fade_c[i * 4 + 1] = m->c[i * 4 + 1];
            fade_c[i * 4 + 2] = m->c[i * 4 + 2]; fade_c[i * 4 + 3] = m->c[i * 4 + 3] * mesh_alpha;
        }
        glColorPointer(4, GL_FLOAT, 0, fade_c);
    } else {
        glColorPointer(4, GL_FLOAT, 0, m->c);
    }
    if (m->uv) {
        glBindTexture(GL_TEXTURE_2D, *m->tex);
        glEnable(GL_TEXTURE_2D);
        glEnableClientState(GL_TEXTURE_COORD_ARRAY);
        glTexCoordPointer(2, GL_FLOAT, 0, m->uv);
    }
    for (int off = 0; off < m->n; off += 30000) glDrawArrays(GL_TRIANGLES, off, m->n - off > 30000 ? 30000 : m->n - off);   // (vitaGL indexes with 16 bits)
    if (m->uv) {
        glDisableClientState(GL_TEXTURE_COORD_ARRAY);
        glDisable(GL_TEXTURE_2D);
    }
}

// ---- procedural textures (64x64, point-sampled: chunky PS1 texels) ----
static unsigned char tex_buf[64 * 64 * 4];
static unsigned tex_state = 0xC0FFEE11u;
static unsigned tex_rnd(void) { tex_state ^= tex_state << 13; tex_state ^= tex_state >> 17; tex_state ^= tex_state << 5; return tex_state; }
static void tex_put(int x, int y, int v, int a) {
    if (v < 0) v = 0;
    if (v > 255) v = 255;
    unsigned char *q = &tex_buf[((y & 63) * 64 + (x & 63)) * 4];
    q[0] = q[1] = q[2] = (unsigned char)v; q[3] = (unsigned char)a;
}
static unsigned tex_make(void) {
    unsigned id = 0;
    glGenTextures(1, &id);
    glBindTexture(GL_TEXTURE_2D, id);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 64, 64, 0, GL_RGBA, GL_UNSIGNED_BYTE, tex_buf);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    return id;
}

static void build_textures(void) {
    // Grass: a quiet mottled base with short dark blades and the odd bright tip. (Props share it, so keep it subtle.)
    for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++) {
        int v = 236 + (int)(tex_rnd() % 12) - 6;
        tex_put(x, y, v, 255);
    }
    for (int k = 0; k < 150; k++) {
        int x = (int)(tex_rnd() % 64), y = (int)(tex_rnd() % 64), len = 2 + (int)(tex_rnd() % 3);
        int dark = 186 + (int)(tex_rnd() % 18);
        for (int j = 0; j < len; j++) {
            tex_put(x, (y + j) & 63, dark + j * 6, 255);
            if (j == 0 && (tex_rnd() & 3) == 0) tex_put((x + 1) & 63, y, dark + 10, 255);
        }
    }
    for (int k = 0; k < 34; k++) tex_put((int)(tex_rnd() % 64), (int)(tex_rnd() % 64), 255, 255);
    tex_grain = tex_make();

    // Bricks: 32x16 texel bricks laid in staggered rows, with mortar lines.
    for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++) {
        int row = y >> 4, off = (row & 1) ? 16 : 0, bx = (x + off) & 31, by = y & 15, brick = (x + off) >> 5;
        unsigned h = (unsigned)(row * 73856093) ^ (unsigned)(brick * 19349663);
        int v;
        if (by < 2 || bx < 2) v = 112 + (int)(tex_rnd() % 10);
        else v = 196 + (int)((h >> 4) % 44) - (int)(tex_rnd() % 16);
        tex_put(x, y, v, 255);
    }
    tex_brick = tex_make();

    // Rock: blotchy two-scale noise with a few dark cracks.
    {
        float g1[9][9], g2[17][17];
        for (int j = 0; j < 9; j++) for (int i = 0; i < 9; i++) g1[j][i] = (float)(tex_rnd() % 256);
        for (int j = 0; j < 9; j++) { g1[j][8] = g1[j][0]; }
        for (int i = 0; i < 9; i++) { g1[8][i] = g1[0][i]; }
        for (int j = 0; j < 17; j++) for (int i = 0; i < 17; i++) g2[j][i] = (float)(tex_rnd() % 256);
        for (int j = 0; j < 17; j++) { g2[j][16] = g2[j][0]; }
        for (int i = 0; i < 17; i++) { g2[16][i] = g2[0][i]; }
        for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++) {
            float fx = x / 8.0f, fy = y / 8.0f; int ix = (int)fx, iy = (int)fy; float ux = fx - ix, uy = fy - iy;
            float a = g1[iy][ix] * (1 - ux) + g1[iy][ix + 1] * ux, b = g1[iy + 1][ix] * (1 - ux) + g1[iy + 1][ix + 1] * ux;
            float n1 = a * (1 - uy) + b * uy;
            fx = x / 4.0f; fy = y / 4.0f; ix = (int)fx; iy = (int)fy; ux = fx - ix; uy = fy - iy;
            a = g2[iy][ix] * (1 - ux) + g2[iy][ix + 1] * ux; b = g2[iy + 1][ix] * (1 - ux) + g2[iy + 1][ix + 1] * ux;
            float n2 = a * (1 - uy) + b * uy;
            int v = 140 + (int)(n1 * 0.30f + n2 * 0.16f) + (int)(tex_rnd() % 14) - 7;
            tex_put(x, y, v, 255);
        }
        for (int c = 0; c < 5; c++) {   // cracks
            int x = (int)(tex_rnd() % 64), y = (int)(tex_rnd() % 64);
            for (int k = 0; k < 18; k++) {
                tex_put(x, y, 70 + (int)(tex_rnd() % 20), 255);
                x += (int)(tex_rnd() % 3) - 1 + 1; y += (int)(tex_rnd() % 3) - 1;
            }
        }
    }
    tex_rock = tex_make();
}

// Texture coordinates from the triangle's own plane (floors use x,z; walls use the horizontal axis and y).
static void bake_uv(Mesh *m, float scale) {
    for (int i = 0; i + 2 < m->n; i += 3) {
        const float *a = &m->v[i * 3], *b = &m->v[(i + 1) * 3], *c = &m->v[(i + 2) * 3];
        float e1x = b[0] - a[0], e1y = b[1] - a[1], e1z = b[2] - a[2];
        float e2x = c[0] - a[0], e2y = c[1] - a[1], e2z = c[2] - a[2];
        float nx = fabsf(e1y * e2z - e1z * e2y), ny = fabsf(e1z * e2x - e1x * e2z), nz = fabsf(e1x * e2y - e1y * e2x);
        int mode = (ny >= nx && ny >= nz) ? 1 : (nx >= nz ? 2 : 3);
        for (int k = 0; k < 3; k++) {
            const float *q = &m->v[(i + k) * 3];
            float u, v;
            if (mode == 1)      { u = q[0]; v = q[2]; }
            else if (mode == 2) { u = q[2]; v = q[1]; }
            else                { u = q[0]; v = q[1]; }
            m->uv0[(i + k) * 2] = m->uv[(i + k) * 2] = u * scale;
            m->uv0[(i + k) * 2 + 1] = m->uv[(i + k) * 2 + 1] = v * scale;
        }
    }
}

// The PS1 "wobble": the console's GTE rounded every projected vertex to a whole pixel of a 320x240 screen, so geometry
// crawls and edges swim as you move. We do the same on the CPU: project each nearby vertex, round it to a coarse grid and
// push it back out. (Distant vertices stay exact: the wobble is far too small to see there anyway.)
static void snap_mesh(Mesh *m, float cx, float cy, float cz, float yaw, float pitch, float range) {
    if (!m->vs) m->vs = (float *)malloc((size_t)m->max * 3 * sizeof(float));
    if (!m->vs) { m->use_vs = 0; return; }
    const float sy = sinf(yaw), cyw = cosf(yaw), sp = sinf(pitch), cp = cosf(pitch);
    const float Fx = -sy * cp, Fy = sp, Fz = -cyw * cp;
    const float Rx = cyw, Rz = -sy;
    const float Ux = sy * sp, Uy = cp, Uz = cyw * sp;
    const float T = 0.70020753f, TA = T * (960.0f / 544.0f);
    const float GX = 160.0f, GY = 90.0f, r2 = range * range;
    for (int i = 0; i < m->n; i++) {
        const float *p = &m->v[i * 3];
        float *o = &m->vs[i * 3];
        float dx = p[0] - cx, dy = p[1] - cy, dz = p[2] - cz;
        float z = dx * Fx + dy * Fy + dz * Fz;
        if (z < 0.3f || p[1] < 0.2f || dx * dx + dz * dz > r2) { o[0] = p[0]; o[1] = p[1]; o[2] = p[2]; continue; }
        float x = dx * Rx + dz * Rz, y = dx * Ux + dy * Uy + dz * Uz;
        float k = 1.0f / (z * TA), l = 1.0f / (z * T);
        float nx = floorf(x * k * GX + 0.5f) / GX, ny = floorf(y * l * GY + 0.5f) / GY;
        x = nx * z * TA; y = ny * z * T;
        o[0] = cx + x * Rx + y * Ux + z * Fx;
        o[1] = cy + y * Uy + z * Fy;
        o[2] = cz + x * Rz + y * Uz + z * Fz;
    }
    m->use_vs = 1;
}

// ---------------------------------------------------------------- main ----

static void set_perspective(void) {
    const float near_ = 0.1f, far_ = 100.0f;
    float top = near_ * tanf(35.0f * PI_F / 180.0f);   // 70 degree vertical FOV
    float right = top * (960.0f / 544.0f);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glFrustum(-right, right, -top, top, near_, far_);
    glMatrixMode(GL_MODELVIEW);
}

// Spinning 3D model inside a rectangle of the HUD (bestiary + equipment screens). Drawn after the
// HUD batch, using the normal projection with the model shifted to the rectangle's centre.
static void draw_preview(const Mesh *m, float rx, float ry, float rw, float rh,
                         float scale, float cy, float cz, float tilt, float spin, int flat,
                         const Mesh *limb, float limb_x, float limb_y, float limb_rest) {
    const float dist = 2.2f;
    float ndc_x = (rx + rw / 2.0f) / 480.0f - 1.0f;
    float ndc_y = 1.0f - (ry + rh / 2.0f) / 272.0f;
    glClear(GL_DEPTH_BUFFER_BIT);
    glEnable(GL_DEPTH_TEST);
    set_perspective();
    glLoadIdentity();
    glTranslatef(ndc_x * dist * 0.70020753f * (960.0f / 544.0f), ndc_y * dist * 0.70020753f, -dist);
    glRotatef(tilt, 1, 0, 0);
    glRotatef(spin, 0, 1, 0);
    glScalef(scale * 0.78f, scale * 0.78f, scale * 0.78f);
    // spin about the middle of the model's footprint, not its origin
    float bx0 = 1e9f, bx1 = -1e9f, bz0 = 1e9f, bz1 = -1e9f;
    for (int i = 0; i < m->n; i++) {
        float vx = m->v[i * 3], vz = m->v[i * 3 + 2];
        if (vx < bx0) bx0 = vx;
        if (vx > bx1) bx1 = vx;
        if (vz < bz0) bz0 = vz;
        if (vz > bz1) bz1 = vz;
    }
    float mcx = m->n ? (bx0 + bx1) * 0.5f : 0.0f, mcz = m->n ? (bz0 + bz1) * 0.5f : 0.0f;
    (void)cz;
    if (flat) {   // weapons lie on their side so the long axis fits the frame
        glRotatef(-90.0f, 0, 0, 1);
        glTranslatef(-mcx, -cy, -mcz);
    } else {
        glTranslatef(-mcx, -cy, -mcz);
    }
    glEnableClientState(GL_VERTEX_ARRAY);
    glEnableClientState(GL_COLOR_ARRAY);
    draw_mesh(m);
    if (limb) {
        glTranslatef(limb_x, limb_y, 0.0f);
        glRotatef(limb_rest, 1, 0, 0);
        draw_mesh(limb);
    }
    glDisableClientState(GL_COLOR_ARRAY);
    glDisableClientState(GL_VERTEX_ARRAY);
    glDisable(GL_DEPTH_TEST);
}

// Enemy animation per state. Rat: hop, crouch + shake, stretched lunge. Crab: scuttle, rear up, slam.
static void draw_enemy(const Enemy *e, float t) {
    const EnemyDef *d = &enemy_defs[e->type];
    float hop_y = 0.0f, pitch = 0.0f, roll = 0.0f, shake = 0.0f, back = 0.0f, lift = 0.0f;
    float sx = 1.0f, sy = 1.0f, sz = 1.0f, u;
    float wig = 0.0f, arm = 0.0f;   // wig: body sway about the vertical (worm); arm: sword-arm angle (undead)
    const float k = enemy_scale_k(e);

    if (e->type == ENEMY_CRAB) {
        float cyc = sinf(e->hop * 2.0f * PI_F);
        switch (e->state) {
        case E_IDLE:
        case E_CHASE:
            if (e->walking) {
                roll = cyc * (e->state == E_CHASE ? 4.5f : 3.0f);
                hop_y = fabsf(cyc) * 0.05f;
                shake = sinf(e->hop * 4.0f * PI_F) * 0.02f;
            } else {
                sy = 1.0f + sinf(t * 1.5f) * 0.015f;
            }
            break;
        case E_WINDUP:   // rears up with claws raised, trembling
            u = fminf(e->state_t / d->windup, 1.0f);
            pitch = -30.0f * u;
            hop_y = 0.20f * u;
            shake = sinf(t * 60.0f) * 0.03f * u;
            sz = 1.0f - 0.06f * u;
            break;
        case E_LUNGE:    // slams forward
            sz = 1.15f; sy = 0.9f; pitch = 22.0f;
            break;
        case E_RECOVER:
            sy = 0.93f; pitch = 10.0f;
            break;
        case E_STAGGER:
            roll = sinf(e->state_t * 40.0f) * 8.0f;
            back = -0.08f;
            break;
        case E_DEAD:     // flips onto its back
            u = smooth01(e->state_t / 0.4f);
            roll = u * 180.0f;
            lift = 0.62f * d->scale * u;
            break;
        }
    } else if (e->type == ENEMY_WORM) {
        back = -0.95f * d->scale * k;   // the mesh origin is the tail: shift so the body is centred on the enemy
        switch (e->state) {
        case E_IDLE:
        case E_CHASE:
            wig = sinf(e->hop * 2.0f * PI_F) * (e->walking ? 16.0f : 5.0f);
            if (!e->walking) wig = sinf(t * 1.7f + e->spawn_x) * 6.0f;
            break;
        case E_WINDUP:   // rears up, maw open, quivering: the bite comes when it drops
            u = smooth01(fminf(e->state_t / d->windup, 1.0f));
            pitch = -72.0f * u;
            shake = sinf(t * 55.0f) * 0.03f * u;
            sz = 1.0f - 0.10f * u;
            break;
        case E_LUNGE:
            sz = 1.3f; sy = 0.9f; pitch = 8.0f;
            break;
        case E_RECOVER:
            pitch = 3.0f; sy = 0.92f;
            break;
        case E_STAGGER:
            roll = sinf(e->state_t * 40.0f) * 12.0f;
            wig = sinf(e->state_t * 30.0f) * 14.0f;
            break;
        case E_DEAD:
            u = smooth01(e->state_t / 0.35f);
            sy = 1.0f - 0.55f * u; roll = 25.0f * u;
            break;
        }
    } else if (e->type == ENEMY_UNDEAD || e->type == ENEMY_WARDEN) {
        float cyc = sinf(e->hop * 2.0f * PI_F);
        switch (e->state) {
        case E_IDLE:
        case E_CHASE:
            if (e->walking) {
                hop_y = fabsf(cyc) * 0.05f;
                roll = cyc * 3.5f;
                arm = -50.0f + cyc * 8.0f;
            } else {
                arm = -50.0f + sinf(t * 1.3f) * 3.0f;
                sy = 1.0f + sinf(t * 1.5f) * 0.01f;
            }
            break;
        case E_WINDUP:   // sword hauled up overhead: the chop comes when it falls
            u = smooth01(fminf(e->state_t / d->windup, 1.0f));
            arm = -50.0f - 120.0f * u;
            pitch = -9.0f * u;
            shake = sinf(t * 50.0f) * 0.02f * u;
            break;
        case E_LUNGE:    // the chop, with a lunging step
            u = fminf(e->state_t / d->lunge_time, 1.0f);
            arm = -170.0f + 130.0f * u;
            pitch = 16.0f * u;
            break;
        case E_RECOVER:
            u = fminf(e->state_t / d->recover, 1.0f);
            arm = -40.0f - 10.0f * u;
            pitch = 10.0f * (1.0f - u);
            break;
        case E_STAGGER:
            roll = sinf(e->state_t * 40.0f) * 9.0f;
            arm = -45.0f;
            back = -0.08f;
            break;
        case E_DEAD:     // collapses backwards
            u = smooth01(e->state_t / 0.5f);
            pitch = -88.0f * u;
            lift = 0.18f * u;
            arm = -30.0f * u;
            break;
        }
    } else if (e->type == ENEMY_ZOMBIE || e->type == ENEMY_BRUTE) {
        float cyc = sinf(e->hop * 2.0f * PI_F);
        switch (e->state) {
        case E_IDLE:
        case E_CHASE:
            if (e->walking) {
                hop_y = fabsf(cyc) * 0.04f;
                roll = cyc * 5.0f;
                arm = -82.0f + cyc * 7.0f;   // arms reaching out in front
                pitch = 7.0f;
            } else {
                arm = -80.0f + sinf(t * 1.1f + e->spawn_x) * 6.0f;
                pitch = 6.0f + sinf(t * 0.9f) * 2.0f;
            }
            break;
        case E_WINDUP:   // both arms haul up over its head: the slam comes down after
            u = smooth01(fminf(e->state_t / d->windup, 1.0f));
            arm = -80.0f - 98.0f * u;
            pitch = 6.0f - 16.0f * u;
            shake = sinf(t * 45.0f) * 0.025f * u;
            break;
        case E_LUNGE:    // the slam
            u = fminf(e->state_t / d->lunge_time, 1.0f);
            arm = -178.0f + 138.0f * u;
            pitch = 24.0f * u;
            break;
        case E_RECOVER:
            u = fminf(e->state_t / d->recover, 1.0f);
            arm = -40.0f - 30.0f * u;
            pitch = 22.0f * (1.0f - u) + 6.0f * u;
            break;
        case E_STAGGER:
            roll = sinf(e->state_t * 40.0f) * 8.0f;
            arm = -100.0f;
            back = -0.08f;
            break;
        case E_DEAD:     // topples forward
            u = smooth01(e->state_t / 0.55f);
            pitch = 88.0f * u;
            lift = 0.28f * u;
            arm = -80.0f + 60.0f * u;
            break;
        }
    } else {
        switch (e->state) {
        case E_IDLE:
            sy = 1.0f + sinf(t * 2.5f) * 0.03f;
            break;
        case E_CHASE: {
            float f = e->hop - floorf(e->hop);
            if (f < 0.65f) {
                float a = sinf(PI_F * f / 0.65f);
                hop_y = a * 0.30f;
                pitch = -a * 22.0f;
            } else {
                sy = 0.85f; sz = 1.08f; pitch = 6.0f;   // landing squash
            }
            break;
        }
        case E_WINDUP:
            u = fminf(e->state_t / d->windup, 1.0f);
            sy = 1.0f - 0.30f * u;
            sz = 1.0f - 0.10f * u;
            back = -0.20f * u;
            pitch = 10.0f * u;
            shake = sinf(t * 70.0f) * 0.035f * u;
            break;
        case E_LUNGE:
            u = fminf(e->state_t / d->lunge_time, 1.0f);
            sz = 1.40f; sy = 0.85f; pitch = -12.0f;
            hop_y = sinf(PI_F * u) * 0.22f;
            break;
        case E_RECOVER:
            sy = 0.88f; pitch = 14.0f;
            break;
        case E_STAGGER:
            roll = sinf(e->state_t * 45.0f) * 12.0f;
            back = -0.1f; pitch = -10.0f;
            break;
        case E_DEAD:
            u = smooth01(e->state_t / 0.25f);
            roll = u * 90.0f;
            lift = 0.17f * d->scale * u;   // lies on its side
            break;
        }
    }

    glPushMatrix();
    glTranslatef(e->x, hop_y + lift, e->z);
    glRotatef(e->yaw * 180.0f / PI_F, 0, 1, 0);
    glRotatef(wig, 0, 1, 0);
    glTranslatef(shake, 0.0f, back);
    glRotatef(pitch, 1, 0, 0);
    glRotatef(roll, 0, 0, 1);
    glScalef(d->scale * k * sx, d->scale * k * sy, d->scale * k * sz);
    draw_mesh(d->mesh);
    if (d->limb) {   // the sword arm / both arms hang from the shoulder
        glTranslatef(d->limb_x, d->limb_y, 0.0f);
        glRotatef(arm, 1, 0, 0);
        draw_mesh(d->limb);
    }
    glPopMatrix();
}

int main(void) {
    sceCtrlSetSamplingMode(SCE_CTRL_MODE_ANALOG);

    vglInit(0x800000);
    glViewport(0, 0, 960, 544);

    build_scene();
    build_hand();
    build_sword();
    build_mace();
    build_axe();
    build_spear();
    build_dummy();
    build_rat();
    build_crab();
    build_door();
    build_gem();
    build_npc();
    build_smith();
    build_gloam();
    build_chest();
    build_worm();
    build_undead();
    build_lhand();
    build_fire();
    build_herb();
    build_potion();
    build_bomb();
    build_torch();
    build_sparks();
    build_pick();
    build_zombie();
    build_dying();
    clone_tint(&bonespear_mesh, &spear_mesh, 1.00f, 0.92f, 0.78f);
    clone_tint(&basaltmace_mesh, &mace_mesh, 0.50f, 0.50f, 0.58f);
    clone_tint(&brute_mesh, &zombie_mesh, 1.10f, 0.72f, 0.62f);
    clone_tint(&brutearms_mesh, &zombiearms_mesh, 1.10f, 0.72f, 0.62f);
    clone_tint(&warden_mesh, &undead_mesh, 0.70f, 0.82f, 1.25f);
    clone_tint(&wardenarms_mesh, &undeadarm_mesh, 0.70f, 0.82f, 1.25f);
    build_textures();
    spawn_maze_enemies();
    place_maze_pickups();
    nw_over = nwalls; nc_over = ncolliders;
    build_cave();
    base_enemies = num_enemies;
    set_zone(0);
    bake_uv(&world_mesh, 0.35f);
    bake_uv(&brick_mesh, 0.45f);
    bake_uv(&cave_mesh, 0.30f);
    reset_enemies();
    refresh_slots();   // read any existing save files so the main menu shows them

    const float sky[4] = {0.45f, 0.55f, 0.75f, 1.0f};
    glClearColor(sky[0], sky[1], sky[2], sky[3]);
    glFogi(GL_FOG_MODE, GL_LINEAR);
    glFogf(GL_FOG_START, 14.0f);
    glFogf(GL_FOG_END, 52.0f);
    glFogfv(GL_FOG_COLOR, sky);

    float px = 0.0f, pz = 6.0f;   // player position
    float py = 0.0f, vy = 0.0f;   // feet height above the ground, and vertical speed
    float yaw = 0.0f, pitch = 0.0f;
    float t = 0.0f, bob = 0.0f;
    float cam_roll = 0.0f, cam_drop = 0.0f;
    char toast_buf[64];
    float toast_t = 0.0f;
    unsigned int prev_buttons = 0;
    int quit = 0;
    uint64_t last = sceKernelGetProcessTimeWide();

    while (!quit) {
        uint64_t now = sceKernelGetProcessTimeWide();
        float dt = (now - last) / 1000000.0f;
        last = now;
        if (dt > 0.1f) dt = 0.1f;
        t += dt;
        g_time = t;
        if (screen == SCREEN_GAME) play_time += dt;
        update_xp_display(dt);
        if (toast_t > 0.0f) toast_t -= dt;
        if (hurt_flash > 0.0f) hurt_flash -= dt;
        {
            static int la = -1, lc = -2;
            int cc = hot[active_hot];
            if (active_hot != la || cc != lc) { la = active_hot; lc = cc; hot_name_t = 2.0f; }
            else if (hot_name_t > 0.0f) hot_name_t -= dt;
        }

        SceCtrlData pad;
        memset(&pad, 0, sizeof(pad));
        sceCtrlPeekBufferPositive(0, &pad, 1);
        unsigned int pressed = pad.buttons & ~prev_buttons;
        prev_buttons = pad.buttons;

        float moving = 0.0f;
        char prompt_buf[64];
        const char *prompt = NULL;

        if (screen == SCREEN_TITLE) {
            // ---- main menu: three save slots ----
            if (title_confirm) {
                if (pressed & SCE_CTRL_CROSS) {
                    delete_save(title_sel);
                    title_confirm = 0;
                    snprintf(toast_buf, sizeof(toast_buf), "SLOT %d DELETED", title_sel + 1);
                    toast_t = 2.0f;
                }
                if (pressed & SCE_CTRL_CIRCLE) title_confirm = 0;
            } else {
                if ((pressed & SCE_CTRL_UP) && title_sel > 0) title_sel--;
                if ((pressed & SCE_CTRL_DOWN) && title_sel < NUM_SLOTS) title_sel++;
                if ((pressed & SCE_CTRL_SQUARE) && title_sel < NUM_SLOTS && slot_ok[title_sel]) title_confirm = 1;
                if (pressed & SCE_CTRL_CROSS) {
                    if (title_sel == NUM_SLOTS) {
                        quit = 1;
                    } else {
                        cur_slot = title_sel;
                        yaw = 0.0f; pitch = 0.0f;
                        if (slot_ok[cur_slot]) {          // continue: wake up at the beacon
                            apply_save(&slot_info[cur_slot]);
                            px = BEACON_X; pz = BEACON_Z + 3.0f; py = 0.0f; vy = 0.0f;
                            snprintf(toast_buf, sizeof(toast_buf), "GAME LOADED");
                        } else {                          // new game
                            new_game_state();
                            px = 0.0f; pz = 6.0f; py = 0.0f; vy = 0.0f;
                            snprintf(toast_buf, sizeof(toast_buf), "NEW GAME - SLOT %d", cur_slot + 1);
                        }
                        toast_t = 2.5f;
                        screen = SCREEN_GAME;
                    }
                }
            }
        } else if (player_dead) {
            // ---- death screen, then wake up at the start ----
            death_t += dt;
            if (death_t >= RESPAWN_DELAY) {
                player_dead = 0;
                menu = MENU_NONE;
                px = 0.0f; pz = 6.0f; py = 0.0f; vy = 0.0f; yaw = 0.0f; pitch = 0.0f;
                set_zone(0); fade_state = 0; fade_t = fade_a = 0.0f;
                do_rest();
                snprintf(toast_buf, sizeof(toast_buf), "YOU AWAKEN AT THE START");
                toast_t = 2.5f;
            }
        } else {
            // ---- menu open / close: START opens the action list, SELECT the equipment ----
            const int menu_start = menu;   // a menu closed this frame must not also act in the world (X would reopen it)
            const int live = (menu == MENU_NONE || menu == MENU_INVENTORY || menu == MENU_ITEMS || menu == MENU_PAUSE || menu == MENU_BESTIARY);
            if (live && fade_state == 0) {
                if (pressed & SCE_CTRL_START) {
                    if (menu == MENU_NONE) { menu = MENU_PAUSE; pause_sel = 0; }
                    else menu = MENU_NONE;
                } else if (pressed & SCE_CTRL_SELECT) {
                    if (menu == MENU_NONE) { menu = MENU_INVENTORY; eq_focus = 0; eq_slot = active_quick; inv_sel = 0; }
                    else if (menu == MENU_INVENTORY || menu == MENU_ITEMS) menu = MENU_NONE;
                }
            }

            if (menu == MENU_INVENTORY) {
                // Equipment screen: pick a slot (weapons, armor, left hand), then pick what goes in it.
                int eq_list[INV_MAX];
                int eq_n = eq_build_list(eq_slot, eq_list);
                if (!eq_focus) {
                    if ((pressed & SCE_CTRL_UP) && eq_slot > 0) eq_slot--;
                    if ((pressed & SCE_CTRL_DOWN) && eq_slot < EQ_SLOTS - 1) eq_slot++;
                    if (pressed & (SCE_CTRL_LEFT | SCE_CTRL_RIGHT)) { menu = MENU_ITEMS; items_focus = 0; items_slot = active_hot; items_sel = 0; }
                    if (pressed & SCE_CTRL_CROSS) {
                        eq_focus = 1;
                        eq_n = eq_build_list(eq_slot, eq_list);
                        inv_sel = 0;   // start the cursor on whatever is in the slot now
                        for (int i = 0; i < eq_n; i++) if (eq_list[i] == eq_current(eq_slot)) inv_sel = i + 1;
                    }
                    if (pressed & SCE_CTRL_CIRCLE) menu = MENU_NONE;
                } else {
                    if ((pressed & SCE_CTRL_UP) && inv_sel > 0) inv_sel--;
                    if ((pressed & SCE_CTRL_DOWN) && inv_sel < eq_n) inv_sel++;   // entry 0 is "EMPTY"
                    if (pressed & SCE_CTRL_CROSS) { eq_equip(eq_slot, inv_sel == 0 ? -1 : eq_list[inv_sel - 1]); eq_focus = 0; }
                    if (pressed & SCE_CTRL_CIRCLE) eq_focus = 0;
                }
            } else if (menu == MENU_ITEMS) {
                int il[CONS_COUNT], iln = 0;
                for (int c = 0; c < CONS_COUNT; c++) if (cons_count[c] > 0) il[iln++] = c;
                if (!items_focus) {
                    if ((pressed & SCE_CTRL_UP) && items_slot > 0) items_slot--;
                    if ((pressed & SCE_CTRL_DOWN) && items_slot < HOT_SLOTS - 1) items_slot++;
                    if (pressed & (SCE_CTRL_LEFT | SCE_CTRL_RIGHT)) { menu = MENU_INVENTORY; eq_focus = 0; }
                    if (pressed & SCE_CTRL_CROSS) {
                        items_focus = 1; items_sel = 0;
                        for (int i = 0; i < iln; i++) if (il[i] == hot[items_slot]) items_sel = i + 1;
                    }
                    if (pressed & SCE_CTRL_CIRCLE) menu = MENU_NONE;
                } else {
                    if ((pressed & SCE_CTRL_UP) && items_sel > 0) items_sel--;
                    if ((pressed & SCE_CTRL_DOWN) && items_sel < iln) items_sel++;
                    if (pressed & SCE_CTRL_CROSS) {
                        int c = items_sel == 0 ? -1 : il[items_sel - 1];
                        if (c >= 0) for (int j = 0; j < HOT_SLOTS; j++) if (j != items_slot && hot[j] == c) hot[j] = hot[items_slot];
                        hot[items_slot] = c;
                        items_focus = 0;
                    }
                    if (pressed & SCE_CTRL_CIRCLE) items_focus = 0;
                }
            } else if (menu == MENU_PAUSE) {
                if ((pressed & SCE_CTRL_UP) && pause_sel > 0) pause_sel--;
                if ((pressed & SCE_CTRL_DOWN) && pause_sel < 2) pause_sel++;
                if (pressed & SCE_CTRL_CROSS) {
                    if (pause_sel == 0) {
                        menu = MENU_BESTIARY;
                    } else if (pause_sel == 1) {   // back to the main menu (unsaved progress is lost)
                        menu = MENU_NONE;
                        screen = SCREEN_TITLE;
                        title_sel = cur_slot;
                        title_confirm = 0;
                        set_zone(0); fade_state = 0; fade_t = fade_a = 0.0f;
                        refresh_slots();
                    } else {
                        quit = 1;
                    }
                }
                if (pressed & SCE_CTRL_CIRCLE) menu = MENU_NONE;
            } else if (menu == MENU_BESTIARY) {
                if ((pressed & SCE_CTRL_UP) && bestiary_sel > 0) bestiary_sel--;
                if ((pressed & SCE_CTRL_DOWN) && bestiary_sel < ENEMY_TYPE_COUNT - 1) bestiary_sel++;
                if (pressed & SCE_CTRL_CIRCLE) menu = MENU_PAUSE;
            } else if (menu == MENU_STATS) {
                // Level-up screen: choose where points go (LEFT/RIGHT), then CONFIRM to spend them.
                int total = pend_total();
                if ((pressed & SCE_CTRL_UP) && stats_sel > 0) stats_sel--;
                if ((pressed & SCE_CTRL_DOWN) && stats_sel < 4) stats_sel++;
                if ((pressed & SCE_CTRL_LEFT) && stats_sel < 4 && pend[stats_sel] > 0) pend[stats_sel]--;
                if (((pressed & SCE_CTRL_RIGHT) || ((pressed & SCE_CTRL_CROSS) && stats_sel < 4)) &&
                    stats_sel < 4 && attr_level(stats_sel) + pend[stats_sel] < ATTR_CAP - 1 &&
                    xp >= levels_cost(player_level(), total + 1)) pend[stats_sel]++;
                if ((pressed & SCE_CTRL_CROSS) && stats_sel == 4) {
                    if (commit_levels(pend[0], pend[1], pend[2], pend[3])) {
                        pend[0] = pend[1] = pend[2] = pend[3] = 0;
                        snprintf(toast_buf, sizeof(toast_buf), "LEVEL UP! NOW LEVEL %d", player_level());
                    } else {
                        snprintf(toast_buf, sizeof(toast_buf), xp >= level_cost(player_level()) ? "CHOOSE ATTRIBUTES FIRST" : "NOT ENOUGH XP");
                    }
                    toast_t = 1.5f;
                }
                if (pressed & SCE_CTRL_CIRCLE) { pend[0] = pend[1] = pend[2] = pend[3] = 0; menu = menu_return; }
            } else if (menu == MENU_DIALOGUE) {
                dlg_chars += DIALOGUE_CPS * dt;
                if (pressed & SCE_CTRL_CROSS) {
                    if (npc_advance()) {
                        menu = MENU_NONE;
                        if (key_just_given) {
                            key_just_given = 0;
                            snprintf(toast_buf, sizeof(toast_buf), "OBTAINED THE LABYRINTH KEY");
                            toast_t = 3.0f;
                        }
                        if (torch_just_given) {
                            torch_just_given = 0;
                            snprintf(toast_buf, sizeof(toast_buf), "OBTAINED A TORCH. IT IS IN YOUR LEFT HAND.");
                            toast_t = 3.0f;
                        }
                    }
                }
                if (pressed & SCE_CTRL_CIRCLE) menu = MENU_NONE;   // walk away; he picks up where he left off
            } else if (menu == MENU_BEACON) {
                if ((pressed & SCE_CTRL_UP) && beacon_sel > 0) beacon_sel--;
                if ((pressed & SCE_CTRL_DOWN) && beacon_sel < 3) beacon_sel++;
                if (pressed & SCE_CTRL_CROSS) {
                    if (beacon_sel == 0) {          // SAVE
                        snprintf(toast_buf, sizeof(toast_buf), write_save(cur_slot) ? "GAME SAVED" : "SAVE FAILED");
                        toast_t = 2.0f;
                    } else if (beacon_sel == 1) {   // REST
                        do_rest();
                        menu = MENU_NONE;
                        snprintf(toast_buf, sizeof(toast_buf), "RESTED. ENEMIES HAVE RETURNED.");
                        toast_t = 2.5f;
                    } else if (beacon_sel == 2) {   // LEVEL UP
                        menu = MENU_STATS;
                        menu_return = MENU_BEACON;
                        stats_sel = 0;
                        pend[0] = pend[1] = pend[2] = pend[3] = 0;
                    } else {                        // TELEPORT (placeholder for later)
                        snprintf(toast_buf, sizeof(toast_buf), "TELEPORT COMES LATER");
                        toast_t = 2.0f;
                    }
                }
                if (pressed & SCE_CTRL_CIRCLE) menu = MENU_NONE;
            }
            if (menu == MENU_NONE || menu == MENU_INVENTORY || menu == MENU_ITEMS || menu == MENU_PAUSE || menu == MENU_BESTIARY) {
                // ---- the world: it keeps running behind the equipment / action menus, but you cannot act ----
                const float ctl = (menu == MENU_NONE && menu_start == MENU_NONE && fade_state == 0) ? 1.0f : 0.0f;
                const unsigned wpressed = ctl > 0.0f ? pressed : 0u;

                // Zone change (door): fade out, move, fade in.
                if (fade_state == 1) {
                    fade_t += dt / 0.35f;
                    if (fade_t >= 1.0f) {
                        fade_t = 1.0f;
                        const Portal *pp = &portals[portal_k];
                        set_zone(pp->dest_zone);
                        px = pp->dest_x; pz = pp->dest_z; yaw = pp->dest_yaw; pitch = 0.0f; py = 0.0f; vy = 0.0f;
                        for (int i = 0; i < MAX_PROJ; i++) projs[i].on = 0;
                        for (int i = 0; i < MAX_BOMB; i++) bombs[i].on = 0;
                        for (int i = 0; i < MAX_PART; i++) parts[i].on = 0;
                        for (int i = 0; i < MAX_BOOM; i++) booms[i].on = 0;
                        fade_state = 2;
                        if (zone == 1 && left_hand != LH_TORCH) {
                            snprintf(toast_buf, sizeof(toast_buf), "IT IS PITCH BLACK. SOMEONE GROANS NEARBY.");
                            toast_t = 3.5f;
                        }
                    }
                } else if (fade_state == 2) {
                    fade_t -= dt / 0.35f;
                    if (fade_t <= 0.0f) { fade_t = 0.0f; fade_state = 0; }
                }
                fade_a = fade_t;

                float lx = axis(pad.lx) * ctl, ly = axis(pad.ly) * ctl;
                float rx = axis(pad.rx) * ctl, ry = axis(pad.ry) * ctl;

                // Look: stick right turns right, stick up looks up.
                yaw   -= rx * LOOK_SPEED * dt;
                pitch -= ry * LOOK_SPEED * dt;
                if (pitch >  1.4f) pitch =  1.4f;
                if (pitch < -1.4f) pitch = -1.4f;

                float fx = -sinf(yaw), fz = -cosf(yaw);   // forward
                float sx =  cosf(yaw), sz = -sinf(yaw);   // right

                // Stamina regen.
                if (stam_delay > 0.0f) {
                    stam_delay -= dt;
                } else {
                    player_stam += STAMINA_REGEN * dt;
                    if (player_stam > player_max_stam) player_stam = player_max_stam;
                }

                // O: a quick tap is a dodge (side-step toward the stick, back-step if neutral); holding it while moving sprints.
                static float circ_hold = 0.0f;
                static int circ_was = 0;
                static int circ_block = 0;   // O pressed to back out of a menu must not become a dodge / sprint
                if (pad.buttons & SCE_CTRL_CIRCLE) { if (ctl <= 0.0f) circ_block = 1; } else circ_block = 0;
                const int circ_down = ctl > 0.0f && !circ_block && (pad.buttons & SCE_CTRL_CIRCLE);
                if (circ_down) circ_hold += dt;
                const int circ_tap = circ_was && !circ_down && circ_hold < SPRINT_HOLD_TIME && ctl > 0.0f;
                circ_was = circ_down;
                if (!circ_down) circ_hold = 0.0f;
                sprinting = circ_down && circ_hold >= SPRINT_HOLD_TIME && (lx * lx + ly * ly) > 0.09f && player_stam > 0.0f &&
                            dodge_t < 0.0f && attack_t < 0.0f && cast_t < 0.0f && use_t < 0.0f;
                if (circ_tap && dodge_t < 0.0f && attack_t < 0.0f && cast_t < 0.0f && use_t < 0.0f && player_stam > 0.0f) {
                    float mag = sqrtf(lx * lx + ly * ly);
                    float dright = 0.0f, dfwd = -1.0f;
                    if (mag > 0.3f) { dright = lx / mag; dfwd = -ly / mag; }
                    dodge_vx = fx * dfwd + sx * dright;
                    dodge_vz = fz * dfwd + sz * dright;
                    dodge_side = dright;
                    dodge_t = 0.0f;
                    use_stamina(DODGE_COST);
                }

                // Hot bar (D-pad left/right): choose which consumable SQUARE will use.
                if (wpressed & SCE_CTRL_RIGHT) active_hot = (active_hot + 1) % HOT_SLOTS;
                if (wpressed & SCE_CTRL_LEFT)  active_hot = (active_hot + HOT_SLOTS - 1) % HOT_SLOTS;

                // Swap weapons (D-pad up/down): cycles through the filled weapon slots.
                if (swap_t < 0.0f && attack_t < 0.0f && dodge_t < 0.0f && cast_t < 0.0f && use_t < 0.0f && (wpressed & (SCE_CTRL_UP | SCE_CTRL_DOWN))) {
                    int dir = (wpressed & SCE_CTRL_DOWN) ? 1 : -1;
                    for (int k = 1; k < QUICK_SLOTS; k++) {
                        int j = ((active_quick + dir * k) % QUICK_SLOTS + QUICK_SLOTS) % QUICK_SLOTS;
                        if (quick[j] >= 0) { swap_to = j; swap_t = 0.0f; swap_done = 0; break; }
                    }
                }
                if (swap_t >= 0.0f) {   // old weapon drops out of view, new one rises in
                    swap_t += dt;
                    if (!swap_done && swap_t >= SWAP_TIME * 0.5f) { active_quick = swap_to; swap_done = 1; }
                    if (swap_t >= SWAP_TIME) swap_t = -1.0f;
                }

                // Attack (R): swing the weapon in hand (style depends on the weapon).
                if ((wpressed & SCE_CTRL_RTRIGGER) && attack_t < 0.0f && dodge_t < 0.0f && swap_t < 0.0f && cast_t < 0.0f && use_t < 0.0f) {
                    if (equipped_id() < 0) {
                        snprintf(toast_buf, sizeof(toast_buf), "NO WEAPON EQUIPPED");
                        toast_t = 1.5f;
                    } else if (player_stam > 0.0f) {
                        attack_t = 0.0f;
                        attack_hit_mask = 0;
                        attack_serial++;
                        swing_sparked = 0;
                        use_stamina(item_defs[equipped_id()].stamina_cost);
                    }
                }

                // Left hand (L): cast the fireball. The raised hand and the swelling flame are the warning; it leaves the hand mid-cast.
                if ((wpressed & SCE_CTRL_LTRIGGER) && cast_t < 0.0f && attack_t < 0.0f && dodge_t < 0.0f && swap_t < 0.0f && use_t < 0.0f) {
                    if (left_hand == LH_TORCH) { snprintf(toast_buf, sizeof(toast_buf), "YOUR LEFT HAND HOLDS A TORCH"); toast_t = 1.5f; }
                    else if (!has_fire) { snprintf(toast_buf, sizeof(toast_buf), "YOU KNOW NO SPELLS YET"); toast_t = 1.5f; }
                    else if (left_hand != LH_FIRE) { snprintf(toast_buf, sizeof(toast_buf), "NO SPELL IN YOUR LEFT HAND"); toast_t = 1.5f; }
                    else if (player_stam > 0.0f) { cast_t = 0.0f; cast_fired = 0; use_stamina(FIRE_STAMINA); }
                }
                if (cast_t >= 0.0f) {
                    cast_t += dt;
                    if (!cast_fired && cast_t >= CAST_SPAWN) {
                        cast_fired = 1;
                        spawn_fireball(px + fx * 0.7f, py + 1.15f, pz + fz * 0.7f, fx, fz);
                    }
                    if (cast_t >= CAST_TIME) cast_t = -1.0f;
                }

                // Use the item on the hot bar (SQUARE).
                if ((wpressed & SCE_CTRL_SQUARE) && use_t < 0.0f && attack_t < 0.0f && dodge_t < 0.0f && cast_t < 0.0f && swap_t < 0.0f) {
                    int c = hot[active_hot];
                    if (c < 0) { snprintf(toast_buf, sizeof(toast_buf), "NOTHING IN THAT HOT BAR SLOT"); toast_t = 1.5f; }
                    else if (cons_count[c] <= 0) { snprintf(toast_buf, sizeof(toast_buf), "YOU HAVE NO %s", cons_names[c]); toast_t = 1.5f; }
                    else if (c != CONS_BOMB && player_hp >= player_max_hp - 0.5f) { snprintf(toast_buf, sizeof(toast_buf), "ALREADY AT FULL HEALTH"); toast_t = 1.5f; }
                    else { use_t = 0.0f; use_cons = c; use_done = 0; }
                }
                if (use_t >= 0.0f) {
                    use_t += dt;
                    if (!use_done && use_t >= USE_EFFECT_AT) {
                        use_done = 1;
                        if (cons_count[use_cons] > 0) {
                            cons_count[use_cons]--;
                            if (use_cons == CONS_HERB) player_hp = fminf(player_max_hp, player_hp + HERB_HEAL);
                            else if (use_cons == CONS_POTION) player_hp = fminf(player_max_hp, player_hp + POTION_HEAL);
                            else throw_bomb(px + fx * 0.5f, py + 1.3f, pz + fz * 0.5f, fx, fz);
                        }
                    }
                    if (use_t >= USE_TIME) use_t = -1.0f;
                }

                // Jump (TRIANGLE): how high depends on Athletics.
                {
                    int on_ground = (py <= floor_at(px, pz, py) + 0.001f) && vy <= 0.0f;
                    if ((wpressed & SCE_CTRL_TRIANGLE) && on_ground && dodge_t < 0.0f && player_stam > 0.0f) {
                        vy = sqrtf(2.0f * GRAVITY * jump_height());
                        use_stamina(JUMP_STAMINA);
                    }
                }

                // Movement: a dodge overrides walking.
                float mx = 0.0f, mz = 0.0f;
                if (dodge_t >= 0.0f) {
                    float u = dodge_t / DODGE_TIME;
                    float speed = (DODGE_DISTANCE / DODGE_TIME) * 2.0f * (1.0f - u);  // eases out
                    mx = dodge_vx * speed * dt;
                    mz = dodge_vz * speed * dt;
                    dodge_t += dt;
                    if (dodge_t >= DODGE_TIME) dodge_t = -1.0f;
                } else {
                    float walk = (attack_t >= 0.0f || cast_t >= 0.0f) ? 0.5f : 1.0f;   // slower while swinging
                    if (sprinting) {
                        walk = SPRINT_MULT;
                        player_stam -= SPRINT_DRAIN * dt;
                        stam_delay = 0.5f;
                        if (player_stam <= 0.0f) { player_stam = 0.0f; stam_delay = STAMINA_EXHAUST_DELAY; }
                    }
                    float fwd = -ly, str = lx;
                    mx = (fx * fwd + sx * str) * MOVE_SPEED * walk * dt;
                    mz = (fz * fwd + sz * str) * MOVE_SPEED * walk * dt;
                    moving = sqrtf(fwd * fwd + str * str);
                    if (moving > 1.0f) moving = 1.0f;
                }
                px += mx;
                pz += mz;

                // Stay inside the play area, and out of objects, walls and the sides of platforms.
                clamp_world(&px, &pz);
                resolve_collisions(&px, &pz, PLAYER_R);
                resolve_plats(&px, &pz, PLAYER_R, py);

                // Gravity, landing on platforms, and bonking your head on a ceiling.
                {
                    float fl = floor_at(px, pz, py);
                    vy -= GRAVITY * dt;
                    py += vy * dt;
                    if (py < fl) { py = fl; if (vy < 0.0f) vy = 0.0f; }
                    int rm = room_of(px, pz);
                    float ceil_h = zone == 1 ? CV_CEIL : (rm == 3) ? MZ_WALL_H : (rm == 1 || rm == 2) ? ROOM_WALL_H : 1000.0f;
                    float max_py = ceil_h - 0.25f - EYE_HEIGHT;
                    if (py > max_py) { py = max_py; if (vy > 0.0f) vy = 0.0f; }
                }

                // Swing progress + hit checks (training dummy, then enemies).
                if (attack_t >= 0.0f && equipped_id() >= 0) {
                    const ItemDef *wd = &item_defs[equipped_id()];
                    attack_t += dt;
                    float u = attack_t / wd->swing_time;
                    if (u >= wd->hit_start && u <= wd->hit_end) {
                        if (zone == 0 && !(attack_hit_mask & 1u)) {
                            if (weapon_touches(wd, px, pz, fx, fz, sx, sz, u, DUMMY_X, DUMMY_Z, 0.55f)) {
                                attack_hit_mask |= 1u;
                                dummy_hit(wd->dmg_type, weapon_damage(wd) * 0.45f);
                            }
                        }

                        // Steel on stone: sparks where the blow lands on a wall or a hard object.
                        if (!swing_sparked && !(attack_hit_mask & 1u)) {
                            float hx, hz, rr = wd->range + 0.25f;
                            if (ray_hit(px, pz, px + fx * rr, pz + fz * rr, &hx, &hz)) {
                                swing_sparked = 1;
                                spawn_sparks(hx - fx * 0.12f, py + 1.42f, hz - fz * 0.12f, -fx, -fz, 6);
                            }
                        }

                        const int n_hit = NUM_ENEMIES;   // (a split worm adds enemies: they wait for the next swing)
                        for (int i = 0; i < n_hit; i++) {
                            Enemy *e = &enemies[i];
                            if (e->state == E_DEAD || e->zone != zone || e->hit_id == attack_serial) continue;
                            if (weapon_touches(wd, px, pz, fx, fz, sx, sz, u, e->x, e->z, enemy_radius(e))) {
                                e->hit_id = attack_serial;
                                hit_enemy(e, wd, px, pz);
                            }
                        }
                    }
                    if (u >= 1.0f) attack_t = -1.0f;
                } else if (attack_t >= 0.0f) {
                    attack_t = -1.0f;
                }
                if (dummy_wobble >= 0.0f) {
                    dummy_wobble += dt;
                    if (dummy_wobble > 1.2f) dummy_wobble = -1.0f;
                }

                // Doors: swing open/shut; each doorway collider is only active while its door is shut.
                for (int i = 0; i < NUM_DOORS; i++) {
                    Door *dr = &doors[i];
                    float tgt = dr->target ? 1.0f : 0.0f;
                    if (dr->open_t < tgt) { dr->open_t += DOOR_OPEN_SPEED * dt; if (dr->open_t > tgt) dr->open_t = tgt; }
                    else if (dr->open_t > tgt) { dr->open_t -= DOOR_OPEN_SPEED * dt; if (dr->open_t < tgt) dr->open_t = tgt; }
                    if (dr->wall >= 0) walls[dr->wall].on = (dr->open_t < 0.35f);
                }

                // Enemies.
                if (zone == 1) {
                    int pc, pr;
                    if (cave_cell(px, pz, &pc, &pr)) cave_dist_from(pc, pr);
                }
                for (int i = 0; i < NUM_ENEMIES; i++) if (enemies[i].zone == zone) update_enemy(&enemies[i], dt, px, pz);
                update_projectiles(dt);
                update_bombs(dt);
                update_fx(dt);

                // Interaction: the nearest of pick-up / door / beacon / person / portal in range.
                {
                    float best = 1e9f;
                    int kind = 0;
                    Pickup *near_pickup = NULL;
                    int near_door = -1, near_portal = -1;
                    if (ctl > 0.0f) {
                        for (int i = 0; i < NUM_PICKUPS; i++) {
                            if (pickups[i].taken || ((i >= PK_CAVE0) != (zone == 1))) continue;
                            float dx = px - pickups[i].x, dz = pz - pickups[i].z;
                            float d = sqrtf(dx * dx + dz * dz);
                            if (d < PICKUP_RANGE && fabsf(py - pickups[i].y) < 1.4f && d < best) { best = d; kind = 1; near_pickup = &pickups[i]; }
                        }
                        if (zone == 0) {
                            for (int i = 0; i < NUM_DOORS; i++) {   // closed doors, from their near (west) side
                                if (doors[i].target) continue;
                                float dx = px - doors[i].x, dz = pz - doors[i].z;
                                float d = sqrtf(dx * dx + dz * dz);
                                if (px < doors[i].x && d < DOOR_RANGE && d < best) { best = d; kind = 2; near_door = i; }
                            }
                            {
                                float dx = px - BEACON_X, dz = pz - BEACON_Z;
                                float d = sqrtf(dx * dx + dz * dz);
                                if (d < BEACON_RANGE && d < best) { best = d; kind = 3; }
                            }
                            {
                                float dx = px - NPC_X, dz = pz - NPC_Z;
                                float d = sqrtf(dx * dx + dz * dz);
                                if (d < NPC_RANGE && d < best) { best = d; kind = 4; }
                            }
                            {
                                float dx = px - SMITH_X, dz = pz - SMITH_Z;
                                float d = sqrtf(dx * dx + dz * dz);
                                if (d < NPC_RANGE + 0.6f && d < best) { best = d; kind = 7; }
                            }
                        } else {
                            float dx = px - CVN_X, dz = pz - CVN_Z;
                            float d = sqrtf(dx * dx + dz * dz);
                            if (d < NPC_RANGE && d < best) { best = d; kind = 6; }
                        }
                        for (int k = 0; k < NUM_PORTALS; k++) {
                            if (portals[k].zone != zone) continue;
                            float dx = px - portals[k].x, dz = pz - portals[k].z;
                            float d = sqrtf(dx * dx + dz * dz);
                            if (d < 2.4f && d < best) { best = d; kind = 5; near_portal = k; }
                        }
                    }

                    if (kind == 1) {
                        if (near_pickup->chest == 3) snprintf(prompt_buf, sizeof(prompt_buf), "X: TAKE THE FIRE TOME");
                        else if (near_pickup->chest == 4) snprintf(prompt_buf, sizeof(prompt_buf), "X: PICK UP %s", cons_names[near_pickup->item]);
                        else if (near_pickup->chest) snprintf(prompt_buf, sizeof(prompt_buf), "X: OPEN CHEST");
                        else snprintf(prompt_buf, sizeof(prompt_buf), "X: PICK UP %s", item_defs[near_pickup->item].name);
                    }
                    else if (kind == 2) snprintf(prompt_buf, sizeof(prompt_buf), (doors[near_door].locked && !has_key) ? "X: LOCKED DOOR" : (doors[near_door].locked ? "X: UNLOCK DOOR" : "X: OPEN DOOR"));
                    else if (kind == 3) snprintf(prompt_buf, sizeof(prompt_buf), "X: USE BEACON");
                    else if (kind == 4 || kind == 6 || kind == 7) snprintf(prompt_buf, sizeof(prompt_buf), "X: TALK");
                    else if (kind == 5) snprintf(prompt_buf, sizeof(prompt_buf), "%s", portals[near_portal].prompt);
                    if (kind) prompt = prompt_buf;

                    if (kind && (wpressed & SCE_CTRL_CROSS)) {
                        if (kind == 1) {
                            Pickup *pk = near_pickup;
                            if (pk->chest == 3) {
                                has_fire = 1;
                                if (left_hand == LH_NONE) left_hand = LH_FIRE;
                                pk->taken = 1;
                                snprintf(toast_buf, sizeof(toast_buf), "LEARNED FIREBALL. L CASTS IT.");
                            } else if (pk->chest == 2 || pk->chest == 6) {   // an armor set
                                if (inv_n + ARMOR_SLOTS > INV_MAX) {
                                    snprintf(toast_buf, sizeof(toast_buf), "INVENTORY FULL");
                                } else {
                                    static const int cloth[ARMOR_SLOTS] = { ITEM_CLOTH_HOOD, ITEM_CLOTH_TUNIC, ITEM_CLOTH_GLOVES, ITEM_CLOTH_TROUSERS };
                                    static const int leather[ARMOR_SLOTS] = { ITEM_LEATHER_CAP, ITEM_LEATHER_JERKIN, ITEM_LEATHER_BRACERS, ITEM_LEATHER_BOOTS };
                                    const int *set = pk->chest == 2 ? cloth : leather;
                                    for (int k = 0; k < ARMOR_SLOTS; k++) {
                                        inv[inv_n++] = set[k];
                                        if (armor[k] < 0) armor[k] = set[k];   // armor is worn straight away
                                    }
                                    pk->taken = 1;
                                    snprintf(toast_buf, sizeof(toast_buf), pk->chest == 2 ? "FOUND CLOTH ARMOR. YOU PUT IT ON." : "FOUND LEATHER ARMOR. YOU PUT IT ON.");
                                }
                            } else if (pk->chest == 4 || pk->chest == 5) {
                                give_cons(pk->item, pk->qty);
                                pk->taken = 1;
                                snprintf(toast_buf, sizeof(toast_buf), "FOUND %d %s", pk->qty, cons_names[pk->item]);
                            } else if (inv_n < INV_MAX) {
                                inv[inv_n++] = pk->item;
                                pk->taken = 1;
                                snprintf(toast_buf, sizeof(toast_buf), pk->chest ? "FOUND %s" : "PICKED UP %s", item_defs[pk->item].name);
                            } else {
                                snprintf(toast_buf, sizeof(toast_buf), "INVENTORY FULL");
                            }
                            toast_t = 2.0f;
                            prompt = NULL;
                        } else if (kind == 2) {
                            if (doors[near_door].locked && !has_key) {
                                snprintf(toast_buf, sizeof(toast_buf), "IT IS LOCKED. YOU NEED A KEY.");
                                toast_t = 2.0f;
                            } else {
                                doors[near_door].target = 1;
                            }
                            prompt = NULL;
                        } else if (kind == 3) {
                            menu = MENU_BEACON;
                            beacon_sel = 0;
                            prompt = NULL;
                        } else if (kind == 5) {
                            fade_state = 1; fade_t = 0.0f; portal_k = near_portal;
                            prompt = NULL;
                        } else {
                            menu = MENU_DIALOGUE;
                            dlg_who = kind == 6 ? 1 : (kind == 7 ? 2 : 0);
                            if (kind == 7) smith_line = 0;
                            if (kind == 6 && !has_torch) cvn_line = 0;
                            dlg_chars = 0.0f;
                            prompt = NULL;
                        }
                    }
                }
            }
        }

        // Camera effects during a dodge.
        if (dodge_t >= 0.0f) {
            float s = sinf(PI_F * dodge_t / DODGE_TIME);
            cam_roll = dodge_side * DODGE_ROLL_DEG * s;
            cam_drop = 0.12f * s;
        } else {
            cam_roll = 0.0f;
            cam_drop = 0.0f;
        }
        bob += dt * moving * 9.0f;

        g_cam_x = px; g_cam_z = pz; g_cam_eye = EYE_HEIGHT + py - cam_drop;
        g_cam_yaw = yaw; g_cam_pitch = pitch; g_cam_roll = cam_roll * PI_F / 180.0f;

        // ---- draw world ----
        {
            // Sky and fog per zone: bright day outside, black in the cave (the torch pushes the dark back).
            static const float black[4] = { 0.0f, 0.0f, 0.0f, 1.0f };
            if (screen == SCREEN_GAME && zone == 1) {
                float fe = (left_hand == LH_TORCH) ? TORCH_FOG_END * (1.0f + 0.05f * sinf(t * 1.7f) + 0.035f * sinf(t * 2.9f + 1.0f) + 0.015f * sinf(t * 0.8f + 4.0f)) : DARK_FOG_END;
                {   // the boss rooms' torches push the dark back as you near them
                    float dm = 1e9f;
                    for (int i = 0; i < cv_nlights; i++) {
                        float ddx = px - cv_lights[i][0], ddz = pz - cv_lights[i][1], dd = sqrtf(ddx * ddx + ddz * ddz);
                        if (dd < dm) dm = dd;
                    }
                    if (dm < 13.0f) {
                        float tgt = 15.0f * (1.0f + 0.04f * sinf(t * 2.1f));
                        if (tgt > fe) fe += (tgt - fe) * (1.0f - dm / 13.0f);
                    }
                }
                glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
                glFogfv(GL_FOG_COLOR, black);
                glFogf(GL_FOG_START, 0.6f);
                glFogf(GL_FOG_END, fe);
            } else {
                glClearColor(sky[0], sky[1], sky[2], sky[3]);
                glFogfv(GL_FOG_COLOR, sky);
                glFogf(GL_FOG_START, 14.0f);
                glFogf(GL_FOG_END, 52.0f);
            }
        }
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        if (screen == SCREEN_GAME) {
        glEnable(GL_DEPTH_TEST);
        glEnable(GL_FOG);

        set_perspective();
        glLoadIdentity();
        glRotatef(cam_roll, 0, 0, 1);
        glRotatef(-pitch * 180.0f / PI_F, 1, 0, 0);
        glRotatef(-yaw * 180.0f / PI_F, 0, 1, 0);
        glTranslatef(-px, -(EYE_HEIGHT + py - cam_drop), -pz);

        glEnableClientState(GL_VERTEX_ARRAY);
        glEnableClientState(GL_COLOR_ARRAY);

        // The PS1 wobble: snap the scenery's vertices to a coarse screen grid.
        {
            const float ecy = EYE_HEIGHT + py - cam_drop;
            if (zone == 0) {
                snap_mesh(&world_mesh, px, ecy, pz, yaw, pitch, 45.0f);
                snap_mesh(&brick_mesh, px, ecy, pz, yaw, pitch, 45.0f);
            } else {
                snap_mesh(&cave_mesh, px, ecy, pz, yaw, pitch, 26.0f);
            }
        }
        if (zone == 0) { draw_mesh(&world_mesh); draw_mesh(&brick_mesh); }
        else {
            draw_mesh(&cave_mesh);
            for (int i = 0; i < cv_nlights; i++) {   // the boss-room torches: slow, lazy flames
                float ff = 0.27f * (1.0f + 0.10f * sinf(t * 3.1f + (float)i * 1.7f) + 0.07f * sinf(t * 5.3f + (float)i * 2.9f));
                glPushMatrix();
                glTranslatef(cv_lights[i][0], 1.88f, cv_lights[i][1]);
                glRotatef(t * 60.0f + (float)i * 40.0f, 0, 1, 0);
                glScalef(ff, ff * 1.5f, ff);
                draw_mesh(&fire_mesh);
                glPopMatrix();
            }
        }

        // Pick-ups: floating things spin, chests sit with their lids shut until looted.
        for (int i = 0; i < NUM_PICKUPS; i++) {
            if ((i >= PK_CAVE0) != (zone == 1)) continue;
            if (pickups[i].chest == 3) {   // the fire tome: a spinning flame
                if (pickups[i].taken) continue;
                glPushMatrix();
                glTranslatef(pickups[i].x, 1.2f + sinf(t * 2.0f) * 0.1f, pickups[i].z);
                glRotatef(t * 90.0f, 0, 1, 0);
                glScalef(0.7f + 0.08f * sinf(t * 9.0f), 0.8f, 0.7f + 0.08f * sinf(t * 9.0f));
                draw_mesh(&fire_mesh);
                glPopMatrix();
                continue;
            }
            if (pickups[i].chest == 4) {   // a loose herb / potion / bomb
                if (pickups[i].taken) continue;
                glPushMatrix();
                glTranslatef(pickups[i].x, 0.9f + sinf(t * 2.0f + i) * 0.1f, pickups[i].z);
                glRotatef(t * 70.0f + i * 90.0f, 0, 1, 0);
                glScalef(1.5f, 1.5f, 1.5f);
                draw_mesh(cons_mesh(pickups[i].item));
                glPopMatrix();
                continue;
            }
            if (pickups[i].chest) {   // chest: lid shut until it has been looted
                glPushMatrix();
                glTranslatef(pickups[i].x, pickups[i].y, pickups[i].z);
                if (pickups[i].chest == 2) glRotatef(180.0f, 0, 1, 0);   // the hidden one faces away from the pyramid
                draw_mesh(&chest_mesh);
                glTranslatef(0.0f, 0.55f, -0.35f);
                glRotatef(pickups[i].taken ? -105.0f : 0.0f, 1, 0, 0);
                draw_mesh(&chestlid_mesh);
                glPopMatrix();
                continue;
            }
            if (pickups[i].taken) continue;
            glPushMatrix();
            glTranslatef(pickups[i].x, 1.25f + sinf(t * 2.0f + i) * 0.1f, pickups[i].z);
            glRotatef(t * 70.0f + i * 90.0f, 0, 1, 0);
            glTranslatef(0, -0.4f, 0);
            draw_mesh(item_defs[pickups[i].item].mesh);
            glPopMatrix();
        }

        if (zone == 0) {
            // Training dummy: slashes rock it sideways, blunt blows rock it back.
            glPushMatrix();
            glTranslatef(DUMMY_X, 0.0f, DUMMY_Z);
            if (dummy_wobble >= 0.0f) {
                float ang = sinf(dummy_wobble * 28.0f) * expf(-dummy_wobble * 5.0f) * dummy_hit_amp;
                if (dummy_hit_type == DMG_SLASH) glRotatef(ang, 0, 0, 1);
                else                             glRotatef(ang, 1, 0, 0);
            }
            draw_mesh(&dummy_mesh);
            glPopMatrix();

            // Doors (each swings open about its hinge, into the room beyond).
            for (int i = 0; i < NUM_DOORS; i++) {
                glPushMatrix();
                glTranslatef(doors[i].x, 0.0f, doors[i].z + DOOR_HALF);
                glRotatef(-95.0f * smooth01(doors[i].open_t), 0, 1, 0);
                draw_mesh(&door_mesh);
                glPopMatrix();
            }

            // Beacon crystal.
            glPushMatrix();
            glTranslatef(BEACON_X, 1.9f + sinf(t * 2.0f) * 0.08f, BEACON_Z);
            glRotatef(t * 50.0f, 0, 1, 0);
            draw_mesh(&gem_mesh);
            glPopMatrix();
        }

        // Enemies.
        for (int i = 0; i < NUM_ENEMIES; i++) {
            const Enemy *e = &enemies[i];
            if (e->zone != zone) continue;
            if (e->state == E_DEAD) {   // corpses lie there a while, fade out, then are gone for good (until you rest)
                float a = 1.0f - (e->state_t - CORPSE_LINGER) / CORPSE_FADE;
                if (a <= 0.0f) continue;
                if (a < 1.0f) { mesh_alpha = a; glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); }
            }
            draw_enemy(e, t);
            mesh_alpha = 1.0f;
            glDisable(GL_BLEND);
        }

        // Bombs in flight.
        for (int i = 0; i < MAX_BOMB; i++) {
            if (!bombs[i].on) continue;
            glPushMatrix();
            glTranslatef(bombs[i].x, bombs[i].y, bombs[i].z);
            glRotatef(bombs[i].spin, 1, 0.3f, 0);
            glScalef(1.1f, 1.1f, 1.1f);
            draw_mesh(&bomb_mesh);
            glPopMatrix();
        }

        // Fireballs: a flame core with a short tail.
        for (int i = 0; i < MAX_PROJ; i++) {
            if (!projs[i].on) continue;
            for (int k = 0; k < 4; k++) {
                float back = (float)k * 0.32f, sc = (0.36f - 0.07f * (float)k) * (1.0f + 0.12f * sinf(t * 30.0f + (float)k));
                glPushMatrix();
                glTranslatef(projs[i].x - projs[i].dx * back, projs[i].y, projs[i].z - projs[i].dz * back);
                glRotatef(t * 400.0f + (float)k * 60.0f, 0.3f, 1, 0.2f);
                glScalef(sc, sc, sc);
                draw_mesh(&fire_mesh);
                glPopMatrix();
            }
        }

        // Explosions: a ball of fire that swells and shrinks away.
        for (int i = 0; i < MAX_BOOM; i++) {
            if (!booms[i].on) continue;
            float u = booms[i].t / booms[i].dur, sz = booms[i].size;
            float grow = sinf(u * PI_F * 0.5f), fade = 1.0f - u * u;
            for (int k = 0; k < 3; k++) {
                float sc = sz * (0.55f + 0.45f * grow) * (1.0f - 0.22f * k) * (0.35f + 0.65f * fade);
                glPushMatrix();
                glTranslatef(booms[i].x + (k - 1) * 0.12f * sz, booms[i].y + k * 0.1f * sz, booms[i].z - (k - 1) * 0.1f * sz);
                glRotatef(t * 500.0f + k * 70.0f, 0.3f, 1, 0.2f);
                glScalef(sc, sc, sc);
                draw_mesh(&fire_mesh);
                glPopMatrix();
            }
        }

        // Sparks and embers.
        for (int i = 0; i < MAX_PART; i++) {
            const Particle *q = &parts[i];
            if (!q->on) continue;
            float k = q->size * (0.4f + 0.6f * q->life / q->max);
            glPushMatrix();
            glTranslatef(q->x, q->y, q->z);
            glRotatef(t * 300.0f + i * 40.0f, 1, 1, 0);
            glScalef(k, k, k);
            draw_mesh(q->kind ? &ember_mesh : &spark_mesh);
            glPopMatrix();
        }

        if (zone == 0) {
            // The blacksmith: a slow, steady cycle -- lift the hammer, hold, strike, rest.
            {
                const float cyc = 2.6f;
                float ph = fmodf(t, cyc) / cyc, ang;
                static float prev_ph = 0.0f;
                if (ph < 0.45f)      ang = -60.0f + (-70.0f) * smooth01(ph / 0.45f);
                else if (ph < 0.60f) ang = -130.0f;
                else if (ph < 0.68f) { float u = (ph - 0.60f) / 0.08f; ang = -130.0f + 70.0f * u * u; }
                else if (ph < 0.76f) { float u = (ph - 0.68f) / 0.08f; ang = -60.0f - 6.0f * sinf(PI_F * u); }
                else                 ang = -60.0f;
                if (ph >= 0.68f && prev_ph < 0.68f) {
                    float ddx = px - SMITH_X, ddz = pz - SMITH_Z;
                    if (ddx * ddx + ddz * ddz < 400.0f) spawn_sparks(SMITH_X, 0.95f, ANVIL_Z, 0.0f, 0.7f, 6);
                }
                prev_ph = ph;
                glPushMatrix();
                glTranslatef(SMITH_X, 0.0f, SMITH_Z);
                draw_mesh(&smith_mesh);
                glTranslatef(0.40f, 1.42f, 0.04f);
                glRotatef(ang, 1, 0, 0);
                draw_mesh(&smitharm_mesh);
                glPopMatrix();
                // the forge's fire
                glPushMatrix();
                glTranslatef(FORGE_X, 1.05f, FORGE_Z);
                float ff = 0.30f * (1.0f + 0.10f * sinf(t * 3.1f) + 0.07f * sinf(t * 5.3f + 2.0f));
                glRotatef(t * 60.0f, 0, 1, 0);
                glScalef(ff, ff * 1.4f, ff);
                draw_mesh(&fire_mesh);
                glPopMatrix();
            }
            // The wanderer by the door: turns to face you when you're near, breathes gently.
            float tdx = px - NPC_X, tdz = pz - NPC_Z;
            float target = NPC_REST_YAW;
            if (tdx * tdx + tdz * tdz < 49.0f) target = atan2f(tdx, tdz);
            float diff = target - npc_yaw;
            while (diff >  PI_F) diff -= 2.0f * PI_F;
            while (diff < -PI_F) diff += 2.0f * PI_F;
            npc_yaw += diff * fminf(1.0f, 5.0f * dt);
            glPushMatrix();
            glTranslatef(NPC_X, 0.0f, NPC_Z);
            glRotatef(npc_yaw * 180.0f / PI_F, 0, 1, 0);
            glScalef(1.0f, 1.0f + sinf(t * 1.6f) * 0.012f, 1.0f);
            draw_mesh(&npc_mesh);
            glPopMatrix();
        } else {
            // The dying man: slumped against the wall, turning his head toward you, breathing shallowly.
            static float dy_yaw = 0.0f;
            float tdx = px - CVN_X, tdz = pz - CVN_Z;
            float target = 0.0f;
            if (tdx * tdx + tdz * tdz < 36.0f) target = atan2f(tdx, tdz) * 0.5f;
            dy_yaw += (target - dy_yaw) * fminf(1.0f, 3.0f * dt);
            glPushMatrix();
            glTranslatef(CVN_X, 0.0f, CVN_Z);
            glRotatef(dy_yaw * 180.0f / PI_F, 0, 1, 0);
            glScalef(1.0f, 1.0f + sinf(t * 1.1f) * 0.02f, 1.0f);
            draw_mesh(&dying_mesh);
            glPopMatrix();
        }

        // ---- draw held weapon (view model) ----
        // Depth is cleared so it never clips into walls; no fog on the hand.
        glClear(GL_DEPTH_BUFFER_BIT);
        glDisable(GL_FOG);
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();

        Pose ap = {0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
        const int held = equipped_id();
        const Mesh *in_hand = held >= 0 ? item_defs[held].mesh : NULL;
        if (use_t >= 0.0f) {
            // Using an item: the weapon goes away and the item is in your hand instead.
            float u = use_t / USE_TIME;
            in_hand = (use_cons == CONS_BOMB && use_done) ? NULL : cons_mesh(use_cons);
            ap = (Pose){0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
            if (use_cons == CONS_BOMB) {
                float k = smooth01(u / 0.60f), f = smooth01((u - 0.55f) / 0.30f);
                ap.dx = 0.10f * k - 0.10f * f; ap.dy = 0.12f * k - 0.05f * f; ap.dz = 0.20f * k - 0.55f * f;
                ap.rx = 35.0f * k - 85.0f * f;
            } else {
                float sn = sinf(PI_F * u);
                ap.dx = -0.26f * sn; ap.dy = 0.10f + 0.30f * sn; ap.dz = 0.05f * sn;
                ap.rx = (use_cons == CONS_POTION ? -75.0f : -35.0f) * sn;
            }
        } else if (held >= 0) {
            const ItemDef *wd = &item_defs[held];
            if (attack_t >= 0.0f) ap = swing_pose(wd->swing, attack_t / wd->swing_time);
            ap.dx += wd->hold.dx; ap.dy += wd->hold.dy; ap.dz += wd->hold.dz;
            ap.rz += wd->hold.rz; ap.rx += wd->hold.rx; ap.ry += wd->hold.ry;
        }
        if (swap_t >= 0.0f) {   // lower the weapon out of view and bring the new one up
            float dip = sinf(PI_F * swap_t / SWAP_TIME);
            ap.dy -= 0.80f * dip;
            ap.rx -= 25.0f * dip;
        }
        float dodge_dip = (dodge_t >= 0.0f) ? 0.06f * sinf(PI_F * dodge_t / DODGE_TIME) : 0.0f;
        float vm_tx = VM_X + ap.dx + sinf(bob) * 0.012f * moving;
        float vm_ty = VM_Y + ap.dy - dodge_dip + fabsf(sinf(bob)) * 0.018f * moving + sinf(t * 1.5f) * 0.004f;
        float vm_tz = VM_Z + ap.dz;
        float vm_rz = VM_ROT_Z + ap.rz, vm_rx = VM_ROT_X + ap.rx, vm_ry = ap.ry;

        // Arm first (camera space): stays anchored at the shoulder and stretches to the wrist.
        vec3 wrist = vm_point(V(0.06f, -0.16f, 0.0f), vm_tx, vm_ty, vm_tz, vm_rz, vm_rx, vm_ry);
        build_arm(V(ARM_ANCHOR_X, ARM_ANCHOR_Y, ARM_ANCHOR_Z), wrist);
        draw_mesh(&arm_mesh);

        // Left hand: rises palm-out while casting, with the flame swelling in front of it.
        if (cast_t >= 0.0f) {
            float cu = cast_t / CAST_TIME, hh;
            if (cu < 0.4f) hh = smooth01(cu / 0.4f);
            else if (cu < 0.55f) hh = 1.0f;
            else hh = 1.0f - smooth01((cu - 0.55f) / 0.45f);
            float lx0 = -0.80f, ly0 = -1.10f, lz0 = -0.75f, lx1 = -0.42f, ly1 = -0.36f, lz1 = -0.95f;
            float hx = lx0 + (lx1 - lx0) * hh, hy = ly0 + (ly1 - ly0) * hh, hz = lz0 + (lz1 - lz0) * hh;
            float spawnu = CAST_SPAWN / CAST_TIME, flame;
            if (cu < spawnu) flame = cu / spawnu;                                    // swelling
            else flame = fmaxf(0.0f, 1.0f - (cu - spawnu) / 0.12f) * 1.3f;          // a quick flash as it leaves
            glPushMatrix();
            glTranslatef(hx, hy, hz);
            glRotatef(-35.0f * hh, 1, 0, 0);
            glRotatef(12.0f, 0, 0, 1);
            draw_mesh(&lhand_mesh);
            glPopMatrix();
            if (flame > 0.02f) {
                float fs = 0.22f * flame * (1.0f + 0.1f * sinf(t * 40.0f));
                glPushMatrix();
                glTranslatef(hx + 0.01f, hy + 0.16f, hz - 0.16f);
                glRotatef(t * 300.0f, 0.2f, 1, 0.1f);
                glScalef(fs, fs, fs);
                draw_mesh(&fire_mesh);
                glPopMatrix();
            }
        } else if (left_hand == LH_TORCH) {
            // The torch in the left hand, with a flickering flame.
            float sway = sinf(t * 1.7f) * 0.012f + sinf(bob) * 0.010f * moving;
            float lift = fabsf(sinf(bob)) * 0.014f * moving;
            glPushMatrix();
            glTranslatef(-0.50f + sway, -0.66f + lift, -0.92f);
            glRotatef(-12.0f, 1, 0, 0);
            glRotatef(14.0f, 0, 0, 1);
            glPushMatrix();
            glTranslatef(0.0f, -0.02f, 0.02f);
            draw_mesh(&lhand_mesh);
            glPopMatrix();
            glTranslatef(0.0f, 0.10f, -0.04f);
            draw_mesh(&torch_mesh);
            {
                float fl = 0.17f * (1.0f + 0.10f * sinf(t * 3.3f) + 0.07f * sinf(t * 5.1f + 2.0f));
                glTranslatef(0.0f, 0.46f, 0.0f);
                glRotatef(t * 70.0f, 0.2f, 1, 0.1f);
                glScalef(fl, fl * 1.5f, fl);
                draw_mesh(&fire_mesh);
            }
            glPopMatrix();
        }

        // Hand + weapon (or the item being used).
        glTranslatef(vm_tx, vm_ty, vm_tz);
        glRotatef(vm_ry, 0, 1, 0);
        glRotatef(vm_rz, 0, 0, 1);
        glRotatef(vm_rx, 1, 0, 0);
        draw_mesh(&hand_mesh);
        if (in_hand) {
            if (use_t >= 0.0f) {
                glTranslatef(0.0f, 0.12f, -0.02f);
                glScalef(1.15f, 1.15f, 1.15f);
            }
            draw_mesh(in_hand);
        }
        glDisableClientState(GL_COLOR_ARRAY);
        glDisableClientState(GL_VERTEX_ARRAY);

        }   // end of in-game drawing

        // ---- draw HUD ----
        build_hud(prompt, toast_t > 0.0f ? toast_buf : NULL);
        glDisable(GL_DEPTH_TEST);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        glOrtho(0, 960, 544, 0, -1, 1);
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();
        glEnableClientState(GL_VERTEX_ARRAY);
        glEnableClientState(GL_COLOR_ARRAY);
        glVertexPointer(2, GL_FLOAT, 0, hud_v);
        glColorPointer(4, GL_FLOAT, 0, hud_c);
        for (int off = 0; off < hud_n; off += 30000) glDrawArrays(GL_TRIANGLES, off, hud_n - off > 30000 ? 30000 : hud_n - off);
        glDisableClientState(GL_COLOR_ARRAY);
        glDisableClientState(GL_VERTEX_ARRAY);
        glDisable(GL_BLEND);

        // ---- spinning 3D previews (bestiary enemy / equipment weapon) ----
        if (menu == MENU_BESTIARY && bestiary_seen[bestiary_sel]) {
            const EnemyDef *bd = &enemy_defs[bestiary_sel];
            draw_preview(bd->mesh, PREVIEW_X, PREVIEW_Y, PREVIEW_W, PREVIEW_H,
                         bd->preview_scale, bd->preview_cy, bd->preview_cz, 18.0f, t * 40.0f, 0,
                         bd->limb, bd->limb_x, bd->limb_y, bd->limb_rest);
        } else if (menu == MENU_ITEMS) {
            int c = -1, il[CONS_COUNT], iln = 0;
            for (int k = 0; k < CONS_COUNT; k++) if (cons_count[k] > 0) il[iln++] = k;
            c = items_focus ? ((items_sel > 0 && items_sel <= iln) ? il[items_sel - 1] : -1) : hot[items_slot];
            if (c >= 0) draw_preview(cons_mesh(c), EQ_PREVIEW_X, EQ_PREVIEW_Y, EQ_PREVIEW_W, EQ_PREVIEW_H,
                                     2.2f, 0.0f, 0.0f, 20.0f, t * 35.0f, 1, NULL, 0.0f, 0.0f, 0.0f);
        } else if (menu == MENU_INVENTORY && eq_slot != EQ_LH && eq_shown_item() >= 0 && item_defs[eq_shown_item()].kind == KIND_WEAPON) {
            const ItemDef *id = &item_defs[eq_shown_item()];
            draw_preview(id->mesh, EQ_PREVIEW_X, EQ_PREVIEW_Y, EQ_PREVIEW_W, EQ_PREVIEW_H,
                         id->preview_scale, id->preview_cy, 0.0f, 22.0f, t * 35.0f, 1, NULL, 0.0f, 0.0f, 0.0f);
        }

        vglSwapBuffers(GL_FALSE);
    }

    sceKernelExitProcess(0);
    return 0;
}
