# Plain Walk (PS Vita homebrew)

Upload this whole folder to a GitHub repo (keep the folder layout). The workflow in
`.github/workflows/build.yml` builds `PlainWalk.vpk` automatically on every push.
Download it from the repo's Releases page (or the run's Artifacts) and install with VitaShell.

Controls: left stick walk, right stick look, X interact, Triangle jump, Square use item, Circle tap = dodge (hold = sprint),
R attack, L left hand (fireball / torch / thrown bomb), hold D-pad down + right stick = weapon wheel (tap = next weapon),
hold D-pad up + right stick = left-hand wheel (tap = next), D-pad left/right choose item,
SELECT equipment + items, START action menu (bestiary, main menu, quit).
