#!/bin/sh
# Usage: linkwrap.sh <target> -- <full link command...>
# Links, then checks the result with vita-elf-create. If the code segment has no
# room for the module data, relinks with more padding until it is accepted.
T="$1"; shift; shift
D=$(dirname "$T")
CC="$1"
TOOL="${VITASDK}/bin/vita-elf-create"
n=0
i=0
while [ $i -lt 24 ]; do
  printf '.text\n.space %d\n' "$n" > "$D/linkpad.s"
  if "$CC" -c "$D/linkpad.s" -o "$D/linkpad.o" && "$@" "$D/linkpad.o"; then
    if "$TOOL" "$T" "$D/linktest.velf" >/dev/null 2>&1; then
      echo "linkwrap: accepted with padding $n"
      rm -f "$D/linktest.velf"
      exit 0
    fi
    echo "linkwrap: padding $n rejected, retrying"
  else
    echo "linkwrap: link with padding failed, falling back to plain link"
    break
  fi
  i=$((i+1))
  n=$((n+1237))
done
rm -f "$D/linktest.velf"
exec "$@"
